
import API.Menu;
import java.io.File;
import java.io.IOException;

/**
 * Epoca Normal ED Daniel Pinto 8200412 Tomás Pendão 8170308
 */
/**
 * Classe que irá invocar um menu. É o ponto de partida do programa.
 *
 * @author Tomás Pendão
 */
public class Main {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        /**
         * To-Do Acabar os tests //done meter o.jar a dar?
         *
         * Melhorar os imports e os prints fazer os metodos das routes e
         * adicionar essas opções ao menu
         *
         */
        //System.out.println("Working Directory = " + System.getProperty("user.dir"));
        //mostra os nomes dos ficheiros .json de export da empresa

        File file = new File("./exportJSON/empresa");//Creating the directory
        file = new File("./exportJSON/vendedor");//Creating the directory
        file = new File("./exportJSON/mercado");//Creating the directory
        file = new File("./exportJSON/armazem");//Creating the directory

        Menu.start();

    }
}
