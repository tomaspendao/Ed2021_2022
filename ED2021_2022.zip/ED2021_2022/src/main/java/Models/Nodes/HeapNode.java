/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models.Nodes;

/**
 *
 * @author tomaspendao
 */
public class HeapNode<T> extends BinaryTreeNode<T> {

    private HeapNode<T> parent;
    //private T extra;

    /**
     * Creates a new heap node with the specified data.
     *
     *
     * @param obj the data to be contained within the new heap nodes
     */
    public HeapNode(T obj) {
        super(obj);
        parent = null;
    }
    
    /*public HeapNode(T obj, T extra) {
        super(obj);
        this.extra = extra;
        parent = null;
    }*/

    public HeapNode<T> getParent() {
        return parent;
    }

    public void setParent(HeapNode<T> parent) {
        this.parent = parent;
    }

    /*public T getExtra() {
        return extra;
    }

    public void setExtra(T extra) {
        this.extra = extra;
    }*/

    
    
}
