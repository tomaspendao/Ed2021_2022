/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models.Nodes;

/**
 *
 * @author tomaspendao
 */
public class MyLinearNode<T> {
    
        // Node que vai guardar um objecto que vai ser value isto por ser POO
    //Node linear ou seja so UM SENTIDO!!!
    
    private MyLinearNode<T> next;
    private T value;

    public MyLinearNode() {
        this.value = null;
        this.next = null;
    }
    
    public MyLinearNode(T value) {
        this.value = value;
        this.next = null;
    }

    public MyLinearNode<T> getNext() {
        return next;
    }

    public void setNext(MyLinearNode<T> next) {
        this.next = next;
    }

    public T getValue() {
        return value;
    }

    public void setValue(T value) {
        this.value = value;
    }
}
