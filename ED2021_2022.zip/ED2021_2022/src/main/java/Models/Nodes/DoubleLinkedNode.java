/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models.Nodes;

/**
 *
 * @author tomaspendao
 */
public class DoubleLinkedNode<T> {
    
    private DoubleLinkedNode<T> next;
    private DoubleLinkedNode<T> previous;
    private T value;

    public DoubleLinkedNode() {
        this.next = null;
        this.previous = null;
        this.value = null;
    }

    public DoubleLinkedNode(T value) {
        this.next = null;
        this.previous = null;
        this.value = value;
    }

    public DoubleLinkedNode<T> getNext() {
        return next;
    }

    public void setNext(DoubleLinkedNode<T> next) {
        this.next = next;
    }

    public DoubleLinkedNode<T> getPrevious() {
        return previous;
    }

    public void setPrevious(DoubleLinkedNode<T> previous) {
        this.previous = previous;
    }

    public T getValue() {
        return value;
    }

    public void setValue(T value) {
        this.value = value;
    }
    
    
    
}
