/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models.Nodes;

/**
 *
 * @author tomaspendao
 */
public class ArestaWeightless {
    
    private int start;
    private int target;

    public ArestaWeightless() {
    }
    
    public ArestaWeightless(int start, int target) {
        this.start = start;
        this.target = target;
    }

    public int getStart() {
        return start;
    }

    public void setStart(int start) {
        this.start = start;
    }

    public int getTarget() {
        return target;
    }

    public void setTarget(int target) {
        this.target = target;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ArestaWeightless other = (ArestaWeightless) obj;
        if (this.start != other.start) {
            return false;
        }
        return this.target == other.target;
    }
    
}
