/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models.Nodes;

/**
 *
 * @author Tomás Pendão
 */
public class Vertex implements Comparable<Vertex>{
    private int value;
    private float weight;

    public Vertex(int value, float weight) {
        this.value = value;
        this.weight = weight;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public float getWeight() {
        return weight;
    }

    public void setWeight(float weight) {
        this.weight = weight;
    }

    @Override
    public int compareTo(Vertex obj) {
        int result;
        Vertex temp = obj;
        if (this.weight > temp.getWeight()) {
            result = 1;
        } else if (this.weight < temp.getWeight()) {
            result = -1;
        } else {
            result = 0;
        }
        return result;
    }
    
}
