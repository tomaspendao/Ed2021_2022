/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models.Nodes;

/**
 *
 * @author tomaspendao
 */
public class ArestaWeight extends ArestaWeightless{
    
    private float weight;
    
    //ter uma aresta especifica para o trabalho??

    public ArestaWeight(int start, int target, float weight) {
        super(start, target);
        this.weight = weight;
    }
    
    public ArestaWeight(int start, int target) {
        super(start, target);
    }

    public float getWeight() {
        return weight;
    }

    public void setWeight(float weight) {
        this.weight = weight;
    }
    
    
}
