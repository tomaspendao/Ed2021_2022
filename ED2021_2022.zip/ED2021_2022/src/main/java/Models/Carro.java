/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author tomaspendao
 */
public class Carro implements Comparable<Carro> {

    private int rodas;
    private String marca;
    private String modelo;
    private String matricula;
    private int cavalos;

    public Carro() {
    }

    public Carro(int rodas, String marca, String modelo, String matricula, int cavalos) {
        this.rodas = rodas;
        this.marca = marca;
        this.modelo = modelo;
        this.matricula = matricula;
        this.cavalos = cavalos;
    }

    public int getRodas() {
        return rodas;
    }

    public void setRodas(int rodas) {
        this.rodas = rodas;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public int getCavalos() {
        return cavalos;
    }

    public void setCavalos(int cavalos) {
        this.cavalos = cavalos;
    }

    @Override
    public int compareTo(Carro carro) {
        if (carro.getMatricula().equals(this.getMatricula())) {
            return 0;
        } else if (carro.getCavalos() > (this.getCavalos())) {
            return 1;
        } else {
            return -1;
        }
    }

}
