/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import Collections.DoubleLinkedList.OrderedDoubleLinkedList;
import Collections.LinkedList.MyLinkedList;
import Collections.SearchAndSort.SearchingAndSorting;

/**
 *
 * @author tomaspendao
 */
public class CarroMain {
    public static void main(String[] args) {
        Carro[] carros = new Carro[5];
        Carro carro1 = new Carro(4, "BMW", "3", "BB-99-AA", 80);
        Carro carro2 = new Carro(4, "BMW", "3", "BB-99-AA", 80);
        Carro carro3 = new Carro(4, "Tesla", "S", "AA-23-WE", 230);
        Carro carro4 = new Carro(4, "Porsche", "911", "CC-90-PP", 180);
        Carro carro5 = new Carro(4, "Citroen", "c3", "VB-00-Kl", 90);
        
        
        Carro carro7 = new Carro(4, "null", "null", "AA-00-AA", 0);
        
        carros[0] = carro1;
        carros[1] = carro2;
        carros[2] = carro3;
        carros[3] = carro4;
        carros[4] = carro5;
        //carros[5] = carro5;
        
        System.out.println("************ARRAY*****************");
        
        System.out.println(SearchingAndSorting.linearSearch(carros, 0, carros.length-1, carro1));//true --> Correct
        System.out.println(SearchingAndSorting.binarySearch(carros, 0, carros.length-1, carro1));//true --> NOTCORRECT
        System.out.println(SearchingAndSorting.linearSearch(carros, 0, carros.length-1, carro7));//false --> Correct
        System.out.println(SearchingAndSorting.binarySearch(carros, 0, carros.length-1, carro7));//false --> Correct
        
        OrderedDoubleLinkedList<Carro> lista = new OrderedDoubleLinkedList<>();
        lista.add(carro1);
        lista.add(carro2);
        lista.add(carro3);
        lista.add(carro4);
        lista.add(carro5);
        
        MyLinkedList<Carro> list = new MyLinkedList<>();
        list.add(carro1);
        list.add(carro2);
        list.add(carro3);
        list.add(carro4);
        list.add(carro5);
        
        System.out.println("**************LINKEDLIST****************");
        
        System.out.println(SearchingAndSorting.linearSearch(list, carro1));//true --> Correct
        System.out.println(SearchingAndSorting.binarySearch(lista, lista.getFront(), lista.getRear(), carro1));//true --> Correct
        System.out.println(SearchingAndSorting.linearSearch(list, carro7));//false --> Correct
        System.out.println(SearchingAndSorting.binarySearch(lista, lista.getFront(), lista.getRear(), carro7));//false --> Correct
    }
}
