/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import Collections.LinkedList.MyLinkedList;
import Collections.SearchAndSort.SearchingAndSorting;
import Models.Nodes.MyLinearNode;

/**
 *
 * @author tomaspendao
 */
public class SortPhoneList {

    /**
     * Creates an array of Contact objects, * sorts them, then prints them.
     * @param args
     */
    public static void main(String[] args) {
        Contact[] friends = new Contact[7];
        friends[0] = new Contact("Clark", "Kent", "610-555-7384");
        friends[1] = new Contact("Bruce", "Wayne", "215-555-3827");
        friends[2] = new Contact("Peter", "Parker", "733-555-2969");
        friends[3] = new Contact("James", "Howlett", "663-555-3984");
        friends[4] = new Contact("Steven", "Rogers", "464-555-3489");
        friends[5] = new Contact("Britt", "Reid", "322-555-2284");
        friends[6] = new Contact("Matt", "Murdock", "243-555-2837");
        
        SearchingAndSorting.mergeSort(friends,0,6);
        for (int index = 0; index < friends.length; index++) {
            System.out.println(friends[index]);
        }
        /** RES SHOULD BE
         * Howlett, James 663-555-3984
         * Kent, Clark	610-555-7384
         * Murdock, Matt 243-555-2837
         * Parker, Peter 733-555-2969
         * Reid, Britt	322-555-2284
         * Rogers, Steven 464-555-3489
         * Wayne, Bruce	215-555-3827
         */
        
        System.out.println("\n\n");
        
        MyLinkedList<Contact> friends2 = new MyLinkedList<>();
        friends2.add(new Contact("Clark", "Kent", "610-555-7384"));
        friends2.add(new Contact("Bruce", "Wayne", "215-555-3827"));
        friends2.add(new Contact("Peter", "Parker", "733-555-2969"));
        friends2.add(new Contact("James", "Howlett", "663-555-3984"));
        friends2.add(new Contact("Steven", "Rogers", "464-555-3489"));
        friends2.add(new Contact("Britt", "Reid", "322-555-2284"));
        friends2.add(new Contact("Matt", "Murdock", "243-555-2837"));
        SearchingAndSorting.selectionSort(friends2);
        friends2.printAll();
       
    }
}
