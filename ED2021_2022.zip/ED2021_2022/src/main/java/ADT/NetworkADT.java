/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ADT;

/**
 *
 * @author tomaspendao
 */
public interface NetworkADT<T> extends GraphADT<T> {

    void addEdge(T paramT1, T paramT2, double paramDouble);

    double shortestPathWeight(T paramT1, T paramT2);
}
