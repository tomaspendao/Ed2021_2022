/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ADT;

/**
 *
 * @author tomaspendao
 */
public interface QueueADT<T> {

    /**
     * Adds an element to the rear of the queue
     *
     * @param element the element to be added to the rear
     */
    public void enqueue(T element);

    /**
     * Removes and returns the element at the front of this queue
     *
     * @return the element at the front to be removed
     */
    public T dequeue();

    /**
     * Return without removing the first element in the queue
     *
     * @return the first element in this queue
     */
    public T first();

    /**
     * Return true if this queue contains no elements
     *
     * @return true if this queue is empty
     */
    public boolean isEmpty();

    /**
     * Returns the numbers of elements in this queue
     *
     * @return the integer representation of the size of this queue
     */
    public int size();

    /**
     * Returns a string representation of this queue.
     *
     * @return the string representation of this queue
     */
    @Override
    public String toString();

}
