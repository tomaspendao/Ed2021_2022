/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ADT;


/**
 *
 * @author tomaspendao
 */
public interface UnorderedListADT<T> extends ListADT<T>{

    /**
     * Adds an element to the front of the list.
     * 
     * @param element to add to the front of the list
     */
    public void addToFront(T element);

    /**
     * Adds an element to the rear of the list.
     * 
     * @param element to add to the rear of the list
     */
    public void addToRear(T element);

    /**
     * Adds an element after another element on the list.
     * 
     * @param element element to add after @target
     * @param target position to add @element after
     */
    public void addAfter(T element, T target);
}
