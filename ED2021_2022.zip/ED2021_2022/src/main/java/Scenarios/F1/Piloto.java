/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Scenarios.F1;

/**
 *
 * @author tomaspendao
 */
public class Piloto {

    private String name;
    private Equipa team;

    public Piloto(String name, Equipa team) {
        this.name = name;
        this.team = team;
    }

    public String getName() {
        return name;
    }

    public Equipa getTeam() {
        return team;
    }

    @Override
    public String toString() {
        return "Piloto{" + "name=" + name + ", team=" + team + '}';
    }

    
}
