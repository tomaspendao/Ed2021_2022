/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Scenarios.F1;

import ADT.OrderedListADT;
import ADT.UnorderedListADT;
import Collections.Array.ArrayUnorderedList;
import Collections.DoubleLinkedList.DoubleLinkedUnorderedList;
import Collections.DoubleLinkedList.OrderedDoubleLinkedList;

import java.util.Random;

/**
 *
 * @author tomaspendao
 */
public class PolePosition {

    private int amountOfPilots;
    private UnorderedListADT<Integer> pointsTable;
    private int amountOfRacesLeft;
    private UnorderedListADT<Classificacao> tabelaFinalUnordered;
    private OrderedListADT<Classificacao> tabelaFinalOrdered = new OrderedDoubleLinkedList<>();

    private boolean sorted = false;

    private UnorderedListADT<Piloto> prova = new ArrayUnorderedList<>(10);

    public PolePosition(int amountOfRaces, UnorderedListADT<Piloto> pilotos) {
        this.amountOfPilots = pilotos.size();
        this.pointsTable = new ArrayUnorderedList<>(10);
        fillPointsTable();
        this.tabelaFinalUnordered = new DoubleLinkedUnorderedList<>();
        fillTabelaFinal(pilotos);
        this.amountOfRacesLeft = amountOfRaces;
        while (this.amountOfRacesLeft > 0) {
            fillProva();
            this.amountOfRacesLeft--;
        }
        if (this.sorted == false) {
            sort();
        }
    }

    private void fillProva() {
        Random random = new Random();
        UnorderedListADT<Classificacao> givenList = new ArrayUnorderedList<>(this.amountOfPilots);
        int option1 = random.nextInt(2);
        for (int i = 0; i < this.amountOfPilots; i++) {
            if (option1 == 0) {
                int option2 = random.nextInt(2);
                Classificacao temp = this.tabelaFinalUnordered.removeFirst();
                if (option2 == 0) {
                    this.prova.addToFront(temp.getPiloto());
                } else {
                    this.prova.addToRear(temp.getPiloto());
                }
                givenList.addToFront(temp);
            } else {
                int option2 = random.nextInt(2);
                Classificacao temp = this.tabelaFinalUnordered.removeLast();
                if (option2 == 0) {
                    this.prova.addToFront(temp.getPiloto());
                } else {
                    this.prova.addToRear(temp.getPiloto());
                }
                givenList.addToFront(temp);
            }

        }
        this.tabelaFinalUnordered = givenList;
        addPointsToTabelaFinal();

    }

    private void fillPointsTable() {
        this.pointsTable.addToRear(25);
        this.pointsTable.addToRear(18);
        this.pointsTable.addToRear(15);
        int i = 12;
        while (i >= 2) {
            this.pointsTable.addToRear(i);
            i = i - 2;
        }
        this.pointsTable.addToRear(1);
    }

    private void fillTabelaFinal(UnorderedListADT<Piloto> pilotos) {
        /*if (pilotos.size() != 10) {
            throw new Error();
        }*/

        for (int i = 0; i < this.amountOfPilots; i++) {
            //System.out.println(this.tabelaFinalUnordered.toString());
            Classificacao temp = new Classificacao(pilotos.removeFirst(), 0);
            this.tabelaFinalUnordered.addToRear(temp);
        }

        /*while (!(pilotos.isEmpty())) {
            Classificacao temp = new Classificacao(pilotos.removeFirst(), 0);
            this.tabelaFinalUnordered.addToRear(temp);
        }*/
    }

    private void addPointsToTabelaFinal() {
        while (!(this.prova.isEmpty())) {
            Piloto pilot = this.prova.removeFirst();
            int points;
            if (this.pointsTable.isEmpty()) {
                points = 0;
            } else {
                points = this.pointsTable.removeFirst();
            }
            //System.out.println("**********");
            //System.out.println(this.tabelaFinalUnordered.toString());
            for (int j = 0; j < this.amountOfPilots; j++) {
                Classificacao classi = this.tabelaFinalUnordered.removeFirst();
                //System.out.println(pilot.getName());
                //System.out.println(classi.getPiloto().getName());
                if (classi.getPiloto().getName().equals(pilot.getName())) {
                    classi.addPontos(points);
                    this.tabelaFinalUnordered.addToRear(classi);
                    break;
                } else {
                    //System.out.println(classi.toString());
                    this.tabelaFinalUnordered.addToRear(classi);
                }
            }
            //this.prova.addToRear(pilot);
        }

        this.fillPointsTable();
    }

    private void sort() {

        for (int i = 0; i < this.amountOfPilots; i++) {
            this.tabelaFinalOrdered.add(this.tabelaFinalUnordered.removeFirst());
        }
        this.sorted = true;
        /*while (!(this.tabelaFinalUnordered.isEmpty())) {
            this.tabelaFinalOrdered.add(this.tabelaFinalUnordered.removeFirst());
        }*/
    }

    public OrderedListADT<Classificacao> getTabelaFinalOrdered() {
        if (this.sorted == false) {
            sort();
        }
        return tabelaFinalOrdered;
    }

    public UnorderedListADT<Classificacao> getTabelaFinalUnordered() {
        return tabelaFinalUnordered;
    }

    public String FinalPole() {
        OrderedListADT<Classificacao> res = this.getTabelaFinalOrdered();
        String str = "";
        for (int i = 0; i < 3; i++) {
            Classificacao clas = this.getTabelaFinalOrdered().removeLast();
            str = str + (i + 1) + "º lugar" + ": " + clas.getPiloto().getName() + ", " + clas.getPiloto().getTeam().toString() + ", points: " + clas.getPontos() + "\n";
        }
        return str;
    }

}
