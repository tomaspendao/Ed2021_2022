/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Scenarios.F1;

/**
 *
 * @author tomaspendao
 */
public class Classificacao implements Comparable<Classificacao> {

    private Piloto piloto;
    private int pontos;

    public Classificacao(Piloto piloto, int pontos) {
        this.piloto = piloto;
        this.pontos = 0;
    }

    public Piloto getPiloto() {
        return piloto;
    }

    public int getPontos() {
        return pontos;
    }

    public void addPontos(int pontosToAdd) {
        this.pontos = this.pontos + pontosToAdd;
    }

    @Override
    public int compareTo(Classificacao classificacao) {
        if (this.pontos > classificacao.pontos) {
            return 1;
        } else if (this.pontos < classificacao.pontos) {
            return -1;
        }else {
            return 0;
        }
    }

    @Override
    public String toString() {
        return "Classificacao{" + "piloto=" + piloto + ", pontos=" + pontos + '}';
    }
    
    

}
