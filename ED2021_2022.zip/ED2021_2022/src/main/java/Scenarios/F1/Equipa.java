/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Scenarios.F1;

/**
 *
 * @author tomaspendao
 */
class Equipa {

    private String name;
    //private Piloto[] pilotos = new Piloto[2];

    public Equipa(String name) {
        this.name = name;
        //this.pilotos[0] = piloto1;
        // dthis.pilotos[1] = piloto2;
    }

    public String getName() {
        return name;
    }

    /*public Piloto[] getPilotos() {
        return pilotos;
    }*/

    @Override
    public String toString() {
        return this.getName();
    }
    
    
}
