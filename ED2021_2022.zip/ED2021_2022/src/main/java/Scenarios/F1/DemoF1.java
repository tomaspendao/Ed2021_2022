/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Scenarios.F1;

import ADT.UnorderedListADT;
import Collections.Array.ArrayUnorderedList;


/**
 *
 * @author tomaspendao
 */
public class DemoF1 {

    public static void main(String[] args) {
        Equipa mercedes = new Equipa("Mercedes");
        Piloto hamilton = new Piloto("Lewis Hamilton", mercedes);
        Piloto bottas = new Piloto("Valtteri Bottas", mercedes);

        Equipa redBull = new Equipa("Red Bull Racing");
        Piloto verstappen = new Piloto("Max Verstappen", redBull);
        Piloto perez = new Piloto("Sergio Perez", redBull);

        Equipa ferrari = new Equipa("Ferrari");
        Piloto sains = new Piloto("Carlos Sainz", ferrari);
        Piloto leclerc = new Piloto("Charles Leclerc", ferrari);

        Equipa mcLarren = new Equipa("McLarren");
        Piloto ricciardo = new Piloto("Daniel Ricciardo", mcLarren);
        Piloto norris = new Piloto("Lando Norris", mcLarren);

        Equipa alpine = new Equipa("Apline");
        Piloto ocon = new Piloto("Esteban Ocon", alpine);
        Piloto alonso = new Piloto("Fernando Alonso", alpine);

        Equipa alphaTauri = new Equipa("AlphaTauri");
        Piloto gasly = new Piloto("Pierre Gasly", alphaTauri);
        Piloto tsunoda = new Piloto("Yuki Tsunoda", alphaTauri);

        Equipa astonMartin = new Equipa("Aston Martin");
        Piloto vettel = new Piloto("Sebastian Vettel", astonMartin);
        Piloto stroll = new Piloto("Lance Stroll", astonMartin);

        Equipa williams = new Equipa("Williams");
        Piloto latifi = new Piloto("Nicholas Latifi", williams);
        Piloto russell = new Piloto("George Russell", williams);

        Equipa alfaRomeo = new Equipa("Alfa Romeo Racing");
        Piloto raikkonen = new Piloto("Kimi Raikkonen", alfaRomeo);
        Piloto giovinazzi = new Piloto("Antonio Giovinazzi", alfaRomeo);

        Equipa haas = new Equipa("Hass F1 Team");
        Piloto schumacher = new Piloto("Mick Schumacher", haas);
        Piloto mazepin = new Piloto("Nikita Mazepin", haas);
        
        UnorderedListADT<Piloto> pilotos = new ArrayUnorderedList<>();
        pilotos.addToFront(hamilton);
        pilotos.addToFront(bottas);
        pilotos.addToFront(gasly);
        pilotos.addToFront(giovinazzi);
        pilotos.addToFront(alonso);
        pilotos.addToFront(latifi);
        pilotos.addToFront(leclerc);
        pilotos.addToFront(mazepin);
        pilotos.addToFront(norris);
        pilotos.addToFront(ocon);
        pilotos.addToFront(perez);
        pilotos.addToFront(raikkonen);
        pilotos.addToFront(ricciardo);
        pilotos.addToFront(russell);
        pilotos.addToFront(sains);
        pilotos.addToFront(schumacher);
        pilotos.addToFront(stroll);
        pilotos.addToFront(tsunoda);
        pilotos.addToFront(verstappen);
        pilotos.addToFront(vettel);
        
        //System.out.println(pilotos.toString());

        PolePosition positions = new PolePosition(23, pilotos);
        System.out.println("RES:::::::");
        
        //System.out.println(positions.getTabelaFinalUnordered().toString());
        
        System.out.println(positions.getTabelaFinalOrdered().size());
        
        System.out.println(positions.getTabelaFinalOrdered().toString());
        
        System.out.println(positions.FinalPole());
    }
}
