/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Scenarios.ValidateXHTML;


import ADT.StackADT;
import ADT.UnorderedListADT;
import Collections.DoubleLinkedList.DoubleLinkedUnorderedList;
import Collections.LinkedList.LinkedStack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author tomaspendao
 */
public class ValidateXHTML {

    private String[] str;
    private StackADT<String> stack;
    private UnorderedListADT<String> validTags;

    public ValidateXHTML() {
        this.stack = new LinkedStack<>();
        this.validTags = new DoubleLinkedUnorderedList<>();
        //this.validate();
    }

    private boolean isTag(String string) {
        String regex = "(<.*>)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(string);
        //System.out.println(matcher.find() + " po1");
        return matcher.find() == true;
    }

    private boolean isClosingTag(String string) {
        //if (isTag(string) == true) {
        //System.out.println("ola?????");
        return string.contains("</");
        //} else {
        //    return false;
        //}
    }

    public boolean validate(String string) {
        this.str = string.split(" ");
        for (int i = 0; i < this.str.length; i++) {
            if (isTag(this.str[i])==true) {
                if (isClosingTag(this.str[i]) == false) {
                    String value = this.str[i].substring(1, this.str[i].length() - 1);
                    stack.push(value);
                } else {
                    String value = this.str[i].substring(2, this.str[i].length() - 1);                    
                    String valueToCompare = this.stack.peek();
                    if (value.equals(valueToCompare)) {
                        this.validTags.addToFront(this.stack.pop());
                    } else {
                        return false;
                    }
                }
            }
        }
        if(this.stack.isEmpty()== false){
            return false;
        }
        return true;
    }

}
