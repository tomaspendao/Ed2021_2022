/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Scenarios.ValidateXHTML;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author tomaspendao
 */
public class ValidateXHTMLDemo {

    public static void main(String[] args) {
        String string = "<body> \n"
                + " <h1> Titulo </h1> \n"
                + " <p> Corpo com <a> link </a> </p> \n"
                + " </body> ";

        String stringErr1 = "<body> \n"
                + " <h1> Titulo </h1> \n"
                + " <p> Corpo com <a> link </p> </a> \n"
                + " </body> ";
        String stringErr2 = "<body> \n"
                + " <h1> Titulo </h1> \n"
                + " <p> Corpo com <a> link </a> </p> ";

        String stringErr3 = "<body> \n"
                + " <h1> Titulo </h1> \n"
                + " <p> Corpo com <a> link </a> </p> \n"
                + " <body> ";

        ValidateXHTML xhtml = new ValidateXHTML();
        System.out.println(xhtml.validate(string));
        System.out.println(xhtml.validate(stringErr1));
        System.out.println(xhtml.validate(stringErr2));
        System.out.println(xhtml.validate(stringErr3));
    }
}
