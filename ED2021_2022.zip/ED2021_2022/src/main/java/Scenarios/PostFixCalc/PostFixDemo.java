/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Scenarios.PostFixCalc;

import java.util.Scanner;

/**
 *
 * @author tomaspendao
 */
public class PostFixDemo {

    private static int menu(Scanner in) {
        System.out.println("\t" + "CALCULADORA POSTFIX" + "\n"
        );

        System.out.println("1 - Calcular\n0 - Sair");
        System.out.print("Opção: ");

        int choice = in.nextInt();

        System.out.println();

        if (choice >= 0 && choice <= 2) {
            return choice;
        } else {
            System.out.println("Opção inválida\n");

            return choice;
        }
    }

    public static void main(String[] args) {
        PostFixCalcStack calculadora = new PostFixCalcStack(2);

        calculadora.calc("1 1 +");
        //System.out.println(calculadora.calc("1 1 + 2"));
        //System.out.println(calculadora.calc("+ + + +"));
        //System.out.println(calculadora.calc("1 -19 3"));
        //System.out.println(calculadora.calc("1 +"));
        System.out.println(calculadora.calc("7 4 -3 * 1 5 + / *"));

        Scanner in = new Scanner(System.in);

        boolean exit = false;

        while (!exit) {
            switch (menu(in)) {
                case 1:
                    System.out.println("--->Calculadora<---\n");

                    Scanner stringi = new Scanner(System.in);

                    System.out.print("Insira uma string (valores separados com strings): ");

                                       
                    String sStringi = stringi.nextLine();
                    System.out.println(sStringi);


                    float res = calculadora.calc(sStringi);
                    System.out.println("O resultado:" + res );

                    System.out.println();

                    break;
                case 0:
                    exit = true;

                    break;
            }
        }

    }

}
