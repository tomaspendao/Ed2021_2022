/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Scenarios.PostFixCalc;

import ADT.StackADT;
import Collections.Array.ArrayStack;
import Collections.LinkedList.LinkedStack;


/**
 *
 * @author tomaspendao
 */
public class PostFixCalcStack {

    private StackADT<Float> stack;

    public PostFixCalcStack(int NumeroSuperImportante) {
        this.stack = new ArrayStack<>();
    }

    public PostFixCalcStack() {
        this.stack = new LinkedStack<>();
    }

    public float calc(String str) {
        float result = 0;
        String[] splitStr = str.trim().split("\\s+");
        /*if(!(str.matches("\\[^0-9 ?!\"']"))){
            throw new Error("No operators");
        }*/
        if(splitStr.length < 3) {
            throw new Error("You need at least 2 numbers and one operator");
        }
        int flag = 0;
        for (int i = 0; i < splitStr.length; i++) {
            //System.out.println(this.stack.toString());
            float first, second;
            switch (splitStr[i]) {
                case "*":
                    if (this.stack.size() < 2) {
                        throw new Error("Not enought values set before");
                    }
                    second = this.stack.pop();
                    first = this.stack.pop();
                    result = first * second;
                    this.stack.push(result);
                    flag = 1;
                    break;
                case "/":
                    if (this.stack.size() < 2) {
                        throw new Error("Not enought values set before");
                    }
                    second = this.stack.pop();
                    first = this.stack.pop();
                    result = first / second;
                    this.stack.push(result);
                    flag = 1;
                    break;
                case "-":
                    if (this.stack.size() < 2) {
                        throw new Error("Not enought values set before");
                    }
                    second = this.stack.pop();
                    first = this.stack.pop();
                    result = first - second;
                    this.stack.push(result);
                    flag = 1;
                    break;
                case "+":
                    if (this.stack.size() < 2) {
                        throw new Error("Not enought values set before operator");
                    }
                    second = this.stack.pop();
                    first = this.stack.pop();
                    result = first + second;
                    this.stack.push(result);
                    flag = 1;
                    break;
                default:
                    //float value = Float.parseFloat(splitStr[i]);
                    float value = Float.valueOf(splitStr[i]);
                    this.stack.push(value);
                    flag = 0;
            }
        }
        if(flag==0){
            throw new Error("Last value was not an operator");
        }
        return stack.peek();
        //return result;
    }
}
