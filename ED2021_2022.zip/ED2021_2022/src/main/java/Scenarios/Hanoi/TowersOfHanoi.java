/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Scenarios.Hanoi;

/**
 *
 * @author tomaspendao
 */
class TowersOfHanoi {

    private int totalDisks;
    private int moves;

    /**
     * Sets up the puzzle with the specified number of disks.
     *
     * @param disks the number of disks to start the tower puzzle with
     */
    public TowersOfHanoi(int disks) {
        this.totalDisks = disks;
        this.moves=0;
    }

    /**
     * Performs the initial call to moveTower to solve the puzzle. Moves the
     * disks from tower 1 to tower 3 using tower 2.
     */
    public void solve() {
        moveTower(totalDisks, 1, 3, 2);
        System.out.println("Solved in "+  this.moves + " moves");
    }

    /**
     * Moves the specified number of disks from one tower to another by moving a
     * subtower of n-1 disks out of the way, moving one disk, then moving the
     * subtower back. Base case of 1 disk.
     *
     * @param numDisks the number of disks to move
     * @param start the starting tower
     * @param end the ending tower
     * @param temp the temporary tower
     */
    private void moveTower(int numDisks, int start,
            int end, int temp) {
        if (numDisks == 1) {
            moveOneDisk(start, end);
        } else {
            moveTower(numDisks - 1, start, temp, end);
            moveOneDisk(start, end);
            moveTower(numDisks - 1, temp, end, start);
        }
    }

    /**
     * Prints instructions to move one disk from the specified start tower to
     * the specified end tower.
     *
     * @param start the starting tower
     * @param end the ending tower
     */
    private void moveOneDisk(int start, int end) {
        System.out.println("Move one disk from " + start
                + " to " + end);
        this.moves++;
    }
}
