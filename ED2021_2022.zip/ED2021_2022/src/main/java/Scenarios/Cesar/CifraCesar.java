/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Scenarios.Cesar;

import ADT.QueueADT;
import Collections.Array.CircularArrayQueue;
import Collections.LinkedList.LinkedQueue;


/**
 *
 * @author tomaspendao
 */
public class CifraCesar {

    private QueueADT<Integer> keyQueue;

    public CifraCesar(int initial_size) {
        this.keyQueue = new CircularArrayQueue<>(initial_size);
        this.keyQueue.enqueue(3);
        this.keyQueue.enqueue(1);
        this.keyQueue.enqueue(7);
        this.keyQueue.enqueue(4);
        this.keyQueue.enqueue(2);
        this.keyQueue.enqueue(5);
    }

    public CifraCesar() {
        this.keyQueue = new LinkedQueue<>();
        //preencher a chave
        this.keyQueue.enqueue(3);
        this.keyQueue.enqueue(1);
        this.keyQueue.enqueue(7);
        this.keyQueue.enqueue(4);
        this.keyQueue.enqueue(2);
        this.keyQueue.enqueue(5);
    }

    public String codificar(String str) {

        String result = "";

        for (int i = 0; i < str.length(); i++) {
            int keyValue = this.keyQueue.dequeue();

            char asciiValue = str.charAt(i);
            String letter = "";
            if (asciiValue >= 97 && asciiValue <= 122) {
                letter = Character.toString(((asciiValue - 'a' + keyValue)%26)+'a');
            } else if (asciiValue >= 65 && asciiValue <= 90) {
                letter = Character.toString(((asciiValue - 'A' + keyValue)%26)+'A');
            } else if (asciiValue == 32){
                letter = " ";
            }
            result = result + letter;
            this.keyQueue.enqueue(keyValue);

        }

        return result;
    }

    public String descodificar(String str) {
        String result = "";
        
        for (int i = 0; i < str.length(); i++) {
            int keyValue = this.keyQueue.dequeue();

            char asciiValue = str.charAt(i);
            String letter = "";
            if (asciiValue >= 97 && asciiValue <= 122) {
                letter = Character.toString(((asciiValue - 'a' + 26 - keyValue)%26)+'a');
            } else if (asciiValue >= 65 && asciiValue <= 90) {
                letter = Character.toString(((asciiValue - 'A' + 26 - keyValue)%26)+'A');
            } else if (asciiValue == 32){
                letter = " ";
            }
            result = result + letter;
            this.keyQueue.enqueue(keyValue);
        }
        
        return result;
    }
}
