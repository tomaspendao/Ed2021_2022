/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Scenarios.Cesar;

/**
 *
 * @author tomaspendao
 */
public class CifraCesarDemo {
    public static void main(String[] args) {
        CifraCesar cesarao = new CifraCesar();
        
        String str = "Knowledge Is Power";
        
        String coded = cesarao.codificar(str);
        
        System.out.println(coded);
        
        System.out.println(cesarao.descodificar(coded));
        
    }
}
