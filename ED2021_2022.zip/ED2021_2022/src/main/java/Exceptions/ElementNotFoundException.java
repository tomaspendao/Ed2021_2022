/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exceptions;

/**
 *
 * @author tomaspendao
 */
public class ElementNotFoundException extends RuntimeException
{
    /**
     * Sets up this exception with an appropriate message.
     * @param element the name of the element
     */
    public ElementNotFoundException(String element)
    {
        super("The " + element + " was not found.");
    }
}
