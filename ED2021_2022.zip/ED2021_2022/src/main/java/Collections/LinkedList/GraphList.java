/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Collections.LinkedList;

import ADT.GraphADT;
import ADT.StackADT;
import ADT.UnorderedListADT;
import Collections.Array.ArrayUnorderedList;
import Collections.Array.GraphMatrix;
import Collections.DoubleLinkedList.DoubleLinkedUnorderedList;
import Exceptions.ElementNotFoundException;
import Exceptions.EmptyCollectionException;
import Models.Nodes.ArestaWeightless;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author tomaspendao
 */
public class GraphList<T> implements GraphADT<T>{
    private final int DEFAULT_CAPACITY = 5;

    private int numVertices;

    private DoubleLinkedUnorderedList<ArestaWeightless>[] adjList;

    private T[] vertices;
    
    public GraphList() {
        this.adjList = new DoubleLinkedUnorderedList[DEFAULT_CAPACITY];
        this.numVertices = 0;
        this.vertices = (T[]) new Object[DEFAULT_CAPACITY];
    }

    @Override
    public void addVertex(T vertex) {
        if (this.numVertices == this.vertices.length) {
            this.expandCapacity();
        }
        this.vertices[this.numVertices] = vertex;
        for (int i = 0; i <= this.numVertices; i++) {
            this.adjList[i] = new DoubleLinkedUnorderedList<>();
            //this.adjMatrix[this.numVertices][i] = false;
            //this.adjMatrix[i][this.numVertices] = false;
        }
        this.numVertices++;
    }

    @Override
    public void removeVertex(T vertex) {
        int pos = -1;
        int i = 0;
        while (i < this.numVertices || pos == -1) {
            if (this.vertices[i].equals(vertex)) {
                pos = i;
            }
            i++;
        }
        if (pos == -1) {
            throw new EmptyCollectionException("Vazio");
        }
        this.vertices[pos] = null;
        for (int j = pos + 1; j < this.numVertices; j++) {
            this.vertices[j - 1] = this.vertices[j];
        }
        for (int k = pos + 1; k < this.numVertices; k++) {
            this.adjList[k-1] = this.adjList[k];
            /*for (int m = 0; m < pos; m++) {
                this.adjMatrix[m][k - 1] = this.adjMatrix[m][k];
            }*/
        }
        //remover arestas noutros vertice com destino o vertice removido
        for (int j = 0; j < this.numVertices; j++) {
            UnorderedListADT tempList = this.adjList[j];
            while(tempList.isEmpty() == false){
                ArestaWeightless tempAresta = (ArestaWeightless)tempList.removeFirst();
                if(tempAresta.getTarget() == pos){
                    this.adjList[j].remove(tempAresta);
                }
            }
        }
        /*for (int x = pos + 1; x < this.numVertices; x++) {
            for (int m = 0; m < pos; m++) {
                this.adjMatrix[x - 1][m] = this.adjMatrix[x][m];
            }
        }
        for (int y = pos + 1; y < this.numVertices; y++) {
            for (int m = pos + 1; m < this.numVertices; m++) {
                this.adjMatrix[m - 1][y - 1] = this.adjMatrix[m][y];
            }
        }*/
        this.numVertices--;
    }

    @Override
    public void addEdge(T vertex1, T vertex2) {
        addEdge(getIndex(vertex1), getIndex(vertex2));
    }

    public void addEdge(int index1, int index2) {
        if (indexIsValid(index1) && indexIsValid(index2)) {
            ArestaWeightless newArestaFrom = new ArestaWeightless(index1, index2);
            ArestaWeightless newArestaTo = new ArestaWeightless(index2, index1);
            this.adjList[index1].addToRear(newArestaFrom);
            this.adjList[index2].addToRear(newArestaTo);
        }
    }

    @Override
    public void removeRedge(T vertex1, T vertex2) {
        int pos1 = -1, pos2 = -1;
        for (int i = 0; i < this.numVertices; i++) {
            if (this.vertices[i].equals(vertex1)) {
                pos1 = i;
            } else if (this.vertices[i].equals(vertex2)) {
                pos2 = i;
            }
        }
        if (pos1 == -1 || pos2 == -1) {
            throw new ElementNotFoundException("Not Found");
        }
        ArestaWeightless arestaToRemove1 = new ArestaWeightless(pos1, pos2);
        ArestaWeightless arestaToRemove2 = new ArestaWeightless(pos2, pos1);
        if(this.adjList[pos1].contains(arestaToRemove1)){
            System.out.println("aresta: " + arestaToRemove1.getStart() + ";" + arestaToRemove1.getTarget());
            this.adjList[pos1].remove(arestaToRemove1);
        } else if(this.adjList[pos2].contains(arestaToRemove2)){
            this.adjList[pos2].remove(arestaToRemove2);
        }
    }

    @Override
    public Iterator iteratorBFS(T startVertex) {
        return iteratorBFS(getIndex(startVertex));
    }

    private Iterator iteratorBFS(int startIndex) {
        int x = 0;
        LinkedQueue<Integer> traversalQueue = new LinkedQueue<>();
        ArrayUnorderedList<T> resultList = new ArrayUnorderedList<>();
        if (!this.indexIsValid(startIndex)) {
            return resultList.iterator();
        }
        boolean[] visited = new boolean[this.numVertices];
        int i;
        for (i = 0; i < this.numVertices; i++) {
            visited[i] = false;
        }
        traversalQueue.enqueue(Integer.valueOf(startIndex));
        visited[startIndex] = true;
        while (!traversalQueue.isEmpty()) {
            try {
                x = ((Integer) traversalQueue.dequeue()).intValue();
            } catch (EmptyCollectionException ex) {
                Logger.getLogger(GraphMatrix.class.getName()).log(Level.SEVERE, (String) null, (Throwable) ex);
            }
            resultList.addToRear(this.vertices[x]);
            for (i = 0; i < this.numVertices; i++) {
                if (this.adjList[x].contains(new ArestaWeightless(x, i)) && !visited[i]) {
                    traversalQueue.enqueue(Integer.valueOf(i));
                    visited[i] = true;
                }
            }
        }
        return resultList.iterator();

    }

    @Override
    public Iterator iteratorDFS(T startVertex) {
        return iteratorDFS(getIndex(startVertex));
    }

    private Iterator iteratorDFS(int startIndex) {
        StackADT<Integer> traversalStack = new LinkedStack<>();
        ArrayUnorderedList<T> resultList = new ArrayUnorderedList<>();
        boolean[] visited = new boolean[this.numVertices];
        if (!indexIsValid(startIndex)) {
            return resultList.iterator();
        }
        int i;
        for (i = 0; i < this.numVertices; i++) {
            visited[i] = false;
        }
        traversalStack.push(Integer.valueOf(startIndex));
        resultList.addToRear(this.vertices[startIndex]);
        visited[startIndex] = true;
        while (!traversalStack.isEmpty()) {
            try {
                Integer x = (Integer) traversalStack.peek();
                boolean found = false;
                for (i = 0; i < this.numVertices && !found; i++) {
                    if (this.adjList[x.intValue()].contains(new ArestaWeightless(x.intValue(), i)) && !visited[i]) {
                        traversalStack.push(Integer.valueOf(i));
                        resultList.addToRear(this.vertices[i]);
                        visited[i] = true;
                        found = true;
                    }
                }
                if (!found && !traversalStack.isEmpty()) {
                    traversalStack.pop();
                }
            } catch (EmptyCollectionException ex) {
                Logger.getLogger(GraphMatrix.class.getName()).log(Level.SEVERE, (String) null, (Throwable) ex);
            }
        }
        return resultList.iterator();
    }

    @Override
    public Iterator iteratorShortestPath(T startVertex, T targetVertex) {
        Integer[] x = null;
        int previous = -1;
        LinkedQueue<Integer[]> traversalQueue = (LinkedQueue) new LinkedQueue<>();
        ArrayUnorderedList<T> resultList = new ArrayUnorderedList<>();
        ArrayUnorderedList<Integer[]> tempresultList = (ArrayUnorderedList) new ArrayUnorderedList<>();
        int src = this.getIndex(startVertex);
        int dest = this.getIndex(targetVertex);
        if (!indexIsValid(src)) {
            return resultList.iterator();
        }
        boolean[] visited = new boolean[this.numVertices];
        for (int i = 0; i < this.numVertices; i++) {
            visited[i] = false;
        }
        Integer[] fl = {Integer.valueOf(previous), Integer.valueOf(src)};
        traversalQueue.enqueue(fl);
        visited[src] = true;
        boolean reachDestination = false;
        while (!traversalQueue.isEmpty() && !reachDestination) {
            try {
                x = traversalQueue.dequeue();
            } catch (EmptyCollectionException ex) {
                Logger.getLogger(GraphMatrix.class.getName()).log(Level.SEVERE, (String) null, (Throwable) ex);
            }
            tempresultList.addToRear(x);
            if (x[1].intValue() == dest) {
                reachDestination = true;
                continue;
            }
            for (int j = 0; j < this.numVertices; j++) {
                if (this.adjList[x[1].intValue()].contains(new ArestaWeightless(x[1].intValue(), j)) && !visited[j]) {
                    Integer[] d = {x[1], Integer.valueOf(j)};
                    traversalQueue.enqueue(d);
                    visited[j] = true;
                }
            }
        }
        previous = -1;
        while (tempresultList.size() != 0) {
            try {
                Integer[] temp = tempresultList.removeLast();
                if (resultList.size() == 0) {
                    resultList.addToFront(this.vertices[temp[1].intValue()]);
                    previous = temp[0].intValue();
                    continue;
                }
                if (temp[1].intValue() == previous) {
                    previous = temp[0].intValue();
                    resultList.addToFront(this.vertices[temp[1].intValue()]);
                }
            } catch (EmptyCollectionException ex) {
                Logger.getLogger(GraphMatrix.class.getName()).log(Level.SEVERE, (String) null, (Throwable) ex);
            }
        }
        return resultList.iterator();
    }

    @Override
    public boolean isEmpty() {
        return (this.numVertices == 0);
    }

    @Override
    public boolean isConnected() {
        int i = 0;
        boolean cont = true;
        while (cont && i < this.numVertices) {
            int x = 0;
            Iterator<T> temp = iteratorBFS(i);
            while (temp.hasNext()) {
                x++;
                temp.next();
            }
            if (x != this.numVertices) {
                cont = false;
            }
            i++;
        }
        return cont;
    }

    @Override
    public int size() {
        return this.numVertices;
    }
    
    public void expandCapacity() {
        T[] larger = (T[]) new Object[this.vertices.length * 2];
        for (int i = 0; i < this.vertices.length; i++) {
            larger[i] = this.vertices[i];
        }
        DoubleLinkedUnorderedList<ArestaWeightless>[] adjListlarger = new DoubleLinkedUnorderedList[this.vertices.length * 2];
        for (int j = 0; j < this.vertices.length; j++) {
            adjListlarger[j] = this.adjList[j];
        }
        this.adjList = adjListlarger;
        this.vertices = larger;
    }
    
    public boolean indexIsValid(int index) {
        if (index < 0 || index >= this.numVertices) {
            return false;
        }
        return true;
    }
    
    public int getIndex(T vertex1) {
        int i = 0;
        int pos = -1;
        while (pos == -1 && i < this.numVertices) {
            if (this.vertices[i].equals(vertex1)) {
                pos = i;
            }
            i++;
        }
        return pos;
    }
}
