/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.LinkedList;

import ADT.BinarySearchTreeADT;
import Exceptions.ElementNotFoundException;
import Exceptions.EmptyCollectionException;
import Models.Nodes.BinaryTreeNode;

/**
 *
 * @author tomaspendao
 */
public class LinkedBinarySearchTree<T> extends LinkedBinaryTree<T> implements BinarySearchTreeADT<T> {

    /**
     * Creates an empty binary search tree.
     */
    public LinkedBinarySearchTree() {
        super();
    }

    /**
     * Creates a binary search with the specified element as its root.
     *
     *
     * @param element the element that will be the root of the new binary search
     * tree
     */
    public LinkedBinarySearchTree(T element) {
        super(element);
    }

    /**
     * Adds the specified object to the binary search tree in the appropriate
     * position according to its key value. Note that equal elements are added
     * to the right.
     *
     * @param element the element to be added to the binary search * tree
     */
    @Override
    public void addElement(T element) {
        BinaryTreeNode<T> temp = new BinaryTreeNode<>(element);
        Comparable<T> comparableElement = (Comparable<T>) element;

        if (isEmpty()) {
            super.root = temp;
        } else {
            BinaryTreeNode<T> current = super.root;
            boolean added = false;
            while (!added) {
                if (comparableElement.compareTo(current.getElement()) < 0) {
                    if (current.getLeft() == null) {
                        current.setLeft(temp);
                        added = true;
                    } else {
                        current = current.getLeft();
                    }
                } else {
                    if (current.getRight() == null) {
                        current.setRight(temp);
                        added = true;
                    } else {
                        current = current.getRight();
                    }
                }
            }
        }
        super.count++;
    }

    /**
     * Removes the first element that matches the specified target element from
     * the binary search tree and returns a reference to it. Throws a
     * ElementNotFoundException if the specified target element is not found in
     * the binary search tree.
     *
     * @param targetElement the element being sought in the binary * search tree
     * @throws ElementNotFoundException if an element not found exception occurs
     */
    @Override
    public T removeElement(T targetElement) {
        T result = null;
        if (!isEmpty()) {
            if (((Comparable) targetElement).equals(super.getRoot())) {
                result = super.getRoot();
                super.root = this.replacement(root);
                super.count--;
            } else {
                BinaryTreeNode<T> current, parent = super.root;
                boolean found = false;
                if (((Comparable) targetElement).compareTo(super.getRoot()) < 0) {
                    current = super.root.getLeft();
                } else {
                    current = super.root.getRight();
                }
                while (current != null && !found) {
                    if (targetElement.equals(current.getElement())) {
                        found = true;
                        super.count--;
                        result = current.getElement();

                        if (current == parent.getLeft()) {
                            parent.setLeft(this.replacement(current));
                        } else {
                            parent.setRight(this.replacement(current));
                        }
                    } else {
                        parent = current;
                        if (((Comparable) targetElement).compareTo(current.getElement()) < 0) {
                            current = current.getLeft();
                        } else {
                            current = current.getRight();
                        }
                    }

                }//while
                if (!found) {
                    throw new ElementNotFoundException("binary search tree");
                }
            }

        }//end outre if
        return result;
    }

    @Override
    public void removeAllOccurrences(T targetElement) {
        boolean toRemove = true;
        while (toRemove == true) {
            try {
                if (removeElement(targetElement) != null) {
                    toRemove = true;
                }
            } catch (ElementNotFoundException ex) {
                toRemove = false;
            }
        }
    }

    @Override
    public T removeMin() {
        T result;
        if (super.root == null) {
            throw new EmptyCollectionException("Linked Binary search tree - removeMin");
        }
        if (super.root.getLeft() == null) {
            result = super.getRoot();
            BinaryTreeNode<T> right = super.root.getRight();
            super.root.setRight(null);
            super.root = right;
        } else {
            BinaryTreeNode<T> current = super.root.getLeft();
            BinaryTreeNode<T> parent = super.root;
            while (current.getLeft() != null) {
                parent = current;
                current = current.getLeft();
            }
            result = current.getElement();
            if (current.getRight() == null) {
                parent.setLeft(null);
            } else {
                parent.setLeft(current.getRight());
                current.setRight(null);
            }
        }
        return result;
    }

    @Override
    public T removeMax() {
        T result;
        if (super.root == null) {
            throw new EmptyCollectionException("Linked Binary Search tree - removeMax");
        }
        if (super.root.getRight() == null) {
            result = super.root.getElement();
            BinaryTreeNode<T> left = super.root.getLeft();
            super.root.setLeft(null);
            super.root = left;
        } else {
            BinaryTreeNode<T> current = super.root.getRight();
            BinaryTreeNode<T> parent = super.root;
            while (current.getRight() != null) {
                parent = current;
                current = current.getRight();
            }
            result = current.getElement();
            if (current.getLeft() == null) {
                parent.setRight(null);
            } else {
                parent.setRight(current.getLeft());
                current.setLeft(null);
            }
        }
        return result;
    }

    @Override
    public T findMin() {
        BinaryTreeNode<T> current = super.root;
        while (current.getLeft() != null) {
            current = current.getLeft();
        }
        return current.getElement();
    }

    @Override
    public T findMax() {
        BinaryTreeNode<T> current = super.root;
        while (current.getRight() != null) {
            current = current.getRight();
        }
        return current.getElement();
    }

    /**
     * Returns a reference to a node that will replace the one specified for
     * removal. In the case where the removed node has two children, the inorder
     * successor is used as its replacement.
     *
     *
     * @param node the node to be removed
     * @return a reference to the replacing node
     */
    private BinaryTreeNode<T> replacement(BinaryTreeNode<T> node) {
        BinaryTreeNode<T> result = null;
        if ((node.getLeft() == null) && (node.getRight() == null)) {
            result = null;
        } else if ((node.getLeft() != null) && (node.getRight() == null)) {
            result = node.getLeft();
        } else if ((node.getLeft() == null) && (node.getRight() != null)) {
            result = node.getRight();
        } else {
            BinaryTreeNode<T> current = node.getRight();
            BinaryTreeNode<T> parent = node;
            while (current.getLeft() != null) {
                parent = current;
                current = current.getLeft();
            }
            if (node.getRight() == current) {
                current.setLeft(node.getLeft());
            } else {
                parent.setLeft(current.getRight());
                current.setRight(node.getRight());
                current.setLeft(node.getLeft());
            }
            result = current;
        }
        return result;
    }

}
