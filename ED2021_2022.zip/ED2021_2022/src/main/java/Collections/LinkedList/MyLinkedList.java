/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.LinkedList;

import Models.Nodes.MyLinearNode;

/**
 *
 * @author tomaspendao
 */
public class MyLinkedList<T> {

    protected MyLinearNode<T> head;
    private int size;

    public MyLinkedList() {
        this.head = new MyLinearNode<>();
        this.size = 0;
    }

    public MyLinkedList(T elem) {
        this.head = new MyLinearNode<>(elem);
        this.size = 1;
    }

    public void add(T elem) {
        MyLinearNode<T> temp = new MyLinearNode<>(elem);
        temp.setNext(this.getHead());
        this.setHead(temp);
        this.size++;
    }

    public void printAll() {
        MyLinearNode node = this.getHead();
        while (node != null) {
            System.out.println(node.getValue());
            node = node.getNext();
        }
    }

    public void remove() {
        if (head == null) {
            return;
        }
        setHead(getHead().getNext());
        this.size--;
    }

    public void remove(MyLinearNode node) {
        if (head == null) {
            return;
        }
        MyLinkedList removed = new MyLinkedList();
        MyLinearNode current = this.getHead();
        for (int i = 0; i < this.getSize(); i++) {
            if (current.getValue().equals(node.getValue())) {
                this.remove();
            } else {
                removed.add(current.getValue());
                this.remove();
                current = current.getNext();
            }
        }
        MyLinearNode removedCurr = removed.getHead();
        for (int i = 0; i < removed.size; i++) {
            this.add((T) removedCurr.getValue());
            removedCurr = removedCurr.getNext();
        }

        this.size--;
    }

    public int getSize() {
        return size;
    }

    public MyLinearNode<T> getHead() {
        return head;
    }

    public void setHead(MyLinearNode<T> head) {
        this.head = head;
    }

    public void recursivePrintAll(MyLinearNode node) {
        if (node == null) {
            System.out.println("");
            return;
        } else {
            System.out.print(node.getValue() + " ");
            recursivePrintAll(node.getNext());
            //System.out.print(node.getValue() + " ");
        }
    }

    public void recursiveInvertedPrintAll(MyLinearNode node) {
        if (node == null) {
            System.out.println("");
            return;
        } else {
            //System.out.print(node.getValue() + " ");
            recursiveInvertedPrintAll(node.getNext());
            System.out.print(node.getValue() + " ");
        }
    }

    public void recursiveReverse() {
        int tam = this.size;
        this.recursiveReverseHelper(this.head, tam);
        MyLinearNode<T> temp = this.getHead();
        for (int i = 0; i < this.size - 1; i++) {
            temp = temp.getNext();
        }
        this.setHead(temp);
    }

    private void recursiveReverseHelper(MyLinearNode node, int size) {
        if (size == 0) {
            System.out.println("");
            return;
        } else {
            T value = this.head.getValue();
            this.remove();
            recursiveReverseHelper(node.getNext(), size - 1);
            this.add(value);

        }
    }
}
