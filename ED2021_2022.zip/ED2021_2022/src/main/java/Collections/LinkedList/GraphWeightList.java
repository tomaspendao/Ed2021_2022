/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt
 * to change this license Click
 * nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this
 * template
 */
package Collections.LinkedList;

import ADT.GraphADT;
import ADT.StackADT;
import ADT.UnorderedListADT;
import Collections.Array.ArrayUnorderedList;
import Collections.Array.GraphMatrix;
import Collections.DoubleLinkedList.DoubleLinkedUnorderedList;
import Exceptions.ElementNotFoundException;
import Exceptions.EmptyCollectionException;
import Models.Nodes.ArestaWeight;
import Models.Nodes.HeapNode;
import Models.Nodes.Vertex;
import java.util.Comparator;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Tomás Pendão
 */
public class GraphWeightList<T> implements GraphADT<T> {

    private final int DEFAULT_CAPACITY = 5;
    private final int DEFAULT_WEIGHT = -999;

    private int numVertices;

    private DoubleLinkedUnorderedList<ArestaWeight>[] adjList;

    private T[] vertices;

    public GraphWeightList() {
        this.adjList = new DoubleLinkedUnorderedList[DEFAULT_CAPACITY];
        this.numVertices = 0;
        this.vertices = (T[]) new Object[DEFAULT_CAPACITY];
    }

    @Override
    public void addVertex(T vertex) {
        if (this.numVertices == this.vertices.length) {
            this.expandCapacity();
        }
        this.vertices[this.numVertices] = vertex;
        for (int i = 0; i <= this.numVertices; i++) {
            this.adjList[i] = new DoubleLinkedUnorderedList<>();
            // this.adjMatrix[this.numVertices][i] = false;
            // this.adjMatrix[i][this.numVertices] = false;
        }
        this.numVertices++;
    }

    @Override
    public void removeVertex(T vertex) {
        int pos = -1;
        int i = 0;
        while (i < this.numVertices || pos == -1) {
            if (this.vertices[i].equals(vertex)) {
                pos = i;
            }
            i++;
        }
        if (pos == -1) {
            throw new EmptyCollectionException("Vazio");
        }
        this.vertices[pos] = null;
        for (int j = pos + 1; j < this.numVertices; j++) {
            this.vertices[j - 1] = this.vertices[j];
        }
        for (int k = pos + 1; k < this.numVertices; k++) {
            this.adjList[k - 1] = this.adjList[k];
            /*for (int m = 0; m < pos; m++) {
          this.adjMatrix[m][k - 1] = this.adjMatrix[m][k];
      }*/
        }
        // remover arestas noutros vertice com destino o vertice removido
        for (int j = 0; j < this.numVertices; j++) {
            UnorderedListADT tempList = this.adjList[j];
            while (tempList.isEmpty() == false) {
                ArestaWeight tempAresta = (ArestaWeight) tempList.removeFirst();
                if (tempAresta.getTarget() == pos) {
                    this.adjList[j].remove(tempAresta);
                }
            }
        }
        /*for (int x = pos + 1; x < this.numVertices; x++) {
        for (int m = 0; m < pos; m++) {
            this.adjMatrix[x - 1][m] = this.adjMatrix[x][m];
        }
    }
    for (int y = pos + 1; y < this.numVertices; y++) {
        for (int m = pos + 1; m < this.numVertices; m++) {
            this.adjMatrix[m - 1][y - 1] = this.adjMatrix[m][y];
        }
    }*/
        this.numVertices--;
    }

    @Override
    public void addEdge(T vertex1, T vertex2) {
        addEdge(getIndex(vertex1), getIndex(vertex2), this.DEFAULT_WEIGHT);
    }

    public void addEdge(T vertex1, T vertex2, float weight) {
        // System.out.println("equals:::::::::" + this.vertices[0].equals(vertex1));
        // System.out.println("exists2:::::::::" +
        // this.indexIsValid(this.getIndex(vertex1))); System.out.println("step
        // 1:::");
        addEdge(getIndex(vertex1), getIndex(vertex2), weight);
    }

    public void addEdge(int index1, int index2, float weight) {
        if (indexIsValid(index1) && indexIsValid(index2)) {
            ArestaWeight newArestaFrom = new ArestaWeight(index1, index2, weight);
            ArestaWeight newArestaTo = new ArestaWeight(index2, index1, weight);

            if (!this.checkIfEdgeExists(index1, index2, weight)) {
//                System.out.println("addEdge:" + this.vertices[index1] + " => "
//                        + this.vertices[index2]);
                this.adjList[index1].addToRear(newArestaFrom);
            }

            if (!this.checkIfEdgeExists(index2, index1, weight)) {
//                System.out.println("addEdge:" + this.vertices[index2] + " => "
//                        + this.vertices[index1]);
                this.adjList[index2].addToRear(newArestaTo);
            }

            //System.out.println("adjList: " + this.adjList.length);
            // return true;
        }
        // return false;
    }

    private boolean checkIfEdgeExists(int index1, int index2, float weight) {
        //return false;
        if (!indexIsValid(index1) || !indexIsValid(index2)) {
            return false;
        }

        Iterator<ArestaWeight> arestaIter = this.adjList[index1].iterator();

        while (arestaIter.hasNext()) {
            ArestaWeight value = (ArestaWeight) arestaIter.next();

            if (value.getTarget() == index2) {
                value.setWeight(weight);
                return true;
            }
        }

        return false;
    }

    @Override
    public void removeRedge(T vertex1, T vertex2) {
        int pos1 = -1, pos2 = -1;
        for (int i = 0; i < this.numVertices; i++) {
            if (this.vertices[i].equals(vertex1)) {
                pos1 = i;
            } else if (this.vertices[i].equals(vertex2)) {
                pos2 = i;
            }
        }
        if (pos1 == -1 || pos2 == -1) {
            throw new ElementNotFoundException("Not Found");
        }
        ArestaWeight arestaToRemove1 = new ArestaWeight(
                pos1, pos2, this.DEFAULT_WEIGHT); // O weight não innteressa
        ArestaWeight arestaToRemove2
                = new ArestaWeight(pos2, pos1, this.DEFAULT_WEIGHT);
        if (this.adjList[pos1].contains(arestaToRemove1)) {
//            System.out.println("aresta: " + arestaToRemove1.getStart() + ";"
//                    + arestaToRemove1.getTarget());
            this.adjList[pos1].remove(arestaToRemove1);
        } else if (this.adjList[pos2].contains(arestaToRemove2)) {
            this.adjList[pos2].remove(arestaToRemove2);
        }
    }

    @Override
    public Iterator iteratorBFS(T startVertex) {
        return iteratorBFS(getIndex(startVertex));
    }

    private Iterator iteratorBFS(int startIndex) {
        int x = 0;
        LinkedQueue<Integer> traversalQueue = new LinkedQueue<>();
        ArrayUnorderedList<T> resultList = new ArrayUnorderedList<>();
        if (!this.indexIsValid(startIndex)) {
            return resultList.iterator();
        }
        boolean[] visited = new boolean[this.numVertices];
        int i;
        for (i = 0; i < this.numVertices; i++) {
            visited[i] = false;
        }
        traversalQueue.enqueue(Integer.valueOf(startIndex));
        visited[startIndex] = true;
        while (!traversalQueue.isEmpty()) {
            try {
                x = ((Integer) traversalQueue.dequeue()).intValue();
            } catch (EmptyCollectionException ex) {
                Logger.getLogger(GraphMatrix.class.getName())
                        .log(Level.SEVERE, (String) null, (Throwable) ex);
            }
            resultList.addToRear(this.vertices[x]);
            for (i = 0; i < this.numVertices; i++) {
                if (this.adjList[x].contains(new ArestaWeight(x, i)) && !visited[i]) {
                    traversalQueue.enqueue(Integer.valueOf(i));
                    visited[i] = true;
                }
            }
        }
        return resultList.iterator();
    }

    @Override
    public Iterator iteratorDFS(T startVertex) {
        return iteratorDFS(getIndex(startVertex));
    }

    private Iterator iteratorDFS(int startIndex) {
        StackADT<Integer> traversalStack = new LinkedStack<>();
        ArrayUnorderedList<T> resultList = new ArrayUnorderedList<>();
        boolean[] visited = new boolean[this.numVertices];
        if (!indexIsValid(startIndex)) {
            return resultList.iterator();
        }
        int i;
        for (i = 0; i < this.numVertices; i++) {
            visited[i] = false;
        }
        traversalStack.push(Integer.valueOf(startIndex));
        resultList.addToRear(this.vertices[startIndex]);
        visited[startIndex] = true;
        while (!traversalStack.isEmpty()) {
            try {
                Integer x = (Integer) traversalStack.peek();
                boolean found = false;
                for (i = 0; i < this.numVertices && !found; i++) {
                    if (this.adjList[x.intValue()].contains(
                            new ArestaWeight(x.intValue(), i))
                            && !visited[i]) {
                        traversalStack.push(Integer.valueOf(i));
                        resultList.addToRear(this.vertices[i]);
                        visited[i] = true;
                        found = true;
                    }
                }
                if (!found && !traversalStack.isEmpty()) {
                    traversalStack.pop();
                }
            } catch (EmptyCollectionException ex) {
                Logger.getLogger(GraphMatrix.class.getName())
                        .log(Level.SEVERE, (String) null, (Throwable) ex);
            }
        }
        return resultList.iterator();
    }

    @Override
    public Iterator iteratorShortestPath(T startVertex, T targetVertex) {
        int start = this.getIndex(startVertex);
        int target = this.getIndex(targetVertex);

//        System.out.print("start: " + start + "@" + startVertex.toString()
//                + " -> target: " + target + "@" + targetVertex.toString());

        // int iteration=0;
        StackADT<Integer> unsetted = new LinkedStack<>();
        DoubleLinkedUnorderedList<Integer> settled
                = new DoubleLinkedUnorderedList<>();

        Vertex[] distance = new Vertex[this.numVertices];

        for (int i = 0; i < distance.length; i++) {
            distance[i] = new Vertex(-1, Float.POSITIVE_INFINITY);
        }
        distance[start] = new Vertex(start, 0); // já está lá

        unsetted.push(start); // adicionar start
        int evaluationNode = start;
        //System.out.println("Conectividade:" + this.isConnected());
        if (this.isConnected() == false) {
            throw new ElementNotFoundException("Graph is not Connected");
        }

        while (unsetted.isEmpty() != true) {
            try {
                int l = unsetted.peek(); // primeira da stack unsetted
                //System.out.println("\t o meu l:" + l);

                // for (int i = 0; i < this.adjList[l].size(); i++) { //que moca (facepalm)
                Iterator iter = this.adjList[l].iterator();
                boolean flag = false;
                while (iter.hasNext()) {
                    ArestaWeight value = (ArestaWeight) iter.next();

//                    System.out.println("neighbour: " + value.getStart() + " "
//                            + this.vertices[value.getStart()]
//                            + " => target: " + value.getTarget() + " "
//                            + this.vertices[value.getTarget()]);

                    if (distance[value.getTarget()].getWeight()
                            == Float.POSITIVE_INFINITY) { // se for infinito
                        distance[value.getTarget()]
                                = new Vertex(value.getStart(), value.getWeight());
                    } else {
                        float currentWeight = distance[value.getTarget()].getWeight();
                        float newWeight
                                = distance[value.getStart()].getWeight() + value.getWeight();
                        if (newWeight < currentWeight) {
                            distance[value.getTarget()]
                                    = new Vertex(value.getStart(), newWeight);
                        }
                    }
                    if (flag == false) {
                        settled.addToRear(unsetted.pop());
                        flag = true;
                    }
                    if (!(settled.contains(value.getTarget()))) {
                        unsetted.push(value.getTarget());
                    }
                    // System.out.println("unsetted:" + unsetted.toString());
                    // System.out.println("settled:" + settled.toString());
                }
                // }
            } catch (EmptyCollectionException ex) {
                // System.out.println("EmptyCollectionException");
                continue;
            }
        }

//        System.out.println("PASSOU A 1ª Fase");
//        for (int i = 0; i < distance.length; i++) {
//
//            System.out.print(distance[i].getValue());
//            System.out.print("\t" + distance[i].getWeight() + "\t");
//            System.out.println(this.vertices[i].toString());
//        }

        StackADT<Integer> res = new LinkedStack<>();

        int temp = target;
        res.push(target);
        boolean flag = false;
        int i = 0;
        float dist = 0;
        while (flag != true || i <= distance.length) {
            dist = dist + distance[temp].getWeight();
            if (temp == start) {
                flag = true;
                break;
            }
            temp = distance[temp].getValue();
            res.push(temp);
            i++;
        }
        //        System.out.println("distancia total:" + dist);
        DoubleLinkedUnorderedList<T> finalRes = new DoubleLinkedUnorderedList<>();
        while (res.isEmpty() == false) {
            finalRes.addToRear(
                    this.getVertice(res.pop())); // passar o index para a vertice
        }

        return finalRes.iterator();
    }

    public float getTripWeight(Iterator iterator) {
        float res = 0;
        Object start, target = null;
        if (iterator.hasNext()) {
            start = iterator.next();
        } else {
            throw new ElementNotFoundException(".next()");
        }
        while (iterator.hasNext()) {
            target = iterator.next();

            int indexStart = this.getIndexFromString(start.toString());
            int indexTarget = this.getIndexFromString(target.toString());

            Iterator<ArestaWeight> iter = this.adjList[indexStart].iterator();

            while (iter.hasNext()) {
                ArestaWeight value = (ArestaWeight) iter.next();
                if (value.getTarget() == indexTarget) {
                    res = res + value.getWeight();
                    break;
                }
            }

            start = target;
        }

        return res;
    }

    @Override
    public boolean isEmpty() {
        return (this.numVertices == 0);
    }

    @Override
    public boolean isConnected() {
        int i = 0;
        boolean cont = true;
        while (cont && i < this.numVertices) {
            int x = 0;
            Iterator<T> temp = iteratorBFS(i);
            while (temp.hasNext()) {
                x++;
                temp.next();
            }
            if (x != this.numVertices) {
                cont = false;
            }
            i++;
        }
        return cont;
    }

    @Override
    public int size() {
        return this.numVertices;
    }

    public void expandCapacity() {
        T[] larger = (T[]) new Object[this.vertices.length * 2];
        for (int i = 0; i < this.vertices.length; i++) {
            larger[i] = this.vertices[i];
        }
        DoubleLinkedUnorderedList<ArestaWeight>[] adjListlarger
                = new DoubleLinkedUnorderedList[this.vertices.length * 2];
        for (int j = 0; j < this.vertices.length; j++) {
            adjListlarger[j] = this.adjList[j];
        }
        this.adjList = adjListlarger;
        this.vertices = larger;
    }

    public boolean indexIsValid(int index) {
        if (index < 0 || index >= this.numVertices) {
            return false;
        }
        return true;
    }

    public int getIndex(T vertex1) {
        int i = 0;
        int pos = -1;
        // System.out.println(vertex1.toString());
        while (pos == -1 && i < this.numVertices) {
            if (this.vertices[i].equals(vertex1)) {
                // System.out.println("exists:: " + vertex1.toString());
                pos = i;
            }
            i++;
        }
        return pos;
    }

    private int getIndexFromString(String vertex1) {
        int i = 0;
        int pos = -1;
        // System.out.println(vertex1);
        while (pos == -1 && i < this.numVertices) {
            if (this.vertices[i].toString().equals(vertex1)) {
                // System.out.println("exists:: " + vertex1.toString());
                pos = i;
            }
            i++;
        }
        return pos;
    }

    public DoubleLinkedUnorderedList<ArestaWeight>[] getAdjList() {
        return adjList;
    }

    /*public T[] getVertices() {
      return vertices;
  }*/
    public T getVertice(int index) {
        return this.vertices[index];
    }
}
