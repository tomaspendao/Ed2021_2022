/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.LinkedList;

import ADT.QueueADT;
import ADT.StackADT;


/**
 *
 * @author tomaspendao
 */
public class QueueFromTwoStacks<T> implements QueueADT<T>{
    
    private StackADT<T> stackReceive = new LinkedStack<>();
    private StackADT<T> stackStore = new LinkedStack<>();

    @Override
    public void enqueue(T element) {
        while(!(this.stackStore.isEmpty())){
            this.stackReceive.push(this.stackStore.pop());
        }
        this.stackStore.push(element);
        while(!(this.stackReceive.isEmpty())){
            this.stackStore.push(this.stackReceive.pop());
        }
    }

    @Override
    public T dequeue() {
        return this.stackStore.pop();
    }

    @Override
    public T first() {
        return this.stackStore.peek();
    }

    @Override
    public boolean isEmpty() {
        return this.stackStore.isEmpty();
    }

    @Override
    public int size() {
        return this.stackStore.size();
    }

    @Override
    public String toString() {
        return this.stackStore.toString();
    }
    
    
}
