/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.LinkedList;

import ADT.QueueADT;
import Exceptions.EmptyCollectionException;
import Models.Nodes.MyLinearNode;

/**
 *
 * @author tomaspendao
 */
public class LinkedQueue<T> implements QueueADT<T> {

    protected MyLinearNode<T> front;
    private MyLinearNode<T> rear;
    private int count = 0;

    public LinkedQueue() {
        this.front = null;
        this.rear = null;
    }

    public LinkedQueue(T element) {
        this.enqueue(element);
    }
    
    @Override
    public void enqueue(T element) {
        MyLinearNode<T> newRear = new MyLinearNode<>(element);
        if (this.isEmpty()) {
            this.rear = newRear;
            this.front = this.rear;
        } else {
            this.rear.setNext(newRear);
            this.rear = newRear;
        }
        this.count++;
    }

    @Override
    public T dequeue() {
        if (this.isEmpty()) { // no values
            throw new EmptyCollectionException("LinkedQueue");
        }
        T result = this.front.getValue(); //return value
        if (this.size() == 1) { // only one value
            this.front = null;
            this.rear = null;
        } else { // all the rest
            this.front = this.front.getNext();
        }
        this.count--;
        return result;
    }

    @Override
    public T first() {
        if (this.isEmpty()) {
            throw new EmptyCollectionException("LinkedQueue");
        }
        return this.front.getValue();
    }

    @Override
    public boolean isEmpty() {
        return this.size() == 0;
    }

    @Override
    public int size() {
        return this.count;
    }

    @Override
    public String toString() {
        String s = "";
        MyLinearNode<T> current = front;
        while (current != null) {
            s = current.getValue().toString() + " " + s;
            //s += "\n";
            current = current.getNext();
        }

        return s;
    }
    
    public void recursivePrintAll(MyLinearNode node){
        if(node == null){
            System.out.println("");
            return;
        }
        else {
            System.out.print(node.getValue() + " ");
            recursivePrintAll(node.getNext());
            //System.out.print(node.getValue() + " ");
        }
    }
    
    public void recursiveInvertedPrintAll(MyLinearNode node){
        if(node == null){
            System.out.println("");
            return;
        }
        else {
            //System.out.print(node.getValue() + " ");
            recursiveInvertedPrintAll(node.getNext());
            System.out.print(node.getValue() + " ");
        }
    }
    
    public void recursiveReverse(){
        this.recursiveReverseHelper(this.front, this.size());
    }
    
    private void recursiveReverseHelper(MyLinearNode node, int size){
        if(size == 0){
            System.out.println("");
            return;
        }
        else {
            T value = this.dequeue();
            recursiveReverseHelper(node.getNext(),size-1);
            this.enqueue(value);
            
            
        }
    }
}
