/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.LinkedList;

import ADT.StackADT;
import Exceptions.EmptyCollectionException;
import Models.Nodes.MyLinearNode;

/**
 *
 * @author tomaspendao
 */
public class LinkedStack<T> implements StackADT<T> {

    private MyLinearNode<T> top;
    private int count;

    public LinkedStack() {
        this.top = new MyLinearNode<>();
        this.count = 0;
    }

    public LinkedStack(T elem) {
        this.top = new MyLinearNode<>(elem);
        this.count++;
    }

    @Override
    public void push(T element) {
        MyLinearNode<T> temp = new MyLinearNode<>(element);
        temp.setNext(this.top);
        this.top = temp;
        this.count++;
    }

    @Override
    public T pop() {
        if (isEmpty()) {
            throw new EmptyCollectionException("Linked_Stack");
        }
        T res = this.top.getValue();
        //if(this.count == 1){//Caso de so ter um elemnto o Top tem que ser null
        //    this.top = null;
        //} else { // resto dos casos o antigo top deixa de ter elemnto a apontar para ele logo G.C. 
        this.top = this.top.getNext();
        this.count--;
        //}
        return res;
    }

    @Override
    public T peek() {
        if (isEmpty()) {
            throw new EmptyCollectionException("Linked_Stack");
        }
        return this.top.getValue();
    }

    @Override
    public boolean isEmpty() {
        return this.count == 0;
    }

    @Override
    public int size() {
        return this.count;
    }

    @Override
    public String toString() {
        String res = "";
        MyLinearNode<T> pos = this.top;
        for (int i = 0; i < this.count; i++) {
            res = res + pos.getValue() + "\n";
            pos = pos.getNext();
        }
        return res;
    }

}
