/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.LinkedList;


import ADT.UnorderedListADT;
import Exceptions.ElementNotFoundException;
import Exceptions.EmptyCollectionException;
import Models.Nodes.MyLinearNode;
import java.util.Iterator;

/**
 *
 * @author tomaspendao
 */
public class CircularLinkedList<T> implements UnorderedListADT<T> {

    private MyLinearNode<T> front;
    private MyLinearNode<T> rear;
    private int size;

    public CircularLinkedList() {
        this.size = 0;
        this.front = null;
        this.rear = null;
    }

    @Override
    public T removeFirst() {
        if (this.isEmpty()) {
            throw new EmptyCollectionException("CircularLinkedList, removeFirst");
        }
        T res = this.front.getValue();

        if (this.size() == 1) {
            this.removeWhenOnlyOne();
        } else {
            this.front = this.front.getNext();
            this.rear.setNext(this.front);
        }
        this.size--;

        return res;
    }

    private void removeWhenOnlyOne() {
        this.front = null;
        this.rear = null;
    }

    @Override
    public T removeLast() {
        if (this.isEmpty()) {
            throw new EmptyCollectionException("CircularLinkedList, removeFirst");
        }
        T res = this.rear.getValue();

        if (this.size() == 1) {
            this.removeWhenOnlyOne();
        } else {
            MyLinearNode<T> current = this.front;
            for (int i = 1; i < this.size - 1; i++) {
                current = current.getNext();
            }
            current.setNext(this.front);
            this.rear = current;
        }
        this.size--;
        return res;
    }

    @Override
    public T remove(T element) {
        if (this.isEmpty()) {
            throw new EmptyCollectionException("Double Linked List remove");
        }
        if (this.contains(element) == false) {
            throw new ElementNotFoundException("Double Linked List remove");
        }
        if (this.size == 1) {
            this.removeWhenOnlyOne();
        }
        MyLinearNode<T> toRemove = this.front;
        int i = 0;
        for (i = 0; i < this.size - 1; i++) {
            if (toRemove.getValue().equals(element) == true) {
                break;
            } else {
                toRemove = toRemove.getNext();
            }

        }
        if (toRemove.equals(this.rear)) {
            this.removeLast();
        } else if (toRemove.equals(this.front)) {
            this.removeFirst();
        } else {
            int j = 0;
            MyLinearNode<T> current = this.front;
            for (j = 0; j < i - 1; j++) {
                current = current.getNext();
            }
            current.setNext(toRemove.getNext());
            toRemove.setNext(null);

            this.size--;
        }
        return toRemove.getValue();
    }

    @Override
    public T first() {
        if (this.isEmpty()) {
            throw new EmptyCollectionException("Double Linked List : first()");
        }
        return this.front.getValue();
    }

    @Override
    public T last() {
        if (this.isEmpty()) {
            throw new EmptyCollectionException("Double Linked List : first()");
        }
        return this.rear.getValue();
    }

    @Override
    public boolean contains(T target) {
        Iterator<T> iterator = this.iterator();
        int pos = 1;
        while (iterator.hasNext() && pos<=this.size) {
            T temp = iterator.next();
            if (temp.equals(target)) {
                return true;
            }
            pos++;
        }
        return false;
    }

    @Override
    public boolean isEmpty() {
        return this.size == 0;
    }

    @Override
    public int size() {
        return this.size;
    }

    @Override
    public Iterator<T> iterator() {
        return new CircularLinkedListIterator<>(this);
    }

    private class CircularLinkedListIterator<T> implements Iterator<T> {

        //private int icount;
        private MyLinearNode<T> current;
        //private int pos;

        public CircularLinkedListIterator(CircularLinkedList<T> lista) {
            //this.icount = lista.size;
            this.current = lista.front;
            //this.pos = 1;
        }

        @Override
        public boolean hasNext() {
            //return this.pos <= CircularLinkedList.this.size;
            return this.current != null;
        }

        @Override
        public T next() {
            T res = this.current.getValue();

            this.current = this.current.getNext();
            //this.pos++;
            return res;
        }

    }

    @Override
    public void addToFront(T element) {
        MyLinearNode<T> node = new MyLinearNode<>(element);
        if (this.isEmpty()) {
            this.front = node;
            this.rear = node;
            this.rear.setNext(this.front);
        } else {
            node.setNext(this.front);
            this.front = node;
            this.rear.setNext(this.front);
        }
        this.size++;
    }

    @Override
    public void addToRear(T element) {
        MyLinearNode<T> node = new MyLinearNode<>(element);
        if (isEmpty()) {
            this.front = node;
            this.rear = node;
            this.rear.setNext(this.front);
        } else {
            node.setNext(this.front);
            this.rear.setNext(node);
            this.rear = node;
        }
        this.size++;
    }

    @Override
    public void addAfter(T element, T target) {
        if (this.isEmpty()) {
            throw new EmptyCollectionException("Double Linked Unordered List, addAfter");
        }
        MyLinearNode<T> newNode = new MyLinearNode<>(element);
        Iterator iter1 = this.iterator();
        boolean flag = false;
        MyLinearNode<T> current = this.front;
        int pos = 1;
        while (iter1.hasNext() && pos<=this.size) {
            T value = (T) iter1.next();
            if (value.equals(target)) {
                flag = true;
                break;
                //
            } else {
                current = current.getNext();
            }
            pos++;
        }
        if (flag == false) {
            throw new ElementNotFoundException("Double Linked Unordered List, addAfter");
        } else if (current.getValue().equals(this.rear.getValue())) {
            this.addToRear(element);
        } else {
            newNode.setNext(current.getNext());
            current.setNext(newNode);
            this.size++;
        }
    }
    
    @Override
    public String toString() {
        String str = "|";

        Iterator<T> iterator = this.iterator();
        int pos = 1;
        while (iterator.hasNext() && pos<=this.size) {
            str = str + iterator.next() + "|";
            pos++;          
        }

        return str;
    }

}
