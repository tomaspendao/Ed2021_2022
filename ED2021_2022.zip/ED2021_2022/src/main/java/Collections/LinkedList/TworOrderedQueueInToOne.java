/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.LinkedList;

import ADT.QueueADT;

/**
 *
 * @author tomaspendao
 * @param <T>
 */
public class TworOrderedQueueInToOne<T extends Comparable> {

    QueueADT<T> newQueue = new LinkedQueue<>();

    QueueADT<T> orderedQueue1;
    QueueADT<T> orderedQueue2;

    public TworOrderedQueueInToOne(QueueADT<T> queue1, QueueADT<T> queue2) {
        this.orderedQueue1 = queue1;
        this.orderedQueue2 = queue2;
        merge();
    }

    private void merge() {

        while (!(this.orderedQueue1.isEmpty() && this.orderedQueue2.isEmpty())) {
            if (this.orderedQueue1.isEmpty()) {
                this.newQueue.enqueue(this.orderedQueue2.dequeue());
            } else if (this.orderedQueue2.isEmpty()) {
                this.newQueue.enqueue(this.orderedQueue1.dequeue());
            } else if (this.orderedQueue1.first().compareTo(this.orderedQueue2.first()) <= 0) {
                this.newQueue.enqueue(this.orderedQueue1.dequeue());
            } else {
                this.newQueue.enqueue(this.orderedQueue2.dequeue());
            }
        }
    }

    public QueueADT<T> getQueue() {
        return newQueue;
    }

}
