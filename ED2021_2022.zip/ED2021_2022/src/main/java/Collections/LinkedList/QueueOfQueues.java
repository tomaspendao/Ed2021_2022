/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.LinkedList;

import ADT.QueueADT;

/**
 *
 * Dadas N strings, criar N Queues cada uma contendo uma das strings. De seguida
 * criar uma Queue das N Queues. Repetidamente aplicar uma operação de junção
 * ordenada às primeiras duas Queues e reinserir a nova Queue no final. Repetir
 * até que a Queue contenha apenas uma Queue.
 *
 * @author tomaspendao
 */
public class QueueOfQueues {

    private QueueADT<QueueADT> queueOfQueues;
    
    public QueueOfQueues(String[] array) {
        this.queueOfQueues = new LinkedQueue<>();
        fillQueue(array);
        joinQueues();
    }

    public QueueADT<QueueADT> getQueueOfQueues() {
        return queueOfQueues;
    }
    
    private void fillQueue(String[] array){
        for (int i = 0; i < array.length; i++) {
            String[] letters = array[i].split("");
            QueueADT<String> tempQueue = new LinkedQueue<>();
            for (int j = 0; j < letters.length; j++) {
                tempQueue.enqueue(letters[j]);
            }
            this.queueOfQueues.enqueue(tempQueue);
        }
    }
    
    private void joinQueues(){
        while(this.queueOfQueues.size() >= 2){
            QueueADT<String> queueToRemove = this.queueOfQueues.dequeue();
            QueueADT<String> queueToAddTo = this.queueOfQueues.dequeue();
            while(!(queueToRemove.isEmpty())){
                queueToAddTo.enqueue(queueToRemove.dequeue());
            }
            this.queueOfQueues.enqueue(queueToAddTo);
        }
    }
}
