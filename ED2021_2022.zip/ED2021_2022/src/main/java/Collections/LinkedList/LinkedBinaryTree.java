/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.LinkedList;

import ADT.BinaryTreeADT;
import ADT.QueueADT;
import ADT.UnorderedListADT;
import Collections.Array.ArrayUnorderedList;
import Exceptions.ElementNotFoundException;
import Exceptions.EmptyCollectionException;
import Models.Nodes.BinaryTreeNode;
import java.util.Iterator;

/**
 *
 * @author tomaspendao
 */
public class LinkedBinaryTree<T> implements BinaryTreeADT<T> {

    protected int count;
    protected BinaryTreeNode<T> root;

    public LinkedBinaryTree(T element) {
        this.count = 1;
        this.root = new BinaryTreeNode<>(element);
    }

    public LinkedBinaryTree() {
        this.count = 0;
        this.root = null;
    }

    @Override
    public T getRoot() {
        if(this.count == 0){
            throw new EmptyCollectionException("Empty Tree");
        }
        return this.root.getElement();
    }

    @Override
    public boolean isEmpty() {
        return this.size() == 0;
    }

    @Override
    public int size() {
        return this.count;
    }

    @Override
    public boolean contains(T targetElement) {
        boolean res = false;
        try {
            if (find(targetElement) != null) {
                return res = true;
            }
        } catch (ElementNotFoundException ex) {
            return res;
        }
        return res;
    }

    /**
     * Returns a reference to the specified target element if it is found in
     * this binary tree.Throws a NoSuchElementException if the specified target
     * element is not found in the binary tree.
     *
     *
     * @param targetElement the element being sought in this tree * @return a
     * reference to the specified target
     * @return
     * @throws ElementNotFoundException if an element not found exception occurs
     */
    @Override
    public T find(T targetElement) {
        BinaryTreeNode<T> current = findAgain(targetElement, this.root);
        if (current == null) {
            throw new ElementNotFoundException("binary tree");
        }
        return (current.getElement());
    }

    /**
     * Performs an inorder traversal on this binary tree by calling an *
     * overloaded, recursive inorder method that starts with the root.
     *
     * @return an in order iterator over this binary tree
     */
    @Override
    public Iterator<T> iteratorInOrder() {
        ArrayUnorderedList<T> tempList = new ArrayUnorderedList<>();
        inorder(this.root, tempList);
        return tempList.iterator();
    }

    /**
     * Performs an preorder traversal on this binary tree by calling an *
     * overloaded, recursive preorder method that starts with the root.
     *
     * @return an in order iterator over this binary tree
     */
    @Override
    public Iterator<T> iteratorPreOrder() {
        ArrayUnorderedList<T> tempList = new ArrayUnorderedList<>();
        preorder(this.root, tempList);
        return tempList.iterator();
    }

    /**
     * Performs an postorder traversal on this binary tree by calling an *
     * overloaded, recursive postorder method that starts with the root.
     *
     * @return an in order iterator over this binary tree
     */
    @Override
    public Iterator<T> iteratorPostOrder() {
        ArrayUnorderedList<T> tempList = new ArrayUnorderedList<>();
        postorder(this.root, tempList);
        return tempList.iterator();
    }

    /**
     * Performs an levelorder traversal on this binary tree starts with the
     * root.
     *
     * @return an in order iterator over this binary tree
     */
    @Override
    public Iterator<T> iteratorLevelOrder() {
        QueueADT<BinaryTreeNode<T>> nodes = new LinkedQueue<>();
        UnorderedListADT<T> results = new ArrayUnorderedList<>();
        if (this.root != null) {
            nodes.enqueue(this.root);
        }
        while (!nodes.isEmpty()) {
            BinaryTreeNode<T> element = (BinaryTreeNode<T>) nodes.dequeue();
            if (!(element == null)) {
                results.addToRear(element.getElement());
                if (element.getLeft() != null) {
                    nodes.enqueue(element.getLeft());
                }
                if (element.getRight() != null) {
                    nodes.enqueue(element.getRight());
                }
            } else {
                results.addToRear(null);
            }
        }
        return results.iterator();
    }

    /**
     * Returns a reference to the specified target element if it is * found in
     * this binary tree.
     *
     * @param targetElement the element being sought in this tree * @param next
     * the element to begin searching from
     */
    private BinaryTreeNode<T> findAgain(T targetElement, BinaryTreeNode<T> next) {
        if (next == null) {
            return null;
        }
        if (next.getElement().equals(targetElement)) {
            return next;
        }
        BinaryTreeNode<T> temp = findAgain(targetElement, next.getLeft());
        if (temp == null) {
            temp = findAgain(targetElement, next.getRight());
        }
        return temp;
    }

    /**
     * Performs a recursive inorder traversal.
     *
     * @param node the node to be used as the root for this traversal
     * @param tempList the temporary list for use in this traversal
     */
    protected void inorder(BinaryTreeNode<T> node,
            ArrayUnorderedList<T> tempList) {
        if (node != null) {
            inorder(node.getLeft(), tempList);
            tempList.addToRear(node.getElement());
            inorder(node.getRight(), tempList);
        }
    }

    /**
     * Performs a recursive preorder traversal.
     *
     * @param node the node to be used as the root for this traversal
     * @param tempList the temporary list for use in this traversal
     */
    protected void preorder(BinaryTreeNode<T> node,
            ArrayUnorderedList<T> tempList) {
        if (node != null) {
            tempList.addToRear(node.getElement());
            preorder(node.getLeft(), tempList);
            preorder(node.getRight(), tempList);
        }
    }

    /**
     * Performs a recursive postorder traversal.
     *
     * @param node the node to be used as the root for this traversal
     * @param tempList the temporary list for use in this traversal
     */
    protected void postorder(BinaryTreeNode<T> node,
            ArrayUnorderedList<T> tempList) {
        if (node != null) {
            postorder(node.getLeft(), tempList);
            postorder(node.getRight(), tempList);
            tempList.addToRear(node.getElement());
        }
    }
}
