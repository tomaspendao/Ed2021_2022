/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.LinkedList;

import Models.Nodes.MyLinearNode;

/**
 *
 * @author tomaspendao
 */
public class MyLinkedListSentinel<T> extends MyLinkedList<T> {

    //private MyLinearNode<T> head;
    private MyLinearNode<T> tail;

    public MyLinkedListSentinel() {
        this.head = new MyLinearNode<>();
        this.tail = new MyLinearNode<>();
        this.head.setNext(this.tail);

    }

    public MyLinkedListSentinel(T head, T tail) {
        super(head);
        this.tail = new MyLinearNode<>(tail);
        this.head.setNext(this.tail);
    }

    @Override
    public void add(T elem) {
        MyLinearNode<T> temp = new MyLinearNode<>(elem);
        temp.setNext(this.getHead().getNext());
        this.getHead().setNext(temp);
    }

    @Override
    public void printAll() {
        MyLinearNode node = this.getHead().getNext();
        while (node.getValue() != null) {
            System.out.print(node.getValue() + ";");
            node = node.getNext();
        }
    }

    public String toString() {
        String str = "";
        MyLinearNode node = this.getHead().getNext();
        while (node.getValue() != null) {
            str = str + node.getValue() + ";";
            node = node.getNext();
        }
        return str;
    }
    
    @Override
    public void remove() {
        if(this.getHead().getNext().equals(this.getTail())){
            return;
        }
        //MyLinearNode next = this.getHead().getNext().getNext();
        //this.getHead().setNext(next);
        removeAfter(this.getHead().getNext().getValue());
    }

    private void removeAfter(T toDelete) {
        MyLinearNode prev = this.getHead();
        MyLinearNode current = this.getHead().getNext();
        while (current.getValue().equals(toDelete) == false) {
            prev = prev.getNext();
            current = current.getNext();
        }
        MyLinearNode next = current.getNext();
        prev.setNext(next);
    }

    @Override
    public MyLinearNode<T> getHead() {
        return head;
    }

    /*@Override
    public void setHead(MyLinearNode<T> head) {
        this.head = head;
    }*/

    public MyLinearNode<T> getTail() {
        return tail;
    }

    /*public void setTail(MyLinearNode<T> tail) {
        this.tail = tail;
    }*/

}
