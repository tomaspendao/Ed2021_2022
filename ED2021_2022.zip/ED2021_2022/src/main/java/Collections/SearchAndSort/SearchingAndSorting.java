/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.SearchAndSort;

import Collections.DoubleLinkedList.OrderedDoubleLinkedList;
import Collections.LinkedList.MyLinkedList;
import Models.Nodes.DoubleLinkedNode;
import Models.Nodes.MyLinearNode;

/**
 *
 * @author tomaspendao
 */
public class SearchingAndSorting<T> {

    public SearchingAndSorting() {
    }

    /**
     * Searches the specified array of objects using a * binary search
     * algorithm.
     *
     * @param <T>
     * @param data
     * @param min
     * @param max
     * @param target the element being searched for
     * @return true if the desired element is found
     */
    public static <T extends Comparable<? super T>> boolean
            binarySearch(T[] data, int min, int max, T target) {
        boolean found = false;
        int midpoint = (min + max) / 2; // determine the midpoint
        if (data[midpoint].compareTo(target) == 0) {
            found = true;
        } else if (data[midpoint].compareTo(target) > 0) {
            if (min <= midpoint - 1) {
                found = binarySearch(data, min, midpoint - 1, target);
            }
        } else if (midpoint + 1 <= max) {
            found = binarySearch(data, midpoint + 1, max, target);
        }
        return found;
    }

    /**
     * Searches the specified array of objects using a * binary search
     * algorithm.
     *
     * @param <T>
     * @param list
     * @param min
     * @param max
     * @param target the element being searched for
     * @return true if the desired element is found
     */
    public static <T extends Comparable<? super T>> boolean
            binarySearch(OrderedDoubleLinkedList list, DoubleLinkedNode min, DoubleLinkedNode max, T target) {
        boolean found = false;
        DoubleLinkedNode midpoint = findMiddle(min, max);
        Comparable value = (Comparable) midpoint.getValue();
        if (value.compareTo(target) == 0) {
            found = true;
        } else if (value.compareTo(target) > 0) {
            if (null != midpoint.getPrevious()) {
                found = binarySearch(list, min, midpoint.getPrevious(), target);
            }
        } else if (midpoint.getNext() != null) {
            found = binarySearch(list, midpoint.getNext(), max, target);
        }
        return found;
    }

    private static DoubleLinkedNode findMiddle(DoubleLinkedNode start, DoubleLinkedNode last) {
        if (start == null) {
            return null;
        }
        DoubleLinkedNode slow = start;
        DoubleLinkedNode fast = start.getNext();
        if (fast == null) {
            return slow;
        }

        while (fast != last || fast.getNext() != null) {
            fast = fast.getNext();

            if (fast != last) {
                slow = slow.getNext();
                fast = fast.getNext();
            }
        }
        return slow;
    }

    /**
     * Searches the specified array of objects using a linear search algorithm.
     *
     * @param <T>
     * @param data
     * @param min
     * @param max
     * @param target the element being searched for
     * @return true if the desired element is found
     */
    public static <T extends Comparable<? super T>> boolean
            linearSearch(T[] data, int min, int max, T target) {
        int index = min;
        boolean found = false;
        while (!found && index <= max) {
            if (data[index].compareTo(target) == 0) {
                found = true;
            }
            index++;
        }
        return found;
    }

    /**
     * Searches the specified linked list of objects using a linear search
     * algorithm.
     *
     * @param <T>
     * @param list
     * @param target the element being searched for
     * @return true if the desired element is found
     */
    public static <T extends Comparable<? super T>> boolean
            linearSearch(MyLinkedList list, T target) {
        MyLinearNode current = list.getHead();
        while (current != null) {
            Comparable value = (Comparable) current.getValue(); ///
            if (value != null) {
                if (value.compareTo(target) == 0) {
                    return true;
                }
            }
            current = current.getNext();
        }
        return false;
    }

    //////////////SORTING
    /**
     * Sorts the specified array of integers using the selection * sort
     * algorithm.
     *
     * @param <T>
     * @param data the array to be sorted
     */
    public static <T extends Comparable<? super T>> void
            selectionSort(T[] data) {
        int min;
        T temp;
        for (int index = 0; index < data.length - 1; index++) {
            min = index;
            for (int scan = index + 1; scan < data.length; scan++) {
                if (data[scan].compareTo(data[min]) < 0) {
                    min = scan;
                }
            }
            /**
             * Swap the values
             */
            temp = data[min];
            data[min] = data[index];
            data[index] = temp;
        }
    }

    /**
     * Sorts the specified list of integers using the selection * sort
     * algorithm.
     *
     * @param <T>
     * @param list
     */
    public static <T extends Comparable<? super T>> void
            selectionSort(MyLinkedList list) {
        int size = list.getSize();
        MyLinkedList newList = new MyLinkedList();
        Comparable max;
        for (int i = 0; i < size; i++) {
            MyLinearNode current = list.getHead();
            max = (Comparable) current.getValue();
            for (int j = 0; j < list.getSize(); j++) {
                Comparable value = (Comparable) current.getValue();
                System.out.println("*******");
                System.out.println(value);
                System.out.println(max);
                System.out.println("*******");
                if (list.getSize() == 1){
                    System.out.println("mattsgsgfgfwhwsx");
                    max = value;
                    list.remove(current);
                    break;
                }
                if (value.compareTo(max) > 0) {
                    System.out.println("OLA");
                    max = value;
                    list.remove(current);
                }
                
                current = current.getNext();
            }
            System.out.println("adeus");
            newList.add(max);
        }
        newList.printAll();
        list.printAll();
        list = newList;
    }

    /**
     * Sorts the specified array of objects using an insertion * sort algorithm.
     *
     * @param <T>
     * @param data the array to be sorted
     */
    public static <T extends Comparable<? super T>> void
            insertionSort(T[] data) {
        for (int index = 1; index < data.length; index++) {
            T key = data[index];
            int position = index;
            /**
             * Shift larger values to the right
             */
            while (position > 0 && data[position - 1].compareTo(key) > 0) {
                data[position] = data[position - 1];
                position--;
            }
            data[position] = key;
        }
    }

    /**
     * Sorts the specified array of objects using a bubble sort * algorithm.
     *
     * @param <T>
     * @param data the array to be sorted
     */
    public static <T extends Comparable<? super T>> void
            bubbleSort(T[] data) {
        int position, scan;
        T temp;
        for (position = data.length - 1; position >= 0; position--) {
            for (scan = 0; scan <= position - 1; scan++) {
                if (data[scan].compareTo(data[scan + 1]) > 0) {
                    /**
                     * Swap the values
                     */
                    temp = data[scan];
                    data[scan] = data[scan + 1];
                    data[scan + 1] = temp;
                }
            }
        }
    }

    /**
     * Sorts the specified array of objects using the quick sort algorithm.
     *
     * @param <T>
     * @param data the array to be sorted
     * @param min the integer representation of the minimum value
     * @param max the integer representation of the maximum value
     */
    public static <T extends Comparable<? super T>> void
            quickSort(T[] data, int min, int max) {
        int indexofpartition;
        if (max - min > 0) {
            /**
             * Create partitions
             */
            indexofpartition = findPartition(data, min, max);
            /**
             * Sort the left side
             */
            quickSort(data, min, indexofpartition - 1);
            /**
             * Sort the right side
             */
            quickSort(data, indexofpartition + 1, max);
        }
    }

    /**
     * Used by the quick sort algorithm to find the partition.
     *
     * @param data the array to be sorted
     * @param min the integer representation of the minimum value
     * @param max the integer representation of the maximum value
     */
    private static <T extends Comparable<? super T>> int
            findPartition(T[] data, int min, int max) {
        int left, right;
        T temp, partitionelement;
        int middle = (min + max) / 2;
        // use middle element as partition
        partitionelement = data[middle];
        left = min;
        right = max;
        while (left < right) {
            /**
             * search for an element that is > the partitionelement
             */
            while (data[left].compareTo(partitionelement) < 0) {
                left++;
            }
            /**
             * search for an element that is < the partitionelement
             */
            while (data[right].compareTo(partitionelement) > 0) {
                right--;
            }
            /**
             * swap the elements
             */
            if (left < right) {
                temp = data[left];
                data[left] = data[right];
                data[right] = temp;
            }
        }
        /**
         * move partition element to partition index
         
        temp = data[min];
        data[min] = data[right];
        data[right] = temp;*/

        return right;
    }

    /**
     * Sorts the specified array of objects using the merge sort algorithm.
     *
     * @param <T>
     * @param data the array to be sorted
     * @param min the integer representation of the minimum value
     * @param max the integer representation of the maximum value
     */
    public static <T extends Comparable<? super T>> void
            mergeSort(T[] data, int min, int max) {
        T[] temp;
        int index1, left, right;
        /**
         * return on list of length one
         */
        if (min == max) {
            return;
        }
        /**
         * find the length and the midpoint of the list
         */
        int size = max - min + 1;
        int pivot = (min + max) / 2;
        temp = (T[]) (new Comparable[size]);
        mergeSort(data, min, pivot); // sort left half of list mergeSort(data, pivot + 1, max); // sort right half of list
        /**
         * copy sorted data into workspace
         */
        for (index1 = 0; index1 < size; index1++) {
            temp[index1] = data[min + index1];
        }
        /**
         * merge the two sorted lists
         */
        left = 0;
        right = pivot - min + 1;
        for (index1 = 0; index1 < size; index1++) {
            if (right <= max - min) {
                if (left <= pivot - min) {
                    if (temp[left].compareTo(temp[right]) > 0) {
                        data[index1 + min] = temp[right++];
                    } else {
                        data[index1 + min] = temp[left++];
                    }
                } else {
                    data[index1 + min] = temp[right++];
                }
            } else {
                data[index1 + min] = temp[left++];
            }
        }
    }
}
