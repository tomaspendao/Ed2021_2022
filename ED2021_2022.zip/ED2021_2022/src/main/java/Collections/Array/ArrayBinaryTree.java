/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.Array;

import ADT.BinaryTreeADT;
import ADT.QueueADT;
import ADT.UnorderedListADT;
import Exceptions.ElementNotFoundException;
import Exceptions.EmptyCollectionException;
import java.util.Iterator;

/**
 *
 * @author tomaspendao
 */
public class ArrayBinaryTree<T> implements BinaryTreeADT<T> {

    private static final int CAPACITY = 10;

    protected int count;
    protected T[] tree;

    /**
     * Creates an empty binary tree.
     */
    public ArrayBinaryTree() {
        this.count = 0;
        this.tree = (T[]) new Object[ArrayBinaryTree.CAPACITY];
    }

    /**
     * Creates a binary tree with the specified element as its root.
     *
     *
     * @param element the element which will become the root of the new tree
     */
    public ArrayBinaryTree(T element) {
        count = 1;
        tree = (T[]) new Object[ArrayBinaryTree.CAPACITY];
        tree[0] = element;
    }

    @Override
    public T getRoot() {
        if(this.isEmpty()){
            throw new EmptyCollectionException("Empty Tree");
        }
        return this.tree[0];
    }

    @Override
    public boolean isEmpty() {
        return this.size() == 0;
    }

    @Override
    public int size() {
        return this.count;
    }

    @Override
    public boolean contains(T targetElement) {
        boolean res = false;
        try {
            if (find(targetElement) != null) {
                return res = true;
            }
        } catch (ElementNotFoundException ex) {
            return res;
        }
        return res;
    }

    /**
     * Returns a reference to the specified target element if it is found in
     * this binary tree.Throws a NoSuchElementException if the specified target
     * element is not found in the binary tree.
     *
     *
     * @param targetElement the element being sought in the tree * @return true
     * if the element is in the tree
     * @return
     * @throws ElementNotFoundException if an element not found exception occurs
     */
    @Override
    public T find(T targetElement) {
        T temp = null;
        boolean found = false;
        for (int ct = 0; ct < count && !found; ct++) {
            if (targetElement.equals(tree[ct])) {
                found = true;
                temp = tree[ct];
            }
        }
        if (!found) {
            throw new ElementNotFoundException("binary tree");
        }
        return temp;
    }

    /**
     * Performs an inorder traversal on this binary tree by * calling an
     * overloaded, recursive inorder method that starts with the root.
     *
     * @return an iterator over the binary tree
     */
    @Override
    public Iterator<T> iteratorInOrder() {
        ArrayUnorderedList<T> templist = new ArrayUnorderedList<>();
        this.inorder(0, templist);
        return templist.iterator();
    }

    @Override
    public Iterator<T> iteratorPreOrder() {
        ArrayUnorderedList<T> templist = new ArrayUnorderedList<>();
        this.preorder(0, templist);
        return templist.iterator();
    }

    @Override
    public Iterator<T> iteratorPostOrder() {
        ArrayUnorderedList<T> templist = new ArrayUnorderedList<>();
        this.postorder(0, templist);
        return templist.iterator();
    }

    @Override
    public Iterator<T> iteratorLevelOrder() {
        QueueADT<Integer> nodes = new CircularArrayQueue<>();
        UnorderedListADT<T> results = new ArrayUnorderedList<>();
        if (this.tree[0] != null) {
            nodes.enqueue(0);
        }
        while (!nodes.isEmpty()) {
            int element = nodes.dequeue();
                results.addToRear(this.tree[element]);
                if (this.tree[element * 2 + 1] != null) {
                    nodes.enqueue(element * 2 + 1);
                }
                if (this.tree[(element + 1) * 2] != null) {
                    nodes.enqueue((element + 1) * 2);
                }
        }
        return results.iterator();
    }

    /**
     * Performs a recursive inorder traversal.
     *
     * @param node the node used in the traversal
     * @param templist the temporary list used in the traversal
     */
    private void inorder(int node, ArrayUnorderedList<T> templist) {
        if (node < tree.length) {
            if (tree[node] != null) {
                inorder(node * 2 + 1, templist); //left
                templist.addToRear(tree[node]);
                inorder((node + 1) * 2, templist); //right
            }
        }
    }

    /**
     * Performs a recursive preorder traversal.
     *
     * @param node the node used in the traversal
     * @param templist the temporary list used in the traversal
     */
    private void preorder(int node, ArrayUnorderedList<T> templist) {
        if (node < tree.length) {
            if (tree[node] != null) {
                templist.addToRear(tree[node]);
                preorder(node * 2 + 1, templist); //left
                preorder((node + 1) * 2, templist); //right
            }
        }
    }

    /**
     * Performs a recursive postorder traversal.
     *
     * @param node the node used in the traversal
     * @param templist the temporary list used in the traversal
     */
    private void postorder(int node, ArrayUnorderedList<T> templist) {
        if (node < tree.length) {
            if (tree[node] != null) {
                postorder(node * 2 + 1, templist); //left
                postorder((node + 1) * 2, templist); //right
                templist.addToRear(tree[node]);
            }
        }
    }

    protected void expandCapacity() {
        T[] larger = (T[]) new Object[this.tree.length * 4];
        for (int i = 0; i < this.tree.length; i++) {
            larger[i] = this.tree[i];
        }
        this.tree = larger;
    }
}
