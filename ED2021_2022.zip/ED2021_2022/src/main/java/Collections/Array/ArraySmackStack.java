/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.Array;

import ADT.SmackStackADT;
import ADT.StackADT;
import Exceptions.EmptyCollectionException;


/**
 *
 * @author tomaspendao
 */
public class ArraySmackStack<T> extends ArrayStack<T> implements SmackStackADT<T>{

    public ArraySmackStack(int initialCapacity) {
        super(initialCapacity);
    }

    public ArraySmackStack() {
    }
    
    @Override
    public T smack() {
        if (super.isEmpty()) {
            throw new EmptyCollectionException("ArraySmackStack, smack()");
        }
        StackADT<T> tempStack = new ArrayStack<>();
        while(!(super.isEmpty())){
            tempStack.push(super.pop());
        }
        T res = tempStack.pop();
        //tempStack.pop();
        while(!(tempStack.isEmpty())){
            super.push(tempStack.pop());
        }
        return res;
    }
    
}
