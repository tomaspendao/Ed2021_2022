/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.Array;

import ADT.QueueADT;
import Exceptions.EmptyCollectionException;


/**
 *
 * @author tomaspendao
 */
public class CircularArrayQueue<T> implements QueueADT<T> {

    private final int DEFAULT_CAPACITY = 100;
    private int front;
    private int rear;
    private T[] queue;
    private int count = 0;

    public CircularArrayQueue() {
        this.queue = (T[]) (new Object[this.DEFAULT_CAPACITY]);
        this.front = 0;
        this.rear = 0;
    }

    public CircularArrayQueue(int initialSize) {
        this.queue = (T[]) (new Object[initialSize]);
        this.front = 0;
        this.rear = 0;
    }

    @Override
    public void enqueue(T element) {
        if (this.size() == this.queue.length) {
            this.expandCapacity();
        }
        this.queue[this.rear] = element;
        this.rear = (this.rear + 1) % this.queue.length;
        count++;
    }

    @Override
    public T dequeue() {
        if (this.isEmpty()) {
            throw new EmptyCollectionException("CircularArrayQueue");
        }
        T result = this.queue[this.front];
        this.queue[this.front] = null;
        this.front = (this.front + 1) % this.queue.length;
        this.count--;
        return result;
    }

    @Override
    public T first() {
        if (this.isEmpty()) {
            throw new EmptyCollectionException("CircularArrayQueue");
        }
        return this.queue[this.front];
    }

    @Override
    public boolean isEmpty() {
        return this.size() == 0;
    }

    @Override
    public int size() {
        return this.count;
    }

    private void expandCapacity() {
        T[] newQueue = (T[]) (new Object[this.queue.length * 2]);
        for (int i = 0; i < this.queue.length; i++) {
            //newQueue[i] = this.queue[i%queue.length];
            newQueue[i] = this.queue[i];
        }
        this.queue = newQueue;
        this.front = 0;
        this.rear = count - 1;

    }

    @Override
    public String toString() {
        String s = "";
        for (int i = front; i < front + size(); i++) {
            s = queue[i % queue.length].toString() + ";" + s;
            //s += ";";
        }
        return s;
    }

}
