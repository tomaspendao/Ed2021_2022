/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.Array;

import ADT.StackADT;
import Exceptions.EmptyCollectionException;

/**
 *
 * @author tomaspendao
 */
public class ArrayStack<T> implements StackADT<T> {

    /**
     * default capacity of the array
     */
    private final int DEFAULT_CAPACITY = 100;

    /**
     * int that represents both the number of elements and the next available
     * position in the array
     */
    private int top;

    /**
     * array generic elements to represent the stack
     */
    private T[] stack;

    /**
     * Creates an empty stack using the specified size
     *
     * @param initialCapacity represents the specified capacity
     */
    public ArrayStack(int initialCapacity) {
        this.top = 0;
        this.stack = (T[]) (new Object[initialCapacity]);
    }
    
    /**
     * Creates an empty stack using the default size
     */
    public ArrayStack() {
        this.top = 0;
        this.stack = (T[]) (new Object[this.DEFAULT_CAPACITY]);
    }

    @Override
    public void push(T element) {
        if (this.size() == stack.length) {
            expandCapacity();
        }
        this.stack[this.top] = element;
        this.top++;
    }

    @Override
    public T pop() {
        if (isEmpty()) {
            throw new EmptyCollectionException("Stack");
        }
        
        this.top--;
        T res = this.stack[this.top];
        this.stack[this.top] = null;
        
        return res;
    }

    @Override
    public T peek() {
        if (isEmpty()) {
            throw new EmptyCollectionException("Stack");
        }
        return this.stack[this.top-1];
    }

    @Override
    public boolean isEmpty() {
        return this.top == 0;
    }

    @Override
    public int size() {
        return this.top;
    }

    private void expandCapacity() {
        T[] newStack = (T[]) (new Object[this.stack.length * 2]);
        for (int i = 0; i < this.stack.length; i++) {
            newStack[i] = this.stack[i];
        }
        this.stack = newStack;
    }

    @Override
    public String toString() {
        String res = "";
        for (int i = 0; i < this.top; i++) {
            res = res + this.stack[i].toString() + " | ";
        }
        return res;
    }

    
}
