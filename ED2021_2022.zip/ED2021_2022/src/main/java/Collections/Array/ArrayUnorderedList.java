/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.Array;

import ADT.UnorderedListADT;
import Exceptions.ElementNotFoundException;
import java.util.Iterator;

/**
 *
 * @author tomaspendao
 */
public class ArrayUnorderedList<T> extends ArrayList<T> implements UnorderedListADT<T>{

    public ArrayUnorderedList() {
        super.list = (T[])new Object[super.DEFAULT_CAPACITY];
    }

    public ArrayUnorderedList(int initialSize) {
        super.list = (T[])new Object[initialSize];
    }
    
    @Override
    public void addToFront(T element) {
        expand();
        super.shiftToTheRightFromTheLeft(0);
        super.list[0] = element;
        super.count++;
    }

    @Override
    public void addToRear(T element) {
        expand();
        super.list[super.rear] = element;
        super.rear++;
        super.count++;
    }

    @Override
    public void addAfter(T element, T target) {
        if(super.contains(target) == false){
            throw new ElementNotFoundException("addAfter ArrayUnorderedList");
        }
        expand();
        int pos = this.findPosToAdd(target);
        super.shiftToTheRightFromTheLeft(pos);
        super.list[pos] = element;
        super.count++;
    }
    
    private void expand(){
        if(super.size() == super.list.length){
            super.expandCapacity();
        }
    }
    
    private int findPosToAdd(T element){
        Iterator<T> iter1 = super.iterator();
        int iTemp = 0;
        while(iter1.hasNext()){
            T temp = iter1.next();
            if(temp.equals(element)){
                iTemp++;
                break;
            }
            iTemp++;
        }
        return iTemp;
    }
    
}
