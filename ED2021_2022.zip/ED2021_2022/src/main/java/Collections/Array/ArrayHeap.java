/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.Array;

import ADT.HeapADT;
import Exceptions.EmptyCollectionException;

/**
 *
 * @author tomaspendao
 */
public class ArrayHeap<T> extends ArrayBinaryTree<T> implements HeapADT<T> {

    public ArrayHeap() {
        super();
    }

    /**
     * Adds the specified element to this heap in the appropriate position
     * according to its key value. Note that equal elements are added to the
     * right.
     *
     * @param obj the element to be added to this heap
     */
    @Override
    public void addElement(T obj) {
        if (super.count == super.tree.length) {
            super.expandCapacity();
        }
        super.tree[super.count] = obj;
        super.count++;
        if (super.count > 1) {
            this.heapifyAdd();
        }
    }

    /**
     * Remove the element with the lowest value in this heap and returns a
     * reference to it. Throws an EmptyCollectionException if the heap is empty.
     *
     * @return a reference to the element with the lowest value in this head
     */
    @Override
    public T removeMin() {
        if (isEmpty()) {
            throw new EmptyCollectionException("Empty Heap");
        }
        T minElement = super.tree[0];
        super.tree[0] = super.tree[super.count - 1];
        this.heapifyRemove();
        super.count--;
        return minElement;
    }

    @Override
    public T findMin() {
        return super.getRoot();
    }

    /**
     * Reorders this heap to maintain the ordering property after * adding a
     * node.
     */
    private void heapifyAdd() {
        T temp;
        int next = super.count - 1;
        temp = super.tree[next];

        while ((next != 0) && ((Comparable) temp).compareTo(super.tree[(next - 1) / 2]) < 0) {
            super.tree[next] = super.tree[(next - 1) / 2];
            next = (next - 1) / 2;
        }

        super.tree[next] = temp;
    }

    /**
     * Reorders this heap to maintain the ordering property.
     */
    private void heapifyRemove() {
        T temp;
        int node = 0;
        int left = 1;
        int right = 2;
        int next;
        if ((super.tree[left] == null) && (super.tree[right] == null)) {
            next = super.count;
        } else if (super.tree[left] == null) {
            next = right;
        } else if (super.tree[right] == null) {
            next = left;
        } else if (((Comparable) super.tree[left]).compareTo(super.tree[right]) < 0) {
            next = left;
        } else {
            next = right;
        }
        temp = super.tree[node];
        while ((next < super.count) && (((Comparable) super.tree[next]).compareTo(temp) < 0)) {
            super.tree[node] = super.tree[next];
            node = next;
            left = 2 * node + 1;
            right = 2 * (node + 1);
            T leftNode=null,rightNode=null;
            if(left < super.tree.length){
                leftNode = super.tree[left];
            }
            if(right < super.tree.length){
                rightNode = super.tree[right];
            }
            //if(left<super.tree.length && right<super.tree.length)
            if ((leftNode == null) && (rightNode == null) ) {
                next = super.count;
            } else if (leftNode == null) {
                next = right;
            } else if (rightNode == null) {
                next = left;
            } else if (((Comparable) leftNode).compareTo(rightNode) < 0) {
                next = left;
            } else {
                next = right;
            }
        }
        super.tree[node] = temp;

    }

}
