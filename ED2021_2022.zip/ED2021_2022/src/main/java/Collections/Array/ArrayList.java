/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.Array;

import ADT.ListADT;
import Exceptions.ElementNotFoundException;
import Exceptions.EmptyCollectionException;
import java.util.Iterator;

/**
 *
 * @author tomaspendao
 * @param <T>
 */
abstract public class ArrayList<T> implements ListADT<T> {

    protected final int DEFAULT_CAPACITY = 100;

    protected int front = 0;
    protected int rear = 0;

    protected int count = 0;

    protected T[] list;

    /*public ArrayList() {
        this.list = (T[]) new Object[this.DEFAULT_CAPACITY];
    }

    public ArrayList(int initialSize) {
        this.list = (T[]) new Object[initialSize];
    }*/

    public ArrayList() {
    }
    

    @Override
    public T removeFirst() {
        if (this.isEmpty()) {
            throw new EmptyCollectionException("ArrayList");
        }
        T result = this.list[this.front];
        for (int i = this.front + 1; i < this.rear; i++) {
            this.list[i - 1] = this.list[i];
        }
        this.count--;
        this.rear--;
        this.list[this.rear] = null; // apagar ultimo na lista para nao ter reptidos

        return result;
    }

    @Override
    public T removeLast() {
        if (this.isEmpty()) {
            throw new EmptyCollectionException("ArrayList");
        }
        T result = this.list[this.rear - 1];

        this.count--;
        this.rear--;
        this.list[this.rear] = null;

        return result;
    }

    @Override
    public T remove(T element) {
        if (this.isEmpty()) {
            throw new EmptyCollectionException("ArrayList");
        }
        if (!(this.contains(element))) {
            throw new ElementNotFoundException(element.toString());
        }
        T result = null;
        int current = 0;
        for (int i = 0; i < this.rear; i++) {
            if (this.list[i].equals(element)) {
                //result = this.list[i];
                current = i;
                break;
            }
        }

        result = this.list[current];

        if (this.size() == 1) {
            this.list[current] = null;
            this.front--;
            this.front = this.rear = 0;

        } else if (current == this.front) {
            this.removeFirst();

        } else if (current == this.rear - 1) {
            this.removeLast();

        } else {
            for (int i = current + 1; i < this.rear; i++) {
                this.list[i - 1] = this.list[i];
            }
            this.count--;
            this.rear--;
            this.list[this.rear] = null;
        }

        return result;
    }

    @Override
    public T first() {
        if (this.isEmpty()) {
            throw new EmptyCollectionException("ArrayList");
        }
        return this.list[this.front];
    }

    @Override
    public T last() {
        if (this.isEmpty()) {
            throw new EmptyCollectionException("ArrayList");
        }
        return this.list[this.rear - 1];
    }

    @Override
    public boolean contains(T target) {
        if (this.isEmpty()) {
            throw new EmptyCollectionException("ArrayList");
        }
        for (int i = 0; i < this.rear; i++) {
            if (this.list[i].equals(target)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean isEmpty() {
        return this.size() == 0;
    }

    @Override
    public int size() {
        return this.count;
    }

    @Override
    public Iterator<T> iterator() {
        return new ArrayListIterator<>(this.count);
    }
    
    protected void expandCapacity() {
        T[] larger = (T[]) (new Object[this.list.length * 2]);
		for (int i = 0; i < this.list.length; i++) {
			larger[i] = this.list[i];
		}
		this.list = larger;
    }

    private class ArrayListIterator<T> implements Iterator<T> {

        private int icount;
        private int current;
        private boolean okToRemove = false;

        public ArrayListIterator(int count) {
            this.icount = count;
            this.current = 0;
        }

        @Override
        public boolean hasNext() {
            return current != rear && this.icount == count;
        }

        @Override
        public T next() {
            if (!(this.hasNext())) {
                throw new ElementNotFoundException("hasNext");
            }
            this.okToRemove = true;
            if (this.icount == count) {
                return (T) list[this.current++];
            } else {
                throw new ElementNotFoundException("next");
            }

        }

        @Override
        public void remove() {
            if (!this.okToRemove) {
                throw new ElementNotFoundException("remove");
            }
            this.okToRemove = false;
            try {
                ArrayList.this.remove(list[current]);
                icount--;
                current++;
            } catch (EmptyCollectionException e) {
                throw new IllegalThreadStateException();
            }

        }

    }
    
    protected void shiftToTheRightFromTheLeft(int tillIndex){
        int i = this.rear-1;
        while(i >= tillIndex){
            this.list[i+1] = this.list[i];
            i--;
        }
        this.rear++;
    }

    @Override
    public String toString() {
        String str = "|";
        
        Iterator<T> iterator = this.iterator();
        while(iterator.hasNext()){
            str = str + iterator.next()+"|";
        }
        
        return str;
    }

}
