/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.Array;

import ADT.BinarySearchTreeADT;
import Exceptions.ElementNotFoundException;
import Exceptions.EmptyCollectionException;

/**
 *
 * @author tomaspendao
 */
public class ArrayBinarySearchTree<T> extends ArrayBinaryTree<T> implements BinarySearchTreeADT<T> {

    private int height;
    private int maxIndex;

    /**
     * Creates an empty binary search tree.
     */
    public ArrayBinarySearchTree() {
        super();
        height = 0;
        maxIndex = -1;
    }

    /**
     * Creates a binary search with the specified element as its root
     *
     * @param element the element that will become the root of the new tree
     */
    public ArrayBinarySearchTree(T element) {
        super(element);
        height = 1;
        maxIndex = 0;
    }

    @Override
    public void addElement(T element) {
        if (this.tree.length < this.maxIndex * 2 + 3) {
            expandCapacity();
        }
        Comparable<T> tempelement = (Comparable<T>) element;
        if (isEmpty()) {
            this.tree[0] = element;
            this.maxIndex = 0;
        } else {
            boolean added = false;
            int currentIndex = 0;
            while (!added) {
                if (tempelement.compareTo(this.tree[currentIndex]) < 0) {
                    /**
                     * go left
                     */

                    currentIndex = this.goLeft(currentIndex);
                    if (this.tree[currentIndex] == null) {
                        this.tree[currentIndex] = element;
                        added = true;
                        if (currentIndex > this.maxIndex) {
                            this.maxIndex = currentIndex;
                        }
                    }

                } else {
                    /**
                     * go right
                     */
                    currentIndex = this.goRight(currentIndex);
                    if (this.tree[currentIndex] == null) {
                        this.tree[currentIndex] = element;
                        added = true;
                        if (currentIndex > this.maxIndex) {
                            this.maxIndex = currentIndex;
                        }
                    }
                }
            }
        }
        this.height = (int) (Math.log((this.maxIndex + 1)) / Math.log(2)) + 1;
        this.count++;
    }

    private int goLeft(int currentIndex) {
        if (currentIndex * 2 + 1 < super.tree.length) {
            return currentIndex = currentIndex * 2 + 1;
        }
        return -7;
    }

    private int goRight(int currentIndex) {
        if (currentIndex * 2 + 2 < super.tree.length) {

            return currentIndex = currentIndex * 2 + 2;
        }
        return -7;
    }

    @Override
    public T removeElement(T targetElement) {
        T result = null;
        if (isEmpty()) {
            throw new ElementNotFoundException("Max not find");
        }
        int current = 0, parent = 0;
        boolean found = false;

        if (((Comparable<T>) targetElement).compareTo(this.tree[0]) == 0) {
            result = super.getRoot();
            super.tree[0] = this.replacement(0);
            super.count--;
        }

        if (((Comparable<T>) targetElement).compareTo(this.tree[0]) < 0) {
            current = 1;
        } else {
            current = 2;
        }
        while (current >=0 && super.tree[current] != null && !found) {
            //System.out.println("ola: " + current);
            //System.out.println("ola2: " + super.tree[current]);
            if (targetElement.equals(super.tree[current])) {
                found = true;
                this.count--;
                result = super.tree[current];
                if (current == this.goLeft(parent)) {
                    super.tree[this.goLeft(parent)] = this.replacement(current);
                    //parent.setLeft(this.replacement(current));
                } else {
                    super.tree[this.goRight(parent)] = this.replacement(current);
                    //parent.setRight(this.replacement(current));
                }
            } else {
                parent = current;
                if (((Comparable<T>) targetElement).compareTo(super.tree[current]) < 0) {
                    current = this.goLeft(current);
                } else {
                    current = this.goRight(current);
                }
            }
        }
        return result;
    }

    @Override
    public void removeAllOccurrences(T targetElement) {
        boolean toRemove = true;
        while (toRemove == true) {
            try {
                if (removeElement(targetElement) != null) {
                    toRemove = true;
                } else {
                    toRemove = false;
                }
            } catch (ElementNotFoundException | EmptyCollectionException ex) {
                toRemove = false;
            }
        }
    }

    @Override
    public T removeMin() {
        return this.removeElement(this.findMin());
    }

    @Override
    public T removeMax() {
        return this.removeElement(this.findMax());
    }

    @Override
    public T findMin() {
        T result = null;
        if (isEmpty()) {
            throw new EmptyCollectionException("min not find");
        }
        int current = 0;
        while (current <= this.maxIndex && super.tree[current * 2 + 1] != null) {
            current = this.goLeft(current);
        }
        result = super.tree[current];
        return result;
    }

    @Override
    public T findMax() {

        T result = null;
        if (isEmpty()) {
            throw new EmptyCollectionException("max not find");
        }
        int current = 0;
        while (current <= this.maxIndex && super.tree[current * 2 + 2] != null) {
            current = this.goRight(current);
        }
        result = super.tree[current];
        return result;
    }

    /**
     * Returns a reference to a node that will replace the one specified for
     * removal. In the case where the removed node has two children, the inorder
     * successor is used as its replacement.
     *
     *
     * @param node the node to be removed
     * @return a reference to the replacing node
     */
    private T replacement(int pos) {
        T result = null;
        if ((super.tree[this.goLeft(pos)] == null) && (super.tree[this.goRight(pos)] == null)) {
            result = null;
        } else if ((super.tree[this.goLeft(pos)] != null) && (super.tree[this.goRight(pos)] == null)) {
            result = super.tree[this.goLeft(pos)];
        } else if ((super.tree[this.goLeft(pos)] == null) && (super.tree[this.goRight(pos)] != null)) {
            result = super.tree[this.goRight(pos)];
        } else {
            int current = this.goRight(pos);
            int parent = pos;
            while (super.tree[this.goLeft(current)] != null) {
                parent = current;
                current = this.goLeft(current);
            }
            if (this.goRight(pos) == current) {
                super.tree[this.goLeft(current)] = super.tree[this.goLeft(pos)];
            } else {
                super.tree[this.goLeft(parent)] = super.tree[this.goRight(current)];
                super.tree[this.goRight(current)] = super.tree[this.goRight(pos)];
                super.tree[this.goLeft(current)] = super.tree[this.goLeft(pos)];
            }
            result = super.tree[current];
        }
        return result;
    }
}
