/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.Array;

import ADT.OrderedListADT;
import java.util.Iterator;

/**
 *
 * @author tomaspendao
 * @param <T>
 */
public class ArrayOrderedList<T extends Comparable> extends ArrayList<T> implements OrderedListADT<T>{

    public ArrayOrderedList() {
        super.list = (T[])new Comparable[super.DEFAULT_CAPACITY];
        //super.list = (T[])new Object[super.DEFAULT_CAPACITY];
    }

    public ArrayOrderedList(int initialSize) {
        super.list = (T[])new Comparable[initialSize];
    }
    
    @Override
    public void add(T element) {
        if(super.size() == super.list.length){
            super.expandCapacity();
        }
        
        int pos = this.findPosToAdd(element);
        super.shiftToTheRightFromTheLeft(pos);
        super.list[pos] = element;
        super.count++;
    }
    
    private int findPosToAdd(T element){
        Iterator<T> iter1 = super.iterator();
        int iTemp = 0;
        while(iter1.hasNext()){
            T temp = iter1.next();
            if(temp.compareTo(element) >= 0){
                //iTemp++;
                //return iTemp;
                break;
            }
            iTemp++;
        }
        return iTemp;
    }
    
}
