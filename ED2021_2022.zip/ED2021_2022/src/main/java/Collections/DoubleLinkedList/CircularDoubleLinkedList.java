/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.DoubleLinkedList;

import java.util.Iterator;

/**
 *
 * @author tomaspendao
 */
public class CircularDoubleLinkedList<T> extends DoubleLinkedUnorderedList<T> {

    public CircularDoubleLinkedList() {
        super();
    }

    @Override
    public T removeFirst() {
        T res = super.removeFirst();

        pointFrontToRearANDRearToFront();

        return res;
    }

    @Override
    public T removeLast() {
        T res = super.removeLast();

        pointFrontToRearANDRearToFront();

        return res;
    }

    @Override
    public void addToFront(T element) {
        super.addToFront(element);
        pointFrontToRearANDRearToFront();
    }
    
    @Override
    public void addToRear(T element) {
        super.addToRear(element);
        pointFrontToRearANDRearToFront();
    }
    
    private void pointFrontToRearANDRearToFront() {
        super.front.setPrevious(super.rear);
        super.rear.setNext(super.front);
    }

    @Override
    public String toString() {
        String str = "|";
        
        Iterator<T> iterator = super.iterator();
        int pos=1;
        while (iterator.hasNext() && pos<=super.size) {
            str = str + iterator.next() + "|";
            pos++;
        }

        return str;
    }
    
}
