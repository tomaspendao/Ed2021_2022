/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.DoubleLinkedList;


import ADT.UnorderedListADT;
import Exceptions.ElementNotFoundException;
import Exceptions.EmptyCollectionException;
import Models.Nodes.DoubleLinkedNode;
import java.util.Iterator;

/**
 *
 * @author tomaspendao
 */
public class DoubleLinkedUnorderedList<T> extends DoubleLinkedList<T> implements UnorderedListADT<T> {

    public DoubleLinkedUnorderedList() {
        super();
    }

    @Override
    public void addToFront(T element) {
        DoubleLinkedNode<T> newNode = new DoubleLinkedNode<>(element);
        if (super.isEmpty()) {
            super.front = newNode;
            super.rear = newNode;
            super.size++;
            super.modcount++;
        } else {
            newNode.setNext(super.front);
            super.front.setPrevious(newNode);
            super.front = newNode;
            super.size++;
            super.modcount++;
        }

    }

    @Override
    public void addToRear(T element) {
        DoubleLinkedNode<T> newNode = new DoubleLinkedNode<>(element);
        if (super.isEmpty()) {
            super.front = newNode;
            super.rear = newNode;
            super.size++;
            super.modcount++;
        } else {
            super.rear.setNext(newNode);
            newNode.setPrevious(super.rear);
            super.rear = newNode;
            super.size++;
            super.modcount++;
        }
    }

    @Override
    public void addAfter(T element, T target) {
        if (super.isEmpty()) {
            throw new EmptyCollectionException("Double Linked Unordered List, addAfter");
        }
        DoubleLinkedNode<T> newNode = new DoubleLinkedNode<>(element);
        Iterator iter1 = super.iterator();
        boolean flag = false;
        DoubleLinkedNode<T> current = this.front;
        while (iter1.hasNext()) {
            T value = (T) iter1.next();
            if (value.equals(target)) {
                flag = true;
                //
                break;
                //
            } else {
                current = current.getNext();
            }
        }
        if (flag == false) {
            throw new ElementNotFoundException("Double Linked Unordered List, addAfter");
        } else if (current.equals(super.rear)) {
            this.addToRear(element);
        } else {
            newNode.setNext(current.getNext());
            newNode.setPrevious(current);
            current.setNext(newNode);
            newNode.getNext().setPrevious(newNode);
            super.size++;
            super.modcount++;
        }
    }

}
