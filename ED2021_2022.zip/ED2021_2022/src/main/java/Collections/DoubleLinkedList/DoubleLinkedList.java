/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.DoubleLinkedList;

import ADT.ListADT;
import ADT.UnorderedListADT;
import Collections.Array.ArrayUnorderedList;
import Exceptions.ElementNotFoundException;
import Exceptions.EmptyCollectionException;
import Models.Nodes.DoubleLinkedNode;
import java.util.Iterator;

/**
 *
 * @author tomaspendao
 * @param <T>
 */
abstract public class DoubleLinkedList<T> implements ListADT<T> {

    protected DoubleLinkedNode<T> front;
    protected DoubleLinkedNode<T> rear;
    protected int size;
    protected int modcount;

    public DoubleLinkedList() {
        this.front = null;
        this.rear = null;
        this.size = 0;
        this.modcount = 0;
    }

    @Override
    public T removeFirst() {
        if (this.isEmpty()) {
            throw new EmptyCollectionException("Double Linked List removeFirst");
        }
        T res = this.front.getValue();
        if (this.size == 1) {
            this.removeWhenOnlyOne();
        } else {
            this.front = this.front.getNext();
            this.front.getPrevious().setNext(null);
            this.front.setPrevious(null);
        }
        this.size--;
        this.modcount++;

        return res;
    }

    @Override
    public T removeLast() {
        if (this.isEmpty()) {
            throw new EmptyCollectionException("Double Linked List removeLast");
        }
        T res = this.rear.getValue();
        if (this.size == 1) {
            this.removeWhenOnlyOne();
        } else {
            this.rear = this.rear.getPrevious();
            this.rear.getNext().setPrevious(null);
            this.rear.setNext(null);
        }
        this.size--;
        this.modcount++;

        return res;
    }

    private void removeWhenOnlyOne() {
        this.front = null;
        this.rear = null;
    }

    @Override
    public T remove(T element) {
        if (this.isEmpty()) {
            throw new EmptyCollectionException("Double Linked List remove");
        }
        if (this.contains(element) == false) {
            throw new ElementNotFoundException("Double Linked List remove");
        }
        if (this.size == 1) {
            this.removeWhenOnlyOne();
        } else {
            DoubleLinkedNode<T> toRemove = this.front;
            for (int i = 0; i < this.size - 1; i++) {
                if (toRemove.getValue().equals(element) == true) {
                    break;
                } else {
                    toRemove = toRemove.getNext();
                }
            }

            if (toRemove.equals(this.rear)) {
                this.removeLast();
            } else if (toRemove.equals(this.front)) {
                this.removeFirst();
            } else {
                toRemove.getPrevious().setNext(toRemove.getNext());
                toRemove.getNext().setPrevious(toRemove.getPrevious());
                toRemove.setNext(null);
                toRemove.setPrevious(null);

                this.size--;
                this.modcount++;
            }
            return toRemove.getValue();
        }
        return element;
    }

    @Override
    public T first() {
        if (this.isEmpty()) {
            throw new EmptyCollectionException("Double Linked List : first()");
        }
        return this.front.getValue();
    }

    @Override
    public T last() {
        if (this.isEmpty()) {
            throw new EmptyCollectionException("Double Linked List : last()");
        }
        return this.rear.getValue();
    }

    @Override
    public boolean contains(T target) {
        Iterator<T> iter = this.iterator();
        while (iter.hasNext() == true) {
            T temp = iter.next();
            if (temp.equals(target)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean isEmpty() {
        return this.size == 0;
    }

    @Override
    public int size() {
        return this.size;
    }

    @Override
    public Iterator<T> iterator() {
        return new DoubleLinkedListIterator<>(this);
    }

    private class DoubleLinkedListIterator<T> implements Iterator<T> {

        //private int icount;
        private DoubleLinkedNode<T> current;

        public DoubleLinkedListIterator(DoubleLinkedList<T> lista) {
            //this.icount = lista.size;
            this.current = lista.front;
        }

        @Override
        public boolean hasNext() {
            return this.current != null;
        }

        @Override
        public T next() {
            T res = this.current.getValue();

            this.current = this.current.getNext();

            return res;
        }

    }

    @Override
    public String toString() {
        String str = "|";

        Iterator<T> iterator = this.iterator();
        while (iterator.hasNext()) {
            str = str + iterator.next() + "|";
        }

        return str;
    }

    public void recursivePrintAllFrontToRear(DoubleLinkedNode node) {
        if (node == null) {
            System.out.println("");
            return;
        } else {
            //A B C 
            System.out.print(node.getValue() + " ");
            recursivePrintAllFrontToRear(node.getNext());
            //System.out.print(node.getValue() + " ");
        }
    }

    public void recursivePrintAllRearToFront(DoubleLinkedNode node) {
        if (node == null) {
            System.out.println("");
            return;
        } else {
            //recursiveInvertedPrintAll(node.getNext());
            //System.out.print(node.getValue() + " ");

            //A B C 
            recursivePrintAllRearToFront(node.getPrevious());
            System.out.print(node.getValue() + " ");

        }
    }

    public UnorderedListADT reverse() {
        UnorderedListADT<T> list = new DoubleLinkedUnorderedList<>();

        this.reverseHelper(this.front, list);
        //System.out.println(list.toString());
        return list;
    }

    private void reverseHelper(DoubleLinkedNode node, UnorderedListADT lista) {
        if (node == null) {
            return;
        } else {

            reverseHelper(node.getNext(), lista);
            lista.addToRear(node.getValue());
        }
    }

    public void replace(T existingElement, T newElement) {
        this.replaceHelper(this.front, existingElement, newElement);
    }

    private void replaceHelper(DoubleLinkedNode<T> node, T existingElement, T newElement) {
        if (node == null) {
            return;
        } else {
            replaceHelper(node.getNext(), existingElement, newElement);
            if (node.getValue().equals(existingElement)) {
                node.setValue(newElement);
            }
        }
    }
}
