/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.DoubleLinkedList;


import ADT.OrderedListADT;
import ADT.UnorderedListADT;
import Models.Nodes.DoubleLinkedNode;
import java.util.Iterator;

/**
 *
 * @author tomaspendao
 * @param <T>
 */
public class OrderedDoubleLinkedList<T extends Comparable> extends DoubleLinkedList<T> implements OrderedListADT<T> {

    public OrderedDoubleLinkedList() {
        super();
    }

    @Override
    public void add(T element) {
        DoubleLinkedNode<T> newNode = new DoubleLinkedNode<>(element);
        DoubleLinkedNode<T> current = super.front;
        boolean flag = false;
        int i = 0;
        if (super.size() > 0) {
            while (i < super.size) {
                if (element.compareTo(current.getValue()) <= 0) {
                    flag = true;
                    break;
                } else {
                    current = current.getNext();
                    i++;
                }
            }
            if (flag == true) {
                if (current.equals(super.front)) {
                    newNode.setNext(super.front);
                    super.front.setPrevious(newNode);
                    super.front = newNode;
                } else if (current.equals(super.rear)) {
                    newNode.setNext(super.rear);
                    newNode.setPrevious(super.rear.getPrevious());
                    super.rear.setPrevious(newNode);
                    newNode.getPrevious().setNext(newNode);
                } else {
                    newNode.setNext(current);
                    newNode.setPrevious(current.getPrevious());
                    current.setPrevious(newNode);
                    newNode.getPrevious().setNext(newNode);
                }
            } else {
                super.rear.setNext(newNode);
                newNode.setPrevious(super.rear);
                super.rear = newNode;
            }
            super.modcount++;
            super.size++;
        } else {
            super.front = newNode;
            super.rear = newNode;
            super.modcount++;
            super.size++;
        }
    }
    
    public UnorderedListADT<T> invert(){
        UnorderedListADT<T> res = new DoubleLinkedUnorderedList<>();
        
        Iterator<T> iter1 = this.iterator();
        while(iter1.hasNext()){
            T value = iter1.next();
            res.addToFront(value);
        }
        
        return res;
    }

    public DoubleLinkedNode<T> getFront() {
        return front;
    }

    public DoubleLinkedNode<T> getRear() {
        return rear;
    }
    
    

}
