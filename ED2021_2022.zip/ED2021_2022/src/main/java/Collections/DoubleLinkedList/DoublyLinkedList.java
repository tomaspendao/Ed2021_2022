/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.DoubleLinkedList;

import Models.Nodes.DoubleLinkedNode;

/**
 *
 * @author tomaspendao
 */
public class DoublyLinkedList<T> {

    private DoubleLinkedNode<T> head;
    private DoubleLinkedNode<T> tail;
    private int size;

    public DoublyLinkedList() {
        this.size = 0;
        this.head = null;
        this.tail = null;
    }

    public DoublyLinkedList(T elem) {
        this.head = new DoubleLinkedNode<>(elem);
        this.tail = head;
        this.size++;
    }

    public void add(T elem) {
        DoubleLinkedNode<T> newHead = new DoubleLinkedNode<>(elem);
        //Se estiver vazia
        if (this.isEmpty() == true) {
            this.setHead(newHead);
            this.setTail(this.getHead());
            this.size++;
        } else {
            newHead.setNext(getHead());
            this.getHead().setPrevious(newHead);
            this.setHead(newHead);
            this.size++;
        }

    }

    public boolean remove(T elem) {
        //Se estiver vazia
        if (isEmpty() == true) {
            return false;
        }
        //Se tiver so 1 elemento
        if (this.size == 1) {
            this.setHead(null);
            this.setTail(null);
            this.size--;
            return true;
        }
        DoubleLinkedNode<T> toRemove = this.getHead();
        for (int i = 0; i < this.size; i++) {
            if (toRemove.getValue().equals(elem)) {
                break;
            }
            toRemove = toRemove.getNext();
        }
        if (toRemove == null) {
            return false;
        }
        if (toRemove.equals(this.getHead())) {
            return this.removeFirst();
        } else if (toRemove.equals(this.getTail())) {
            return this.removeLast();
        } else {
            toRemove.getPrevious().setNext(toRemove.getNext());
            toRemove.getNext().setPrevious(toRemove.getPrevious());
            toRemove.setNext(null);
            toRemove.setPrevious(null);
            this.size--;
            return true;
        }

    }

    public boolean removeFirst() {
        if (isEmpty() == true) {
            return false;
        }
        if (this.size == 1) {
            this.setHead(null);
            this.setTail(null);
            this.size--;
            return true;
        }
        this.setHead(this.getHead().getNext());
        this.getHead().getPrevious().setNext(null);
        this.getHead().setPrevious(null);
        this.size--;
        return true;
    }

    public boolean removeLast() {
        if (isEmpty() == true) {
            return false;
        }
        if (this.size == 1) {
            this.setHead(null);
            this.setTail(null);
            this.size--;
            return true;
        }
        this.setTail(this.getTail().getPrevious());
        this.getTail().getNext().setPrevious(null);
        this.getTail().setNext(null);
        this.size--;
        return true;
    }

    public void printAll() {
        if (isEmpty() != true) {
            DoubleLinkedNode<T> pos = this.getHead();
            for (int i = 0; i < this.size; i++) {
                System.out.print(pos.getValue() + ";");
                pos = pos.getNext();
            }
        }
    }

    public T[] toArray() {
        return toArrayOfElementsBetween(0, this.size - 1);
    }

    public T[] toArrayTillPos(int end) {
        return toArrayOfElementsBetween(0, end);
    }

    public T[] toArrayAfterPos(int start) {
        return toArrayOfElementsBetween(start, this.size - 1);
    }

    public T[] toArrayOfElementsBetween(int start, int end) {
        if (end >= this.size) {
            return null;
        }
        if (start > end) {
            int tempInt = start;
            start = end;
            end = tempInt;
        }
        int newSize = end - start + 1;
        Object[] array = new Object[newSize];

        DoubleLinkedNode<T> pos = this.getHead();
        //Tudo incluido
        int j = 0;
        for (int i = 0; i <= end; i++) {
            if (i >= start) {
                array[j] = pos.getValue();
                j++;
            }
            pos = pos.getNext();
        }

        return (T[]) array;
    }

    public DoublyLinkedList<T> justPares() {

        DoublyLinkedList<T> res = new DoublyLinkedList<>();
        DoubleLinkedNode<T> pos = this.getHead();
        for (int i = 0; i < this.size; i++) {

            if ((Integer) (pos.getValue()) % 2 == 0) {
                res.add(pos.getValue());
            }

            pos = pos.getNext();
        }

        return res;
    }

    public int removeExtras(T elem) {
        int kount = 0;

        DoubleLinkedNode<T> pos = this.getHead();
        int tempSize = this.size;
        for (int i = 0; i < tempSize; i++) {
            if (pos.getValue().equals(elem) == true) {
                if (kount == 0) {
                    kount++;
                    pos = pos.getNext();
                } else {
                    //remove(elem);
                    DoubleLinkedNode toRemove = pos;
                    pos = pos.getNext();
                    toRemove.getPrevious().setNext(toRemove.getNext());
                    if(toRemove.getNext() != null){
                        toRemove.getNext().setPrevious(toRemove.getPrevious());
                    }
                    toRemove.setNext(null);
                    toRemove.setPrevious(null);
                    this.size--;
                    kount++;
                }
            } else {
                pos = pos.getNext();
            }
        }
        return kount;
    }
    
    public int removeAllExtras(T elem) {
        int kount = 0;

        DoubleLinkedNode<T> pos = this.getHead();
        int tempSize = this.size;
        for (int i = 0; i < tempSize; i++) {
            if (pos.getValue().equals(elem) == true) {
                if (kount == 0) {
                    kount++;
                    pos = pos.getNext();
                } else {
                    remove(elem);
                    //this.size--;
                    kount++;
                }
            } else {
                pos = pos.getNext();
            }
        }
        
        return kount;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public DoubleLinkedNode<T> getHead() {
        return head;
    }

    public void setHead(DoubleLinkedNode<T> head) {
        this.head = head;
    }

    public DoubleLinkedNode<T> getTail() {
        return tail;
    }

    public void setTail(DoubleLinkedNode<T> tail) {
        this.tail = tail;
    }

}
