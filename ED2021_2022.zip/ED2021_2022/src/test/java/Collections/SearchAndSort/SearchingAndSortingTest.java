/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.SearchAndSort;

import Models.Carro;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author tomaspendao
 */
public class SearchingAndSortingTest {
    
    Carro[] carros;
    Carro carro1 = new Carro(4, "BMW", "3", "BB-99-AA", 80);
    Carro carro2 = new Carro(4, "BMW", "3", "BB-99-AA", 80);
    Carro carro3 = new Carro(4, "Tesla", "S", "AA-23-WE", 230);
    Carro carro4 = new Carro(4, "Porsche", "911", "CC-90-PP", 180);
    Carro carro5 = new Carro(4, "Citroen", "c3", "VB-00-Kl", 90);

    Carro carro7 = new Carro(4, "null", "null", "AA-00-AA", 0);

    @BeforeEach
    public void setUp() {
        carros = new Carro[5];
        carros[0] = carro1;
        carros[1] = carro2;
        carros[2] = carro3;
        carros[3] = carro4;
        carros[4] = carro5;
    }

    @AfterEach
    public void tearDown() {
        this.carros = null;
    }

    /**
     * Test of linearSearch method, of class SearchingAndSorting.
     */
    @Test
    public void testLinearSearch() {
        this.setUp();
        System.out.println("linearSearch");

        assertTrue(SearchingAndSorting.linearSearch(carros, 0, carros.length - 1, carro4));
        assertFalse(SearchingAndSorting.linearSearch(carros, 0, carros.length - 1, carro7));
        this.tearDown();
    }
    
    
}
