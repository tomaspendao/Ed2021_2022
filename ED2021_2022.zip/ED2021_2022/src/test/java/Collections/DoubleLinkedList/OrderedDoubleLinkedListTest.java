/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.DoubleLinkedList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author tomaspendao
 */
public class OrderedDoubleLinkedListTest {
    
    OrderedDoubleLinkedList<Integer> tester;
    
    @BeforeEach
    public void setUp() {
        System.out.println("\nRunning Set Up");
        this.tester = new OrderedDoubleLinkedList<>();
        this.tester.add(1);
        this.tester.add(100);
        this.tester.add(9);
        this.tester.add(5);
    }
    
    @AfterEach
    public void tearDown() {
        System.out.println("Running Tear Down\n");
        this.tester = null;
    }

    /**
     * Test of add method, of class OrderedDoubleLinkedList.
     */
    @Test
    public void testAdd() {
        this.tester = new OrderedDoubleLinkedList<>();
        System.out.println("add");
        this.tester.add(1);
        this.tester.add(100);
        this.tester.add(9);
        this.tester.add(5);
        
        assertEquals("|1|5|9|100|", this.tester.toString());
        assertEquals(4, this.tester.size());
        
        this.tearDown();
    }

    /**
     * Test of invert method, of class OrderedDoubleLinkedList.
     */
    @Test
    public void testInvert() {
        this.setUp();
        System.out.println("invert");
        assertEquals("|100|9|5|1|", this.tester.invert().toString());
        this.tearDown();
    }
    
}
