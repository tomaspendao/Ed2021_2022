/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.DoubleLinkedList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author tomaspendao
 */
public class DoublyLinkedListTest {

    DoublyLinkedList<Integer> tester;

    @BeforeEach
    public void setUp() {
        System.out.println("\nRunning Set Up");
        this.tester = new DoublyLinkedList<>();
        this.tester.add(1);
        this.tester.add(2);
        this.tester.add(3);
        this.tester.add(2);
        this.tester.add(1);
        this.tester.add(5);
        this.tester.add(2);

    }

    @AfterEach
    public void tearDown() {
        System.out.println("Running Tear Down\n");
        this.tester = null;
    }

    /**
     * Test of add method, of class DoublyLinkedList.
     */
    @Test
    public void testAdd() {
        System.out.println("add");
        this.tester = new DoublyLinkedList<>();
        this.tester.add(10);
        this.tester.add(5);
        this.tester.add(12);
        assertEquals(false, this.tester.isEmpty());
        assertEquals(12, this.tester.getHead().getValue());
        assertEquals(10, this.tester.getTail().getValue());
        //this.tester.printAll();
        this.tearDown();
    }

    /**
     * Test of remove method, of class DoublyLinkedList.
     */
    @Test
    public void testRemove() {
        this.setUp();
        System.out.println("remove");
        this.tester.printAll();
        System.out.println();
        assertTrue(this.tester.remove(1));
        this.tester.printAll();
        System.out.println();
        this.tearDown();
    }

    /**
     * Test of removeFirst method, of class DoublyLinkedList.
     */
    @Test
    public void testRemoveFirst() {
        this.setUp();
        System.out.println("removeFirst");
        this.tester.printAll();
        System.out.println();
        assertTrue(this.tester.removeFirst());
        this.tester.printAll();
        System.out.println();
        this.tearDown();
    }

    /**
     * Test of removeLast method, of class DoublyLinkedList.
     */
    @Test
    public void testRemoveLast() {
        this.setUp();
        System.out.println("removeLast");
        this.tester.printAll();
        System.out.println();
        assertTrue(this.tester.removeLast());
        this.tester.printAll();
        System.out.println();
        this.tearDown();
    }

    /**
     * Test of printAll method, of class DoublyLinkedList.
     */
    /*@Test
    public void testPrintAll() {
        System.out.println("printAll");
        DoublyLinkedList instance = new DoublyLinkedList();
        instance.printAll();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }*/

    /**
     * Test of toArray method, of class DoublyLinkedList.
     */
    /*@Test
    public void testToArray() {
        System.out.println("toArray");
        DoublyLinkedList instance = new DoublyLinkedList();
        Object[] expResult = null;
        Object[] result = instance.toArray();
        assertArrayEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }*/

    /**
     * Test of toArrayTillPos method, of class DoublyLinkedList.
     */
    /*@Test
    public void testToArrayTillPos() {
        System.out.println("toArrayTillPos");
        int end = 0;
        DoublyLinkedList instance = new DoublyLinkedList();
        Object[] expResult = null;
        Object[] result = instance.toArrayTillPos(end);
        assertArrayEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }*/

    /**
     * Test of toArrayAfterPos method, of class DoublyLinkedList.
     */
    /*@Test
    public void testToArrayAfterPos() {
        System.out.println("toArrayAfterPos");
        int start = 0;
        DoublyLinkedList instance = new DoublyLinkedList();
        Object[] expResult = null;
        Object[] result = instance.toArrayAfterPos(start);
        assertArrayEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }*/

    /**
     * Test of toArrayOfElementsBetween method, of class DoublyLinkedList.
     */
    /*@Test
    public void testToArrayOfElementsBetween() {
        System.out.println("toArrayOfElementsBetween");
        int start = 0;
        int end = 0;
        DoublyLinkedList instance = new DoublyLinkedList();
        Object[] expResult = null;
        Object[] result = instance.toArrayOfElementsBetween(start, end);
        assertArrayEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }*/

    /**
     * Test of justPares method, of class DoublyLinkedList.
     */
    /*@Test
    public void testJustPares() {
        System.out.println("justPares");
        DoublyLinkedList instance = new DoublyLinkedList();
        DoublyLinkedList expResult = null;
        DoublyLinkedList result = instance.justPares();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }*/

    /**
     * Test of removeExtras method, of class DoublyLinkedList.
     */
    @Test
    public void testRemoveExtras() {
        this.setUp();
        System.out.println("removeExtras");
        this.tester.printAll();
        System.out.println();
        assertEquals(3,this.tester.removeExtras(2));
        this.tester.printAll();
        System.out.println();
        this.tearDown();
    }

    /**
     * Test of removeAllExtras method, of class DoublyLinkedList.
     */
    @Test
    public void testRemoveAllExtras() {
        this.setUp();
        System.out.println("removeAllExtras");
        this.tester.printAll();
        System.out.println();
        assertEquals(5,this.tester.removeAllExtras(2));
        this.tester.printAll();
        System.out.println();
        this.tearDown();
    }

    /**
     * Test of isEmpty method, of class DoublyLinkedList.
     */
    @Test
    public void testIsEmpty() {
        this.setUp();
        System.out.println("isEmpty");
        assertEquals(false, this.tester.isEmpty());
        this.tearDown();
    }

    /**
     * Test of getHead method, of class DoublyLinkedList.
     */
    @Test
    public void testGetHead() {
        this.setUp();
        System.out.println("getHead");
        assertEquals(2, this.tester.getHead().getValue());
        this.tearDown();
    }

    /**
     * Test of setHead method, of class DoublyLinkedList.
     */
    /*@Test
    public void testSetHead() {
        System.out.println("setHead");
        DoublyLinkedList instance = new DoublyLinkedList();
        instance.setHead(null);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }*/

    /**
     * Test of getTail method, of class DoublyLinkedList.
     */
    @Test
    public void testGetTail() {
        this.setUp();
        System.out.println("getTail");
        assertEquals(1, this.tester.getTail().getValue());
        this.tearDown();
    }

    /**
     * Test of setTail method, of class DoublyLinkedList.
     */
    /*@Test
    public void testSetTail() {
        System.out.println("setTail");
        DoublyLinkedList instance = new DoublyLinkedList();
        instance.setTail(null);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }*/

}
