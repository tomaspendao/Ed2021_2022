/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.DoubleLinkedList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author tomaspendao
 */
public class DoubleLinkedUnorderedListTest {

    DoubleLinkedUnorderedList<Integer> tester;
    
    @BeforeEach
    public void setUp() {
        System.out.println("\nRunning Set Up");
        this.tester = new DoubleLinkedUnorderedList<>();
        
    }
    
    @AfterEach
    public void tearDown() {
        System.out.println("Running Tear Down\n");
        this.tester = null;
    }

    /**
     * Test of addToFront method, of class DoubleLinkedUnorderedList.
     */
    @Test
    public void testAddToFront() {
        this.setUp();
        System.out.println("addToFront");
        this.tester.addToFront(1);
        this.tester.addToFront(2);
        this.tester.addToFront(3);
        assertEquals(3, this.tester.first());
        assertEquals(1, this.tester.last());
        assertEquals("|3|2|1|", this.tester.toString());
        
        this.tearDown();
    }

    /**
     * Test of addToRear method, of class DoubleLinkedUnorderedList.
     */
    @Test
    public void testAddToRear() {
        this.setUp();
        System.out.println("addToRear");
        this.tester.addToRear(1);
        this.tester.addToRear(2);
        this.tester.addToRear(3);
        assertEquals(1, this.tester.first());
        assertEquals(3, this.tester.last());
        assertEquals("|1|2|3|", this.tester.toString());
        
        this.tearDown();
    }

    /**
     * Test of addAfter method, of class DoubleLinkedUnorderedList.
     */
    @Test
    public void testAddAfter() {
        System.out.println("addAfter");
        this.setUp();
        System.out.println("addAfter");
        this.tester.addToFront(1);
        this.tester.addAfter(3,1);
        this.tester.addAfter(2,1);
        this.tester.addAfter(5,2);
        assertEquals(1, this.tester.first());
        assertEquals(3, this.tester.last());
        assertEquals("|1|2|5|3|", this.tester.toString());
        
        this.tearDown();
    }
    
    
    /**
     * Test of recursivePrintAll method, of class DoubleLinkedUnorderedList.
     */
    /*
    @Test
    public void testRecursivePrintAll() {
        this.setUp();
        this.tester.addToRear(1);
        this.tester.addToRear(2);
        this.tester.addToRear(3);
        System.out.println("recursivePrintAll");
        tester.recursivePrintAllFrontToRear(this.tester.front);
        this.tearDown();
    }

    /**
     * Test of recursiveInvertedPrintAll method, of class DoubleLinkedUnorderedList.
     */
    /*
    @Test
    public void testRecursiveInvertedPrintAll() {
        this.setUp();
        this.tester.addToRear(1);
        this.tester.addToRear(2);
        this.tester.addToRear(3);
        System.out.println("recursiveInvertedPrintAll");
        tester.recursivePrintAllRearToFront(this.tester.rear);
        this.tearDown();
    }
    */
    
}
