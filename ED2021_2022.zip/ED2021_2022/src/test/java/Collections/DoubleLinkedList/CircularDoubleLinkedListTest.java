/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.DoubleLinkedList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author tomaspendao
 */
public class CircularDoubleLinkedListTest {
    
    CircularDoubleLinkedList<Integer> tester;
    
    @BeforeEach
    public void setUp() {
        System.out.println("Running Set Up");
        this.tester = new CircularDoubleLinkedList<>();
        this.tester.addToFront(1);
        this.tester.addToFront(2);
        this.tester.addToFront(3);
        
    }
    
    @AfterEach
    public void tearDown() {
        System.out.println("Running Tear Down");
        this.tester = null;
    }

    /**
     * Test of removeFirst method, of class CircularDoubleLinkedList.
     */
    @Test
    public void testRemoveFirst() {
        this.setUp();
        System.out.println("removeFirst");
        assertEquals(3, this.tester.removeFirst());
        assertEquals("|2|1|", this.tester.toString());
        this.tearDown();
    }

    /**
     * Test of removeLast method, of class CircularDoubleLinkedList.
     */
    @Test
    public void testRemoveLast() {
        this.setUp();
        System.out.println("removeLast");
        assertEquals(1, this.tester.removeLast());
        assertEquals("|3|2|", this.tester.toString());
        this.tearDown();
    }

    /**
     * Test of addToFront method, of class CircularDoubleLinkedList.
     */
    @Test
    public void testAddToFront() {
        this.setUp();
        System.out.println("addToFront");
        assertEquals("|3|2|1|", this.tester.toString());
        this.tester.addToFront(5);
        assertEquals("|5|3|2|1|", this.tester.toString());
        this.tearDown();
    }

    /**
     * Test of addToRear method, of class CircularDoubleLinkedList.
     */
    @Test
    public void testAddToRear() {
        this.setUp();
        System.out.println("addToRear");
        assertEquals("|3|2|1|", this.tester.toString());
        this.tester.addToRear(5);
        assertEquals("|3|2|1|5|", this.tester.toString());
        this.tearDown();
    }

    /**
     * Test of toString method, of class CircularDoubleLinkedList.
     */
    @Test
    public void testToString() {
        this.setUp();
        System.out.println("toString");
        assertEquals("|3|2|1|", this.tester.toString());
        this.tearDown();
    }
    
}
