/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.DoubleLinkedList;

import ADT.UnorderedListADT;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author tomaspendao
 */
public class DoubleLinkedListTest {
    
    DoubleLinkedUnorderedList<Integer> tester;
    
    @BeforeEach
    public void setUp() {
        System.out.println("\nRunning Set Up");
        tester = new DoubleLinkedUnorderedList<>();
        tester.addToFront(1);
        tester.addToFront(2);
        tester.addToFront(3);
    }
    
    @AfterEach
    public void tearDown() {
        System.out.println("Running Tear Down\n");
        tester = null;
    }

    /**
     * Test of removeFirst method, of class DoubleLinkedList.
     */
    @Test
    public void testRemoveFirst() {
        this.setUp();
        System.out.println("removeFirst");
        assertEquals(3, this.tester.removeFirst());
        assertEquals("|2|1|", this.tester.toString());
        this.tearDown();
    }

    /**
     * Test of removeLast method, of class DoubleLinkedList.
     */
    @Test
    public void testRemoveLast() {
        this.setUp();
        System.out.println("removeLast");
        assertEquals(1, this.tester.removeLast());
        assertEquals("|3|2|", this.tester.toString());
        this.tearDown();
    }

    /**
     * Test of remove method, of class DoubleLinkedList.
     */
    @Test
    public void testRemove() {
        this.setUp();
        System.out.println("remove");
        assertEquals(2, this.tester.remove(2));
        assertEquals("|3|1|", this.tester.toString());
        this.tearDown();
    }

    /**
     * Test of first method, of class DoubleLinkedList.
     */
    @Test
    public void testFirst() {
        this.setUp();
        System.out.println("first");
        assertEquals(3, this.tester.first());
        this.tearDown();
    }

    /**
     * Test of last method, of class DoubleLinkedList.
     */
    @Test
    public void testLast() {
        this.setUp();
        System.out.println("last");
        assertEquals(1, this.tester.last());
        this.tearDown();
    }

    /**
     * Test of contains method, of class DoubleLinkedList.
     */
    @Test
    public void testContains() {
        this.setUp();
        System.out.println("contains");
        assertEquals(true, this.tester.contains(2));
        assertEquals(false, this.tester.contains(10));
        this.tearDown();
    }

    /**
     * Test of isEmpty method, of class DoubleLinkedList.
     */
    @Test
    public void testIsEmpty() {
        this.setUp();
        System.out.println("isEmpty");
        assertEquals(false, this.tester.isEmpty());
        this.tearDown();
    }

    /**
     * Test of size method, of class DoubleLinkedList.
     */
    @Test
    public void testSize() {
        this.setUp();
        System.out.println("size");
        assertEquals(3, this.tester.size());
        this.tearDown();
    }

    /**
     * Test of toString method, of class DoubleLinkedList.
     */
    @Test
    public void testToString() {
        this.setUp();
        System.out.println("toString");
        assertEquals("|3|2|1|", this.tester.toString());
        this.tearDown();
    }

    /**
     * Test of recursivePrintAll method, of class DoubleLinkedList.
     */
    @Test
    public void testRecursivePrintAllFrontToRear() {
        this.setUp();
        System.out.println("recursivePrintAll");
        tester.recursivePrintAllFrontToRear(this.tester.front);
        this.tearDown();
    }

    /**
     * Test of recursiveInvertedPrintAll method, of class DoubleLinkedList.
     */
    @Test
    public void testRecursivePrintAllRearToFront() {
        this.setUp();
        System.out.println("recursiveInvertedPrintAll");
        tester.recursivePrintAllRearToFront(this.tester.rear);
        this.tearDown();
    }

    /**
     * Test of reverse method, of class DoubleLinkedList.
     */
    @Test
    public void testReverse() {
        this.setUp();
        System.out.println("reverse");
        UnorderedListADT lista = this.tester.reverse();
        assertEquals("|1|2|3|", lista.toString());
        this.tearDown();
    }

    /**
     * Test of iterator method, of class DoubleLinkedList.
     */
    @Test
    public void testIterator() {
        //fail("Iterator!");
    }

    /**
     * Test of replace method, of class DoubleLinkedList.
     */
    @Test
    public void testReplace() {
        this.setUp();
        System.out.println("replace");
        this.tester.addToFront(2);
        this.tester.replace(2, 5);
        assertEquals("|5|3|5|1|", tester.toString());
        this.tearDown();
    }
    
}
