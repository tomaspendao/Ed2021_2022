/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.Array;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author tomaspendao
 */
public class ArraySmackStackTest {
    
    ArraySmackStack<Integer> tester;
    
    @BeforeEach
    public void setUp() {
        System.out.println("\nRunning Set Up");
        this.tester = new ArraySmackStack<>();
        this.tester.push(1);
        this.tester.push(2);
        this.tester.push(3);
    }
    
    @AfterEach
    public void tearDown() {
        System.out.println("Running Tear Down\n");
        this.tester = null;
    }

    /**
     * Test of smack method, of class ArraySmackStack.
     */
    @Test
    public void testSmack() {
        this.setUp();
        System.out.println("smack");
        assertEquals(1, this.tester.smack());
        assertEquals("2 | 3 | ", this.tester.toString());
        this.tearDown();
    }
    
}
