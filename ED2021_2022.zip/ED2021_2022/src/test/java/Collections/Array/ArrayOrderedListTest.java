/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.Array;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.Test;

/**
 *
 * @author tomaspendao
 */
public class ArrayOrderedListTest {
    
    ArrayOrderedList<Integer> tester;

    public void setUp() {
        System.out.println("\nRunning Set Up");
        tester = new ArrayOrderedList<>();
    }

    public void tearDown() {
        System.out.println("Running Tear Down\n");
        tester = null;
    }

    /**
     * Test of add method, of class ArrayOrderedList.
     */
    @Test
    public void testAdd() {
        this.setUp();
        System.out.println("add");
        tester.add(1);
        tester.add(2);
        tester.add(1000);
        tester.add(2);
        assertEquals("|1|2|2|1000|",tester.toString());
        assertEquals(4, tester.size(), "Checking if the size of ArrayOrderedList is 4");
        this.tearDown();
    }
    
}
