/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.Array;

import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author tomaspendao
 */
public class ArrayUnorderedListTest {
    
    ArrayUnorderedList<Integer> tester;
    
    public void setUp() throws Exception {
        System.out.println("\nRunning Set Up");
        tester = new ArrayUnorderedList<>();
    }

    public void tearDown() throws Exception {
        System.out.println("Running Tear Down\n");
        tester = null;
    }

    /**
     * Test of addToFront method, of class ArrayUnorderedList.
     */
    @Test
    public void testAddToFront() throws Exception {
        this.setUp();
        System.out.println("addToFront");
        
        tester.addToFront(1);
        tester.addToFront(10);
        tester.addToFront(5);
        tester.addToFront(12);
        
        assertEquals("|12|5|10|1|", tester.toString());
        assertEquals(4, tester.size());
        assertEquals(12, tester.first());
        assertEquals(1, tester.last());
        
        this.tearDown();
    }

    /**
     * Test of addToRear method, of class ArrayUnorderedList.
     */
    @Test
    public void testAddToRear() throws Exception {
        this.setUp();
        System.out.println("addToRear");
        
        tester.addToRear(1);
        tester.addToRear(10);
        tester.addToRear(5);
        tester.addToRear(12);
        
        assertEquals("|1|10|5|12|", tester.toString());
        assertEquals(4, tester.size());
        assertEquals(1, tester.first());
        assertEquals(12, tester.last());
        
        this.tearDown();        
    }

    /**
     * Test of addAfter method, of class ArrayUnorderedList.
     */
    @Test
    public void testAddAfter() throws Exception {
        this.setUp();
        System.out.println("addAfter");
        tester.addToFront(7);
        tester.addAfter(1,7);
        tester.addAfter(10,1);
        tester.addAfter(5,1);
        tester.addAfter(12,10);
        
        assertEquals("|7|1|5|10|12|", tester.toString());
        assertEquals(5, tester.size());
        assertEquals(7, tester.first());
        assertEquals(12, tester.last());
        
        this.tearDown();
    }
    
}
