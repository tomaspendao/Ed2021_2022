/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.Array;

import java.util.Iterator;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author tomaspendao
 */
public class ArrayBinaryTreeTest {
    
    ArrayBinarySearchTree<String> teste;
    
    @Before
    public void setUp() {
        System.out.println("Running Set Up\n");
        teste = new ArrayBinarySearchTree<>();
        teste.addElement("D");
        teste.addElement("B");
        teste.addElement("F");
        teste.addElement("E");
        teste.addElement("A");
        teste.addElement("C");
    }
    
    @After
    public void tearDown() {
        System.out.println("\nRunning Tear Down");
        this.teste = null;
    }

    /**
     * Test of getRoot method, of class ArrayBinaryTree.
     */
    @Test
    public void testGetRoot() {
        System.out.println("getRoot");
        assertEquals("D", teste.getRoot());
    }

    /**
     * Test of isEmpty method, of class ArrayBinaryTree.
     */
    @Test
    public void testIsEmpty() {
        System.out.println("isEmpty");
        assertFalse(teste.isEmpty());
    }

    /**
     * Test of size method, of class ArrayBinaryTree.
     */
    @Test
    public void testSize() {
        System.out.println("size");
        assertEquals(6, teste.size());
    }

    /**
     * Test of contains method, of class ArrayBinaryTree.
     */
    @Test
    public void testContains() {
        System.out.println("contains");
        assertTrue(teste.contains("A"));
        assertFalse(teste.contains("Z"));
    }

    /**
     * Test of find method, of class ArrayBinaryTree.
     */
    @Test
    public void testFind() {
        System.out.println("find");
        assertEquals("B", teste.find("B"));
    }

    /**
     * Test of iteratorInOrder method, of class ArrayBinaryTree.
     */
    @Test
    public void testIteratorInOrder() {
        System.out.println("iteratorInOrder");
        Iterator iter = teste.iteratorInOrder();
        
        assertEquals("A", iter.next());
        assertEquals("B", iter.next());
        assertEquals("C", iter.next());
        assertEquals("D", iter.next());
        assertEquals("E", iter.next());
        assertEquals("F", iter.next()); 
    }

    /**
     * Test of iteratorPreOrder method, of class ArrayBinaryTree.
     */
    @Test
    public void testIteratorPreOrder() {
        System.out.println("iteratorPreOrder");

        Iterator iter = teste.iteratorPreOrder();
        
        assertEquals("D", iter.next());
        assertEquals("B", iter.next());
        assertEquals("A", iter.next());
        assertEquals("C", iter.next());
        assertEquals("F", iter.next());
        assertEquals("E", iter.next());
    }

    /**
     * Test of iteratorPostOrder method, of class ArrayBinaryTree.
     */
    @Test
    public void testIteratorPostOrder() {
        System.out.println("iteratorPostOrder");

        Iterator iter = teste.iteratorPostOrder();
        
        assertEquals("A", iter.next());
        assertEquals("C", iter.next());
        assertEquals("B", iter.next());
        assertEquals("E", iter.next());
        assertEquals("F", iter.next());
        assertEquals("D", iter.next());
    }

    /**
     * Test of iteratorLevelOrder method, of class ArrayBinaryTree.
     */
    @Test
    public void testIteratorLevelOrder() {
        System.out.println("iteratorLevelOrder");

        Iterator iter = teste.iteratorLevelOrder();
        
        assertEquals("D", iter.next());
        assertEquals("B", iter.next());
        assertEquals("F", iter.next());
        assertEquals("A", iter.next());
        assertEquals("C", iter.next());
        assertEquals("E", iter.next());
    }

    /**
     * Test of expandCapacity method, of class ArrayBinaryTree.
     */
    @Test
    public void testExpandCapacity() {
        /*for (int i = 0; i < 50; i++) {
            teste.addElement("Z");
        }*/
        teste.addElement("Z");
        teste.addElement("Y");
        assertEquals(8, teste.size());
    }
    
}
