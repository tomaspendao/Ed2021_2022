/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.Array;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author tomaspendao
 */
public class PriorityQueueTest {
    
    PriorityQueue<Integer> teste;
    
    @Before
    public void setUp() {
        teste = new PriorityQueue<>();
        teste.addElement(3, 3);
        teste.addElement(4, 2);
        teste.addElement(5, 1);
        teste.addElement(6, 2);
    }
    
    @After
    public void tearDown() {
        teste = null;
    }

    /**
     * Test of removeNext method, of class PriorityQueue.
     */
    @Test
    public void testRemoveNext() {
        System.out.println("removeNext");
        assertEquals((Integer)5, teste.removeNext());
    }

    /**
     * Test of addElement method, of class PriorityQueue.
     */
    @Test
    public void testAddElement() {
        System.out.println("addElement");
        teste.addElement(1,1);
        assertEquals((Integer)5, teste.findMin().getElement());
        teste.removeNext();
        assertEquals((Integer)1, teste.findMin().getElement());
    }
    
}
