/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.Array;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author tomaspendao
 */
public class CircularArrayQueueTest {
    
    CircularArrayQueue<Integer> tester;
    
    @BeforeEach
    public void setUp() {
        System.out.println("\nRunning Set Up");
        this.tester = new CircularArrayQueue<>();
        this.tester.enqueue(1);
        this.tester.enqueue(2);
        this.tester.enqueue(3);
    }
    
    @AfterEach
    public void tearDown() {
        System.out.println("Running Tear Down\n");
        tester = null;
    }

    /**
     * Test of enqueue method, of class CircularArrayQueue.
     */
    @Test
    public void testEnqueue() {
        this.tester = new CircularArrayQueue<>();
        System.out.println("enqueue");
        this.tester.enqueue(1);
        this.tester.enqueue(2);
        this.tester.enqueue(3);
        assertEquals(1,this.tester.first());
        assertEquals("3;2;1;", this.tester.toString());
        this.tearDown();
    }

    /**
     * Test of dequeue method, of class CircularArrayQueue.
     */
    @Test
    public void testDequeue() {
        this.setUp();
        System.out.println("dequeue");
        assertEquals(1,this.tester.dequeue());
        assertEquals(2,this.tester.first());
        assertEquals("3;2;", this.tester.toString());
        this.tearDown();
    }

    /**
     * Test of first method, of class CircularArrayQueue.
     */
    @Test
    public void testFirst() {
        this.setUp();
        System.out.println("first");
        assertEquals(1, this.tester.first());
        this.tearDown();
    }

    /**
     * Test of isEmpty method, of class CircularArrayQueue.
     */
    @Test
    public void testIsEmpty() {
        this.setUp();
        System.out.println("isEmpty");
        assertEquals(false, this.tester.isEmpty());
        this.tearDown();
    }

    /**
     * Test of size method, of class CircularArrayQueue.
     */
    @Test
    public void testSize() {
        this.setUp();
        System.out.println("size");
        assertEquals(3, this.tester.size());
        this.tearDown();
    }

    /**
     * Test of toString method, of class CircularArrayQueue.
     */
    @Test
    public void testToString() {
        this.setUp();
        System.out.println("toString");
        assertEquals("3;2;1;",this.tester.toString());
        this.tearDown();
    }
    
}
