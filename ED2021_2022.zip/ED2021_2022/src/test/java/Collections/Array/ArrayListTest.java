/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.Array;

import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author tomaspendao
 */
public class ArrayListTest {
    
    ArrayUnorderedList<Integer> tester;
    
    public void setUp() {
        System.out.println("\nRunning Set Up");
        tester = new ArrayUnorderedList<>();
        tester.addToRear(1);
        tester.addToRear(2);
        tester.addToRear(2);
        tester.addToRear(1000);
    }
    
    public void tearDown() {
        System.out.println("Running Tear Down\n");
        this.tester = null;
    }

    @Test
    public void testContains() throws Exception {
        this.setUp();
        System.out.println("Contains");
        assertEquals(true,tester.contains(2), "Checking if ArrayOrderedList Contains value is 2");
        this.tearDown();
    }
    
    //first
    
    @Test
    public void testFirst() throws Exception {
        this.setUp();
        System.out.println("First");
        assertEquals(1,tester.first(), "Checking if ArrayOrderedList first value is 1");
        this.tearDown();
    }
    
    //isEmpty
    
    @Test
    public void testIsEmpty() throws Exception {
        this.setUp();
        System.out.println("isEmpty");
        assertEquals(false,tester.isEmpty(), "Checking if ArrayOrderedList is empty");
        this.tearDown();
    }
    
    //last
    
    @Test
    public void testLast() throws Exception {
        this.setUp();
        System.out.println("Last");
        assertEquals(1000,tester.last(), "Checking if ArrayOrderedList last value is 1000");
        this.tearDown();
    }
    
    //remove
    
    @Test
    public void testRemove() throws Exception {
        this.setUp();
        System.out.println("Remove");
        assertEquals(2,tester.remove(2));
        assertEquals("|1|2|1000|",tester.toString());
        assertEquals(3,tester.size(), "Checking if ArrayOrderedList size is 3 after removing value 2");
        this.tearDown();
    }
    
    //removeFirst
    
    @Test
    public void testRemoveFirst() throws Exception {
        this.setUp();
        System.out.println("RemoveFirst");
        assertEquals(1,tester.removeFirst());
        assertEquals("|2|2|1000|",tester.toString());
        assertEquals(3,tester.size(), "Checking if ArrayOrderedList size is 3 after removing first value");
        this.tearDown();
    }
    
    //removeLast
    
    @Test
    public void testRemoveLast() throws Exception {
        this.setUp();
        System.out.println("RemoveLast");
        assertEquals(1000,tester.removeLast());
        assertEquals("|1|2|2|",tester.toString());
        assertEquals(3,tester.size(), "Checking if ArrayOrderedList size is 3 after removing first value");
        this.tearDown();
    }
    
    //size
    
    @Test
    public void testSize() throws Exception {
        this.setUp();
        System.out.println("Size");
        assertEquals(4,tester.size(), "Checking if ArrayOrderedList size is 4");
        this.tearDown();
    }
    
    @Test
    public void testToString() throws Exception {
        this.setUp();
        System.out.println("toString");
        assertEquals("|1|2|2|1000|",tester.toString());
        this.tearDown();
    }

    /**
     * Test of iterator method, of class ArrayList.
     */
    /*@Test
    public void testIterator() {
        System.out.println("iterator");
        ArrayList instance = new ArrayListImpl();
        Iterator expResult = null;
        Iterator result = instance.iterator();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }*/

    /**
     * Test of expandCapacity method, of class ArrayList.
     */
    /*@Test
    public void testExpandCapacity() {
        this.setUp();
        System.out.println("expandCapacity");
        System.out.println(this.tester.list.length);
        int len = this.tester.list.length;
        this.tester.expandCapacity();
        assertEquals(len*2, this.tester.list.length);
        this.tearDown();
    }*/

    /**
     * Test of shiftToTheRightFromTheLeft method, of class ArrayList.
     */
    @Test
    public void testShiftToTheRightFromTheLeft() {
        this.setUp();
        System.out.println("shiftToTheRightFromTheLeft");
        assertEquals("|1|2|2|1000|",tester.toString());
        this.tester.shiftToTheRightFromTheLeft(1);
        assertEquals("|1|2|2|2|1000|",tester.toString());
        this.tearDown();
    }
    
}
