/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.Array;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author tomaspendao
 */
public class ArrayStackTest {
    
    ArrayStack<Integer> testStack;
    
    @BeforeEach
    public void setUp() {
        System.out.println("\nRunning Set Up");
        this.testStack = new ArrayStack<>();
        this.testStack.push(10);
        this.testStack.push(20);
        this.testStack.push(5);
    }
    
    @AfterEach
    public void tearDown() {
        System.out.println("Running Tear Down\n");
        testStack = null;
    }

    /**
     * Test of push method, of class ArrayStack.
     */
    @Test
    public void testPush() {
        this.testStack = new ArraySmackStack<>();
        
        System.out.println("push");
        this.testStack.push(10);
        this.testStack.push(2);
        this.testStack.push(3);
        assertEquals(false, testStack.isEmpty());
        assertEquals(3, testStack.peek());
        assertEquals("10 | 2 | 3 | ", testStack.toString());
        
        this.tearDown();
    }

    /**
     * Test of pop method, of class ArrayStack.
     */
    @Test
    public void testPop() {
        this.setUp();
        
        System.out.println("pop");
        
        assertEquals("10 | 20 | 5 | ", testStack.toString(), "Test if the stack has the right values");
        assertEquals(5, this.testStack.pop(), "If pop value is 5");
        assertEquals(2, this.testStack.size(), "If stack size is 2");
        assertEquals("10 | 20 | ", testStack.toString(), "Test if the stack has the right values");
        assertEquals(20, this.testStack.pop(), "If pop value is 20");
        assertEquals(10, this.testStack.pop(), "If pop value is 10");
        
        this.tearDown();
    }

    /**
     * Test of peek method, of class ArrayStack.
     */
    @Test
    public void testPeek() {
        this.setUp();
        System.out.println("peek");
        assertEquals("10 | 20 | 5 | ", testStack.toString(), "Test if the stack has the right values");
        assertEquals(5, this.testStack.peek(), "Test if the peek value is 5");
        this.testStack.pop();
        assertEquals(20, this.testStack.peek(), "Test if the peek value is 20");
        this.tearDown();
    }

    /**
     * Test of isEmpty method, of class ArrayStack.
     */
    @Test
    public void testIsEmpty() {
        this.testStack = new ArraySmackStack<>();
        assertEquals(true, this.testStack.isEmpty(), "Test if the stack is empty");
        this.tearDown();
        this.setUp();
        System.out.println("isEmpty");
        assertEquals(false, this.testStack.isEmpty(), "Test if the stack is not empty");
        this.tearDown();
    }

    /**
     * Test of size method, of class ArrayStack.
     */
    @Test
    public void testSize() {
        this.testStack = new ArraySmackStack<>();
        assertEquals(0, this.testStack.size(), "Test if the stack size is 0");
        this.tearDown();
        this.setUp();
        System.out.println("size");
        assertEquals(3, this.testStack.size(), "Test if the stack size is 4");
        this.tearDown();
    }

    /**
     * Test of toString method, of class ArrayStack.
     */
    @Test
    public void testToString() {
        this.testStack = new ArraySmackStack<>();
        assertEquals("", this.testStack.toString(), "Test the stack values");
        this.tearDown();
        this.setUp();
        System.out.println("toString");
        assertEquals("10 | 20 | 5 | ", this.testStack.toString(), "Test the stack values");
        this.tearDown();
    }
    
}
