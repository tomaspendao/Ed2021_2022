/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.LinkedList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author tomaspendao
 */
public class LinkedQueueTest {

    LinkedQueue<Integer> tester;

    @BeforeEach
    public void setUp() {
        System.out.println("\nRunning Set Up");
        this.tester = new LinkedQueue<>();
        this.tester.enqueue(1);
        this.tester.enqueue(2);
        this.tester.enqueue(3);
    }

    @AfterEach
    public void tearDown() {
        System.out.println("Running Tear Down\n");
        this.tester = null;
    }

    /**
     * Test of enqueue method, of class LinkedQueue.
     */
    @Test
    public void testEnqueue() {
        this.setUp();
        System.out.println("enqueue");
        this.tester.enqueue(99);
        assertEquals("99 3 2 1 ", this.tester.toString());
        this.tearDown();
    }

    /**
     * Test of dequeue method, of class LinkedQueue.
     */
    @Test
    public void testDequeue() {
        this.setUp();
        System.out.println("dequeue");
        assertEquals(1, this.tester.dequeue());
        assertEquals("3 2 ", this.tester.toString());
        this.tearDown();
    }

    /**
     * Test of first method, of class LinkedQueue.
     */
    @Test
    public void testFirst() {
        this.setUp();
        System.out.println("first");
        assertEquals(1, this.tester.first());
        this.tearDown();
    }

    /**
     * Test of isEmpty method, of class LinkedQueue.
     */
    @Test
    public void testIsEmpty() {
        this.tester = new LinkedQueue<>();
        assertTrue(this.tester.isEmpty());
        this.tearDown();
        this.setUp();
        System.out.println("isEmpty");
        assertFalse(this.tester.isEmpty());
        this.tearDown();
    }

    /**
     * Test of size method, of class LinkedQueue.
     */
    @Test
    public void testSize() {
        this.tester = new LinkedQueue<>();
        assertEquals(0, this.tester.size());
        this.tearDown();
        this.setUp();
        System.out.println("size");
        assertEquals(3, this.tester.size());
        this.tearDown();
    }

    /**
     * Test of toString method, of class LinkedQueue.
     */
    @Test
    public void testToString() {
        this.setUp();
        System.out.println("toString");
        assertEquals("3 2 1 ", this.tester.toString());
        this.tearDown();
    }

    /**
     * Test of recursivePrintAll method, of class LinkedQueue.
     */
    @Test
    public void testRecursivePrintAll() {
        this.setUp();
        System.out.println("recursivePrintAll");
        this.tester.recursivePrintAll(tester.front);
        this.tearDown();
    }

    /**
     * Test of recursiveInvertedPrintAll method, of class LinkedQueue.
     */
    @Test
    public void testRecursiveInvertedPrintAll() {
        this.setUp();
        System.out.println("recursiveInvertedPrintAll");
        this.tester.recursiveInvertedPrintAll(tester.front);
        this.tearDown();
    }

    /**
     * Test of recursiveReverse method, of class LinkedQueue.
     */
    @Test
    public void testRecursiveReverse() {
        this.setUp();
        System.out.println("recursiveReverse");
        this.tester.recursiveReverse();
        assertEquals("1 2 3 ", this.tester.toString());
        this.tearDown();
    }

}
