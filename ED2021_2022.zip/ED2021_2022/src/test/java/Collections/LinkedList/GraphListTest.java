/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package Collections.LinkedList;

import java.util.Iterator;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Tomás Pendão
 */
public class GraphListTest {

    GraphList<Integer> graph;
    GraphList<String> graph2;

    public void setUp() {
        graph = new GraphList<>();
        graph.addVertex(2);
        graph.addVertex(3);
        graph.addVertex(4);
        graph.addVertex(5);
    }

    public void setUp2() {
        graph2 = new GraphList<>();
        graph2.addVertex("A");
        graph2.addVertex("B");
        graph2.addVertex("C");
        graph2.addVertex("D");
        graph2.addVertex("E");
        graph2.addVertex("F");

        this.graph2.addEdge("A", "B");
        this.graph2.addEdge("A", "C");
        this.graph2.addEdge("B", "D");
        this.graph2.addEdge("C", "E");
        this.graph2.addEdge("C", "F");
    }

    public void tearDown() {
        graph = null;
    }

    public void tearDown2() {
        graph2 = null;
    }

    /**
     * Test of addVertex method, of class GraphList.
     */
    @Test
    public void testAddVertex() {
        graph = new GraphList<>();
        System.out.println("addVertex");
        graph.addVertex(2);
        graph.addVertex(3);

        assertEquals(false, graph.isEmpty());
        assertEquals(2, graph.size());
        assertEquals(1, graph.getIndex(3));
        assertEquals(true, graph.indexIsValid(0));
        assertEquals(false, graph.indexIsValid(2));

        this.tearDown();
    }

    /**
     * Test of removeVertex method, of class GraphList.
     */
    @Test
    public void testRemoveVertex() {
        this.setUp();
        System.out.println("removeVertex");
        assertEquals(4, this.graph.size());
        assertEquals(0, graph.getIndex(2));
        this.graph.removeVertex(2);
        assertEquals(3, this.graph.size());
        assertEquals(-1, graph.getIndex(2));
        assertEquals(0, graph.getIndex(3));
        this.tearDown();
    }

    /**
     * Test of addEdge method, of class GraphList.
     */
    @Test
    public void testAddEdge_GenericType_GenericType() {
        System.out.println("addEdge");
        this.graph = new GraphList<>();
        Integer vertex1 = 6;
        Integer vertex2 = 7;
        this.graph.addVertex(vertex1);
        this.graph.addVertex(vertex2);

        assertEquals(false, this.graph.isConnected());

        this.graph.addEdge(vertex1, vertex2);

        assertEquals(true, this.graph.isConnected());

        this.tearDown();
    }

    /**
     * Test of addEdge method, of class GraphList.
     */
    @Test
    public void testAddEdge_int_int() {
        this.setUp();
        System.out.println("addEdge");
        this.graph.addEdge(0, 1);
        this.graph.addEdge(1, 2);
        assertEquals(false, this.graph.isConnected());
        this.graph.addEdge(2, 3);
        assertEquals(true, this.graph.isConnected());
        this.tearDown();
    }

    /**
     * Test of removeRedge method, of class GraphList.
     */
    @Test
    public void testRemoveRedge() {
        this.setUp();
        System.out.println("removeRedge");

        this.graph.addEdge(0, 1);
        this.graph.addEdge(1, 2);
        this.graph.addEdge(2, 3);

        assertEquals(true, this.graph.isConnected());
        this.graph.removeRedge(2, 3);
        assertEquals(false, this.graph.isConnected());

        this.tearDown();
    }

    /**
     * Test of iteratorBFS method, of class GraphList.
     */
    @Test
    public void testIteratorBFS() {
        this.setUp2();
        System.out.println("iteratorBFS");

        Iterator iter = this.graph2.iteratorBFS("B");

        String string = "";
        while (iter.hasNext()) {
            Object value = iter.next();
            System.out.println(value);
            string = string + value;
        }
        assertEquals("BADCEF", string);

        this.tearDown2();
    }

    /**
     * Test of iteratorDFS method, of class GraphList.
     */
    @Test
    public void testIteratorDFS() {
        this.setUp2();
        System.out.println("iteratorDFS");

        Iterator iter = this.graph2.iteratorDFS("A");

        String string = "";
        while (iter.hasNext()) {
            Object value = iter.next();
            System.out.println(value);
            string = string + value;
        }
        assertEquals("ABDCEF", string);
        this.tearDown2();
    }

    /**
     * Test of iteratorShortestPath method, of class GraphList.
     */
    @Test
    public void testIteratorShortestPath() {
        this.setUp2();
        System.out.println("iteratorShortestPath");

        Iterator iter = this.graph2.iteratorShortestPath("A", "D");

        String string = "";
        while (iter.hasNext()) {
            Object value = iter.next();
            System.out.println(value);
            string = string + value;
        }
        assertEquals("ABD", string);
        this.tearDown2();
    }

    /**
     * Test of isEmpty method, of class GraphList.
     */
    @Test
    public void testIsEmpty() {
        this.setUp();
        System.out.println("isEmpty");
        assertFalse(this.graph.isEmpty());
        this.tearDown();
    }

    /**
     * Test of isConnected method, of class GraphList.
     */
    @Test
    public void testIsConnected() {
        this.setUp();
        System.out.println("isConnected");
        assertFalse(this.graph.isConnected());
        this.tearDown();
        this.setUp2();
        assertTrue(this.graph2.isConnected());
        this.tearDown2();
    }

    /**
     * Test of size method, of class GraphList.
     */
    @Test
    public void testSize() {
        System.out.println("size");
        this.graph = new GraphList<>();
        assertEquals(0, this.graph.size());
        this.tearDown();
        this.setUp();
        assertEquals(4, this.graph.size());
        this.tearDown();
    }

    /**
     * Test of expandCapacity method, of class GraphList.
     */
    @Test
    public void testExpandCapacity() {
        this.setUp();
        System.out.println("expandCapacity");
        this.graph.addVertex(9);
        this.graph.addVertex(10012);
        assertEquals(6, this.graph.size());
        this.tearDown();
    }

    /**
     * Test of indexIsValid method, of class GraphList.
     */
    @Test
    public void testIndexIsValid() {
        this.setUp();

        System.out.println("indexIsValid");

        assertTrue(this.graph.indexIsValid(0));
        assertTrue(this.graph.indexIsValid(1));
        assertTrue(this.graph.indexIsValid(2));
        assertTrue(this.graph.indexIsValid(3));
        assertFalse(this.graph.indexIsValid(4));

        this.tearDown();
    }

    /**
     * Test of getIndex method, of class GraphList.
     */
    @Test
    public void testGetIndex() {
        this.setUp();
        System.out.println("getIndex");

        assertEquals(0, this.graph.getIndex(2));
        assertEquals(-1, this.graph.getIndex(1));
        assertEquals(2, this.graph.getIndex(4));
        assertEquals(1, this.graph.getIndex(3));
        assertEquals(3, this.graph.getIndex(5));

        this.tearDown();
    }

}
