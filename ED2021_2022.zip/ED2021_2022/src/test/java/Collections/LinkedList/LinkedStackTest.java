/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.LinkedList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author tomaspendao
 */
public class LinkedStackTest {
    
    LinkedStack<Integer> tester;
    
    @BeforeEach
    public void setUp() {
        System.out.println("\nRunning Set Up");
        this.tester = new LinkedStack<>();
        this.tester.push(1);
        this.tester.push(2);
        this.tester.push(3);
    }
    
    @AfterEach
    public void tearDown() {
        System.out.println("Running Tear Down\n");
        this.tester = null;
    }

    /**
     * Test of push method, of class LinkedStack.
     */
    @Test
    public void testPush() {
        this.setUp();
        System.out.println("push");
        this.tester.push(99);
        assertEquals(4, this.tester.size());
        assertEquals("99\n3\n2\n1\n", this.tester.toString());
        this.tearDown();
    }

    /**
     * Test of pop method, of class LinkedStack.
     */
    @Test
    public void testPop() {
        this.setUp();
        System.out.println("pop");
        assertEquals(3, this.tester.pop());
        assertEquals(2, this.tester.size());
        assertEquals("2\n1\n", this.tester.toString());
        this.tearDown();
    }

    /**
     * Test of peek method, of class LinkedStack.
     */
    @Test
    public void testPeek() {
        this.setUp();
        System.out.println("peek");
        assertEquals(3, this.tester.peek());
        assertEquals("3\n2\n1\n", this.tester.toString());
        this.tearDown();
    }

    /**
     * Test of isEmpty method, of class LinkedStack.
     */
    @Test
    public void testIsEmpty() {
        this.tester = new LinkedStack<>();
        assertTrue(this.tester.isEmpty());
        this.tearDown();
        this.setUp();
        System.out.println("isEmpty");
        assertFalse(this.tester.isEmpty());
        this.tearDown();
    }

    /**
     * Test of size method, of class LinkedStack.
     */
    @Test
    public void testSize() {
        this.tester = new LinkedStack<>();
        assertEquals(0,this.tester.size());
        this.tearDown();
        this.setUp();
        System.out.println("size");
        assertEquals(3,this.tester.size());
        this.tearDown();
    }

    /**
     * Test of toString method, of class LinkedStack.
     */
    @Test
    public void testToString() {
        this.setUp();
        System.out.println("toString");
        assertEquals("3\n2\n1\n", this.tester.toString());
        this.tearDown();
    }
    
}
