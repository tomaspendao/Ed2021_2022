/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.LinkedList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author tomaspendao
 */
public class LinkedBinarySearchTreeTest {
    
    LinkedBinarySearchTree<Integer> teste;
    
    @Before
    public void setUp() {
        System.out.println("Running Set Up");
        teste = new LinkedBinarySearchTree<>();
        teste.addElement(5);
        teste.addElement(7);
        teste.addElement(3);
        teste.addElement(4);
    }
    
    @After
    public void tearDown() {
        System.out.println("Running Tear Down");
        teste = null;
    }

    /**
     * Test of addElement method, of class LinkedBinarySearchTree.
     */
    @Test
    public void testAddElement() {
        System.out.println("addElement");
        teste.addElement(2);
        assertEquals((Integer)2, teste.findMin());
        teste.addElement(20);
        assertEquals((Integer)20, teste.findMax());
    }

    /**
     * Test of removeElement method, of class LinkedBinarySearchTree.
     */
    @Test
    public void testRemoveElement() {
        System.out.println("removeElement");
        assertEquals((Integer)3, teste.removeElement(3));
        assertEquals((Integer)4, teste.findMin());
        assertEquals((Integer)7, teste.findMax());
        assertEquals((Integer)5, teste.getRoot());
        assertEquals((Integer)5, teste.removeElement(5));
        assertEquals((Integer)7, teste.getRoot());
    }

    /**
     * Test of removeAllOccurrences method, of class LinkedBinarySearchTree.
     */
    @Test
    public void testRemoveAllOccurrences() {
        System.out.println("removeAllOccurrences");
        teste.addElement(3);
        assertEquals((Integer)3, teste.findMin());
        teste.removeAllOccurrences(3);
        assertEquals((Integer)4, teste.findMin());
    }

    /**
     * Test of removeMin method, of class LinkedBinarySearchTree.
     */
    @Test
    public void testRemoveMin() {
        System.out.println("removeMin");
        assertEquals((Integer)3, teste.removeMin());
        assertEquals((Integer)4, teste.findMin());
    }

    /**
     * Test of removeMax method, of class LinkedBinarySearchTree.
     */
    @Test
    public void testRemoveMax() {
        System.out.println("removeMax");
        assertEquals((Integer)7, teste.removeMax());
        assertEquals((Integer)5, teste.findMax());
    }

    /**
     * Test of findMin method, of class LinkedBinarySearchTree.
     */
    @Test
    public void testFindMin() {
        System.out.println("findMin");
        assertEquals((Integer)3, teste.findMin());
    }

    /**
     * Test of findMax method, of class LinkedBinarySearchTree.
     */
    @Test
    public void testFindMax() {
        System.out.println("findMax");
        assertEquals((Integer)7, teste.findMax());
    }
    
}
