/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.LinkedList;

import ADT.QueueADT;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author tomaspendao
 */
public class TworOrderedQueueInToOneTest {
    
    TworOrderedQueueInToOne tester;
    
    @BeforeEach
    public void setUp() {
        System.out.println("\nRunning Set Up");
        QueueADT<String> queue1 = new LinkedQueue<>();
        QueueADT<String> queue2 = new LinkedQueue<>();
        
        queue1.enqueue("a");
        queue1.enqueue("b");
        queue1.enqueue("c");
        queue1.enqueue("d");
        
        
        queue2.enqueue("b");
        queue2.enqueue("d");
        queue2.enqueue("e");
        
        this.tester = new TworOrderedQueueInToOne(queue1, queue2);
    }
    
    @AfterEach
    public void tearDown() {
        System.out.println("Running Tear Down\n");
        this.tester = null;
    }

    /**
     * Test of getQueue method, of class TworOrderedQueueInToOne.
     */
    @Test
    public void testGetQueue() {
        this.setUp();
        System.out.println("getQueue");
        assertEquals("e d d c b b a ", this.tester.getQueue().toString());
        this.tearDown();
    }
    
}
