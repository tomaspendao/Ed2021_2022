/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.LinkedList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author tomaspendao
 */
public class MyLinkedListSentinelTest {
    
    MyLinkedListSentinel<Integer> tester;
    
    @BeforeEach
    public void setUp() {
        System.out.println("\nRunning Set Up");
        this.tester = new MyLinkedListSentinel<>();
        this.tester.add(1);
        this.tester.add(2);
        this.tester.add(3);
    }
    
    @AfterEach
    public void tearDown() {
        System.out.println("Running Tear Down\n");
        this.tester = null;
    }

    /**
     * Test of add method, of class MyLinkedListSentinel.
     */
    @Test
    public void testAdd() {
        this.setUp();
        System.out.println("add");
        this.tester.add(99);
        //this.tester.printAll();
        assertEquals(99, this.tester.getHead().getNext().getValue());
        this.tearDown();
    }

    /**
     * Test of printAll method, of class MyLinkedListSentinel.
     */
    /*@Test
    public void testPrintAll() {
        System.out.println("printAll");
        MyLinkedListSentinel instance = new MyLinkedListSentinel();
        instance.printAll();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }*/

    /**
     * Test of remove method, of class MyLinkedListSentinel.
     */
    @Test
    public void testRemove() {
        this.setUp();
        System.out.println("remove");
        assertEquals(3, this.tester.getHead().getNext().getValue());
        this.tester.remove();
        assertEquals(2, this.tester.getHead().getNext().getValue());
        //this.tester.printAll();
        this.tearDown();
    }

    /**
     * Test of getHead method, of class MyLinkedListSentinel.
     */
    @Test
    public void testGetHead() {
        this.setUp();
        System.out.println("getHead");
        assertNull(this.tester.getHead().getValue());
        this.tearDown();
    }

    /**
     * Test of setHead method, of class MyLinkedListSentinel.
     */
    /*@Test
    public void testSetHead() {
        System.out.println("setHead");
        MyLinkedListSentinel instance = new MyLinkedListSentinel();
        instance.setHead(null);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }*/

    /**
     * Test of getTail method, of class MyLinkedListSentinel.
     */
    @Test
    public void testGetTail() {
        this.setUp();
        System.out.println("getTail");
        assertNull(this.tester.getTail().getValue());
        this.tearDown();
    }

    /**
     * Test of toString method, of class MyLinkedListSentinel.
     */
    @Test
    public void testToString() {
        this.setUp();
        System.out.println("toString");
        assertEquals("3;2;1;", this.tester.toString());
        this.tearDown();
    }

    /**
     * Test of setTail method, of class MyLinkedListSentinel.
     */
    /*@Test
    public void testSetTail() {
        System.out.println("setTail");
        MyLinkedListSentinel instance = new MyLinkedListSentinel();
        instance.setTail(null);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }*/
    
}
