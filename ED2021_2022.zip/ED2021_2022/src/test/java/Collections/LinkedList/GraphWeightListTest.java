/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package Collections.LinkedList;

import Collections.DoubleLinkedList.DoubleLinkedUnorderedList;
import Models.Nodes.ArestaWeight;
import java.util.Iterator;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Tomás Pendão
 */
public class GraphWeightListTest {
    
    GraphWeightList<Integer> graph;
    GraphWeightList<String> graph2;

    public void setUp() {
        graph = new GraphWeightList<>();
        graph.addVertex(2);
        graph.addVertex(3);
        graph.addVertex(4);
        graph.addVertex(5);
    }

    public void setUp2() {
        graph2 = new GraphWeightList<>();
        graph2.addVertex("A");
        graph2.addVertex("B");
        graph2.addVertex("C");
        graph2.addVertex("D");
        graph2.addVertex("E");
        graph2.addVertex("F");

        this.graph2.addEdge("A", "B",2);
        this.graph2.addEdge("A", "C",4);
        this.graph2.addEdge("B", "D",6);
        this.graph2.addEdge("C", "E",2);
        this.graph2.addEdge("C", "F",9);
    }

    public void setUp3(){
        graph2 = new GraphWeightList<>();
        graph2.addVertex("A");
        graph2.addVertex("B");
        graph2.addVertex("C");
        graph2.addVertex("D");
        graph2.addVertex("E");
        graph2.addVertex("F");

        this.graph2.addEdge("A", "B",10);
        this.graph2.addEdge("A", "C",15);
        this.graph2.addEdge("B", "D",12);
        this.graph2.addEdge("B", "F",15);
        this.graph2.addEdge("C", "E",10);
        this.graph2.addEdge("D", "E",2);
        this.graph2.addEdge("D", "F",1);
        this.graph2.addEdge("F", "E",5);
    }
    
    public void tearDown() {
        graph = null;
    }

    public void tearDown2() {
        graph2 = null;
    }

    /**
     * Test of addVertex method, of class GraphWeightList.
     */
    @Test
    public void testAddVertex() {
        graph = new GraphWeightList<>();
        System.out.println("addVertex");
        graph.addVertex(2);
        graph.addVertex(3);

        assertEquals(false, graph.isEmpty());
        assertEquals(2, graph.size());
        assertEquals(1, graph.getIndex(3));
        assertEquals(true, graph.indexIsValid(0));
        assertEquals(false, graph.indexIsValid(2));

        this.tearDown();
    }

    /**
     * Test of removeVertex method, of class GraphWeightList.
     */
    @Test
    public void testRemoveVertex() {
        this.setUp();
        System.out.println("removeVertex");
        assertEquals(4, this.graph.size());
        assertEquals(0, graph.getIndex(2));
        this.graph.removeVertex(2);
        assertEquals(3, this.graph.size());
        assertEquals(-1, graph.getIndex(2));
        assertEquals(0, graph.getIndex(3));
        this.tearDown();
    }

    /**
     * Test of addEdge method, of class GraphWeightList.
     */
    @Test
    public void testAddEdge_GenericType_GenericType() {
        System.out.println("addEdge");
        this.graph = new GraphWeightList<>();
        Integer vertex1 = 6;
        Integer vertex2 = 7;
        this.graph.addVertex(vertex1);
        this.graph.addVertex(vertex2);

        assertEquals(false, this.graph.isConnected());

        this.graph.addEdge(vertex1, vertex2);

        assertEquals(true, this.graph.isConnected());

        this.tearDown();
    }

    /**
     * Test of addEdge method, of class GraphWeightList.
     */
    @Test
    public void testAddEdge_3args_1() {
        System.out.println("addEdge");
        this.graph = new GraphWeightList<>();
        Integer vertex1 = 6;
        Integer vertex2 = 7;
        this.graph.addVertex(vertex1);
        this.graph.addVertex(vertex2);

        assertEquals(false, this.graph.isConnected());

        this.graph.addEdge(vertex1, vertex2,5);

        assertEquals(true, this.graph.isConnected());

        this.tearDown();
    }

    /**
     * Test of addEdge method, of class GraphWeightList.
     */
    @Test
    public void testAddEdge_3args_2() {
        this.setUp();
        System.out.println("addEdge");
        this.graph.addEdge(0, 1, 5);
        this.graph.addEdge(1, 2, 6);
        assertEquals(false, this.graph.isConnected());
        this.graph.addEdge(2, 3, 7);
        assertEquals(true, this.graph.isConnected());
        this.tearDown();
    }

    /**
     * Test of removeRedge method, of class GraphWeightList.
     */
    @Test
    public void testRemoveRedge() {
        this.setUp();
        System.out.println("removeRedge");

        this.graph.addEdge(0, 1,2);
        this.graph.addEdge(1, 2,4);
        this.graph.addEdge(2, 3,1);

        //assertEquals(true, this.graph.isConnected());
        this.graph.removeRedge(2, 3);
        assertEquals(false, this.graph.isConnected());

        this.tearDown();
    }

    /**
     * Test of iteratorBFS method, of class GraphWeightList.
     */
    @Test
    public void testIteratorBFS() {
        this.setUp2();
        System.out.println("iteratorBFS");

        Iterator iter = this.graph2.iteratorBFS("B");

        String string = "";
        while (iter.hasNext()) {
            Object value = iter.next();
            System.out.println(value);
            string = string + value;
        }
        assertEquals("BADCEF", string);
        
        this.tearDown2();
    }

    /**
     * Test of iteratorDFS method, of class GraphWeightList.
     */
    @Test
    public void testIteratorDFS() {
        this.setUp2();
        System.out.println("iteratorDFS");

        Iterator iter = this.graph2.iteratorDFS("A");

        String string = "";
        while (iter.hasNext()) {
            Object value = iter.next();
            System.out.println(value);
            string = string + value;
        }
        assertEquals("ABDCEF", string);
        this.tearDown2();
    }

    /**
     * Test of iteratorShortestPath method, of class GraphWeightList.
     */
    @Test
    public void testIteratorShortestPath() {
        // this.setUp3();
        
        graph2 = new GraphWeightList<>();
        graph2.addVertex("Empresa");
        graph2.addVertex("Mercado 1");
        graph2.addVertex("Mercado 2");
        graph2.addVertex("Armazém 1");

        this.graph2.addEdge("Empresa", "Mercado 1", 30);
        // this.graph2.addEdge("Mercado 1", "Empresa", 30);

        this.graph2.addEdge("Mercado 1", "Mercado 2", 30);
        // this.graph2.addEdge("Mercado 2", "Mercado 1", 30);

        this.graph2.addEdge("Empresa", "Armazém 1", 30);
        // this.graph2.addEdge("Armazém 1", "Empresa", 30);

        this.graph2.addEdge("Mercado 1", "Armazém 1", 30);        
        // this.graph2.addEdge("Armazém 1", "Mercado 1", 30);        
        
        System.out.println("iteratorShortestPath");

        Iterator iter = this.graph2.iteratorShortestPath("Armazém 1", "Mercado 2");

        //System.out.println("ola-->" + this.graph2.getTripWeight(iter));
        
        String string = "";
        while (iter.hasNext()) {
            Object value = iter.next();
            System.out.println(":" + value);
            string = string + value;
        }
        assertEquals("Armazém 1Mercado 1Mercado 2", string);
        this.tearDown2();
    }

    /**
     * Test of isEmpty method, of class GraphWeightList.
     */
    @Test
    public void testIsEmpty() {
        this.setUp();
        System.out.println("isEmpty");
        assertFalse(this.graph.isEmpty());
        this.tearDown();
    }

    /**
     * Test of isConnected method, of class GraphWeightList.
     */
    @Test
    public void testIsConnected() {
        this.setUp();
        System.out.println("isConnected");
        assertFalse(this.graph.isConnected());
        this.tearDown();
        this.setUp2();
        assertTrue(this.graph2.isConnected());
        this.tearDown2();
    }

    /**
     * Test of size method, of class GraphWeightList.
     */
    @Test
    public void testSize() {
        System.out.println("size");
        this.graph = new GraphWeightList<>();
        assertEquals(0, this.graph.size());
        this.tearDown();
        this.setUp();
        assertEquals(4, this.graph.size());
        this.tearDown();
    }

    /**
     * Test of expandCapacity method, of class GraphWeightList.
     */
    @Test
    public void testExpandCapacity() {
        this.setUp();
        System.out.println("expandCapacity");
        this.graph.addVertex(9);
        this.graph.addVertex(10012);
        assertEquals(6, this.graph.size());
        this.tearDown();
    }

    /**
     * Test of indexIsValid method, of class GraphWeightList.
     */
    @Test
    public void testIndexIsValid() {
        this.setUp();
        
        System.out.println("indexIsValid");
        
        assertTrue(this.graph.indexIsValid(0));
        assertTrue(this.graph.indexIsValid(1));
        assertTrue(this.graph.indexIsValid(2));
        assertTrue(this.graph.indexIsValid(3));
        assertFalse(this.graph.indexIsValid(4));
        
        this.tearDown();
    }

    /**
     * Test of getIndex method, of class GraphWeightList.
     */
    @Test
    public void testGetIndex() {
        this.setUp();
        this.setUp2();
        System.out.println("getIndex");
        DoubleLinkedUnorderedList<ArestaWeight>[] test = this.graph2.getAdjList();
        for (int i = 0; i < this.graph2.size(); i++) {
            Iterator iter = test[i].iterator();
            while(iter.hasNext()){
                ArestaWeight value = (ArestaWeight) iter.next();
                System.out.println(value.getWeight());
            }
        }
        assertEquals(0, this.graph.getIndex(2));
        assertEquals(-1, this.graph.getIndex(1));
        assertEquals(2, this.graph.getIndex(4));
        assertEquals(1, this.graph.getIndex(3));
        assertEquals(3, this.graph.getIndex(5));
        
        this.tearDown2();
        this.tearDown();
    }
    
}
