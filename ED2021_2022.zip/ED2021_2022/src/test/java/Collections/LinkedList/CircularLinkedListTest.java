/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.LinkedList;

import java.util.Iterator;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author tomaspendao
 */
public class CircularLinkedListTest {
    
    CircularLinkedList<Integer> tester;
    
    @BeforeEach
    public void setUp() {
        System.out.println("\nRunning Set Up");
        this.tester = new CircularLinkedList<>();
        this.tester.addToFront(1);
        this.tester.addToFront(2);
        this.tester.addToFront(3);
    }
    
    @AfterEach
    public void tearDown() {
        System.out.println("Running Tear Down\n");
        this.tester = null;
    }

    /**
     * Test of removeFirst method, of class CircularLinkedList.
     */
    @Test
    public void testRemoveFirst() {
        this.setUp();
        System.out.println("removeFirst");
        assertEquals(3, this.tester.removeFirst());
        assertEquals(2, this.tester.size());
        assertEquals("|2|1|", this.tester.toString());
        this.tearDown();
    }

    /**
     * Test of removeLast method, of class CircularLinkedList.
     */
    @Test
    public void testRemoveLast() {
        this.setUp();
        System.out.println("removeLast");
        assertEquals(1, this.tester.removeLast());
        assertEquals(2, this.tester.size());
        assertEquals("|3|2|", this.tester.toString());
        this.tearDown();
    }

    /**
     * Test of remove method, of class CircularLinkedList.
     */
    @Test
    public void testRemove() {
        this.setUp();
        System.out.println("remove");
        assertEquals(2, this.tester.remove(2));
        assertEquals(2, this.tester.size());
        assertEquals("|3|1|", this.tester.toString());
        this.tearDown();
    }

    /**
     * Test of first method, of class CircularLinkedList.
     */
    @Test
    public void testFirst() {
        this.setUp();
        System.out.println("first");
        assertEquals(3, this.tester.first());
        this.tearDown();
    }

    /**
     * Test of last method, of class CircularLinkedList.
     */
    @Test
    public void testLast() {
        this.setUp();
        System.out.println("last");
        assertEquals(1, this.tester.last());
        this.tearDown();
    }

    /**
     * Test of contains method, of class CircularLinkedList.
     */
    @Test
    public void testContains() {
        this.setUp();
        System.out.println("contains");
        assertTrue(this.tester.contains(2));
        assertFalse(this.tester.contains(21));
        this.tearDown();
    }

    /**
     * Test of isEmpty method, of class CircularLinkedList.
     */
    @Test
    public void testIsEmpty() {
        this.tester = new CircularLinkedList<>();
        assertTrue(this.tester.isEmpty());
        this.tearDown();
        this.setUp();
        System.out.println("isEmpty");
        assertFalse(this.tester.isEmpty());
        this.tearDown();
    }

    /**
     * Test of size method, of class CircularLinkedList.
     */
    @Test
    public void testSize() {
        this.tester = new CircularLinkedList<>();
        assertEquals(0,this.tester.size());
        this.tearDown();
        this.setUp();
        System.out.println("size");
        assertEquals(3,this.tester.size());
        this.tearDown();
    }

    /**
     * Test of iterator method, of class CircularLinkedList.
     */
    /*@Test
    public void testIterator() {
        System.out.println("iterator");
        CircularLinkedList instance = new CircularLinkedList();
        Iterator expResult = null;
        Iterator result = instance.iterator();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }*/

    /**
     * Test of addToFront method, of class CircularLinkedList.
     */
    @Test
    public void testAddToFront() {
        this.setUp();
        System.out.println("addToFront");
        this.tester.addToFront(101);
        assertEquals("|101|3|2|1|", this.tester.toString());
        this.tearDown();
    }

    /**
     * Test of addToRear method, of class CircularLinkedList.
     */
    @Test
    public void testAddToRear() {
        this.setUp();
        System.out.println("addToRear");
        this.tester.addToRear(102);
        assertEquals("|3|2|1|102|", this.tester.toString());
        this.tearDown();
    }

    /**
     * Test of addAfter method, of class CircularLinkedList.
     */
    @Test
    public void testAddAfter() {
        this.setUp();
        System.out.println("addAfter");
        this.tester.addAfter(103,2);
        assertEquals("|3|2|103|1|", this.tester.toString());
        this.tearDown();
    }

    /**
     * Test of toString method, of class CircularLinkedList.
     */
    @Test
    public void testToString() {
        this.setUp();
        System.out.println("toString");
        assertEquals("|3|2|1|", this.tester.toString());
        this.tearDown();
    }
    
}
