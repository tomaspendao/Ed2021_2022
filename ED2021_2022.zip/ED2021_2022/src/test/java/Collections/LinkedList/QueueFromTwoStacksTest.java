/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.LinkedList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author tomaspendao
 */
public class QueueFromTwoStacksTest {
    
    QueueFromTwoStacks<Integer> tester;
    
    @BeforeEach
    public void setUp() {
        System.out.println("\nRunning Set Up");
        this.tester = new QueueFromTwoStacks<>();
        this.tester.enqueue(1);
        this.tester.enqueue(2);
        this.tester.enqueue(3);
    }
    
    @AfterEach
    public void tearDown() {
        System.out.println("Running Tear Down\n");
        this.tester = null;
    }

    /**
     * Test of enqueue method, of class QueueFromTwoStacks.
     */
    @Test
    public void testEnqueue() {
        this.setUp();
        System.out.println("enqueue");
        this.tester.enqueue(99);
        assertEquals("1\n2\n3\n99\n", this.tester.toString());
        assertEquals(1, this.tester.first());
        this.tearDown();
    }

    /**
     * Test of dequeue method, of class QueueFromTwoStacks.
     */
    @Test
    public void testDequeue() {
        this.setUp();
        System.out.println("dequeue");
        assertEquals("1\n2\n3\n", this.tester.toString());
        assertEquals(1, this.tester.dequeue());
        assertEquals("2\n3\n", this.tester.toString());
        assertEquals(2, this.tester.first());
        this.tearDown();
    }

    /**
     * Test of first method, of class QueueFromTwoStacks.
     */
    @Test
    public void testFirst() {
        this.setUp();
        System.out.println("first");
        assertEquals(1, this.tester.first());
        this.tearDown();
    }

    /**
     * Test of isEmpty method, of class QueueFromTwoStacks.
     */
    @Test
    public void testIsEmpty() {
        this.tester = new QueueFromTwoStacks<>();
        assertTrue(this.tester.isEmpty());
        this.tearDown();
        this.setUp();
        System.out.println("isEmpty");
        assertFalse(this.tester.isEmpty());
        this.tearDown();
    }

    /**
     * Test of size method, of class QueueFromTwoStacks.
     */
    @Test
    public void testSize() {
        this.tester = new QueueFromTwoStacks<>();
        assertEquals(0,this.tester.size());
        this.tearDown();
        this.setUp();
        System.out.println("size");
        assertEquals(3,this.tester.size());
        this.tearDown();
    }

    /**
     * Test of toString method, of class QueueFromTwoStacks.
     */
    @Test
    public void testToString() {
        this.setUp();
        System.out.println("toString");
        assertEquals("1\n2\n3\n", this.tester.toString());
        this.tearDown();
    }
    
}
