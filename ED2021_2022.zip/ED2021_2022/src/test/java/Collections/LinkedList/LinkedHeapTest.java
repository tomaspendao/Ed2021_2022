/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.LinkedList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author tomaspendao
 */
public class LinkedHeapTest {

    LinkedHeap<Integer> teste;

    @Before
    public void setUp() {
        teste = new LinkedHeap<>();
        teste.addElement(3);
        teste.addElement(5);
        teste.addElement(4);
        teste.addElement(8);
        teste.addElement(7);
        teste.addElement(9);
    }

    @After
    public void tearDown() {
        this.teste = null;
    }

    /**
     * Test of addElement method, of class LinkedHeap.
     */
    @Test
    public void testAddElement() {
        System.out.println("addElement");
        teste.addElement(2);
        assertEquals((Integer) 2, teste.getRoot());
    }

    /**
     * Test of removeMin method, of class LinkedHeap.
     */
    @Test
    public void testRemoveMin() {
        System.out.println("removeMin");
        assertEquals((Integer) 3, teste.removeMin());
        assertEquals((Integer) 4, teste.getRoot());
    }

    /**
     * Test of findMin method, of class LinkedHeap.
     */
    @Test
    public void testFindMin() {
        System.out.println("findMin");
        assertEquals((Integer) 3, teste.findMin());
        assertEquals(teste.getRoot(), teste.findMin());
    }

}
