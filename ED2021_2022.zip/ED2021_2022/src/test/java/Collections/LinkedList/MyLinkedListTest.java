/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.LinkedList;

import Models.Nodes.MyLinearNode;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author tomaspendao
 */
public class MyLinkedListTest {
    
    MyLinkedList<Integer> list;
    
    @BeforeEach
    public void setUp() {
        this.list = new MyLinkedList<>();
        this.list.add(1);
        this.list.add(2);
        this.list.add(3);      
    }
    
    @AfterEach
    public void tearDown() {
        this.list = null;
    }

    /**
     * Test of add method, of class MyLinkedList.
     */
    @Test
    public void testAdd() {
        this.setUp();
        System.out.println("add");
        this.list.add(7);
        this.list.printAll();
        assertEquals(7, this.list.getHead().getValue());
        this.tearDown();
    }

    /**
     * Test of printAll method, of class MyLinkedList.
     */
    @Test
    public void testPrintAll() {
        this.setUp();
        System.out.println("printAll");
        this.list.printAll();
        this.tearDown();
    }

    /**
     * Test of remove method, of class MyLinkedList.
     */
    @Test
    public void testRemove() {
        this.setUp();
        System.out.println("remove");
        this.list.remove();
        //this.list.printAll();
        assertEquals(2, this.list.getHead().getValue());
        this.tearDown();
    }

    /**
     * Test of getHead method, of class MyLinkedList.
     */
    @Test
    public void testGetHead() {
        this.setUp();
        System.out.println("getHead");
        assertEquals(3, this.list.getHead().getValue());
        this.tearDown();
    }

    /**
     * Test of setHead method, of class MyLinkedList.
     */
    @Test
    public void testSetHead() {
        this.setUp();
        System.out.println("setHead");
        MyLinearNode<Integer> newHead = new MyLinearNode(9);
        this.list.setHead(newHead);
        assertEquals(9, this.list.getHead().getValue());
        this.tearDown();
    }

    /**
     * Test of recursivePrintAll method, of class MyLinkedList.
     */
    @Test
    public void testRecursivePrintAll() {
        this.setUp();
        System.out.println("recursivePrintAll");
        this.list.recursivePrintAll(this.list.head);
        this.tearDown();
    }

    /**
     * Test of recursiveInvertedPrintAll method, of class MyLinkedList.
     */
    @Test
    public void testRecursiveInvertedPrintAll() {
        this.setUp();
        System.out.println("recursiveInvertedPrintAll");
        this.list.recursiveInvertedPrintAll(this.list.head);
        this.tearDown();
    }

    /**
     * Test of recursiveReverse method, of class MyLinkedList.
     */
    @Test
    public void testRecursiveReverse() {
        this.setUp();
        System.out.println("recursiveReverse");
        this.list.recursiveReverse();
        assertEquals(1, this.list.getHead().getValue());
        this.tearDown();
    }
    
}
