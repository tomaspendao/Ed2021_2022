/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections.LinkedList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author tomaspendao
 */
public class QueueOfQueuesTest {
    
    QueueOfQueues tester;
    
    @BeforeEach
    public void setUp() {
        System.out.println("\nRunning Set Up");
        String[] array = {"1","2","3","4","5","6"};
        this.tester = new QueueOfQueues(array);
    }
    
    @AfterEach
    public void tearDown() {
        System.out.println("Running Tear Down\n");
        this.tester = null;
    }

    /**
     * Test of getQueueOfQueues method, of class QueueOfQueues.
     */
    @Test
    public void testGetQueueOfQueues() {
        this.setUp();
        System.out.println("getQueueOfQueues");
        assertEquals(1, this.tester.getQueueOfQueues().size());
        this.tearDown();
    }
    
}
